import * as jspdf from 'jspdf';
import * as html2canvas from 'html2canvas';

var commonjsGlobal = typeof globalThis !== 'undefined' ? globalThis : "undefined" !== 'undefined' ? window : typeof global !== 'undefined' ? global : typeof self !== 'undefined' ? self : {};

function getDefaultExportFromCjs (x) {
	return x && x.__esModule && Object.prototype.hasOwnProperty.call(x, 'default') ? x['default'] : x;
}

function getDefaultExportFromNamespaceIfNotNamed (n) {
	return n && Object.prototype.hasOwnProperty.call(n, 'default') && Object.keys(n).length === 1 ? n['default'] : n;
}

var html2pdf$2 = {exports: {}};

const require$$0 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(jspdf);

const require$$1 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(html2canvas);

/*!
 * html2pdf.js v0.12.1
 * Copyright (c) 2025 Erik Koopmans
 * Released under the MIT License.
 */

(function (module, exports) {
	(function webpackUniversalModuleDefinition(root, factory) {
		module.exports = factory(require$$0, require$$1);
	})(self, function(__WEBPACK_EXTERNAL_MODULE_jspdf__, __WEBPACK_EXTERNAL_MODULE_html2canvas__) {
	return /******/ (function() { // webpackBootstrap
	/******/ 	var __webpack_modules__ = ({

	/***/ "./node_modules/core-js/internals/a-callable.js":
	/*!******************************************************!*\
	  !*** ./node_modules/core-js/internals/a-callable.js ***!
	  \******************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/core-js/internals/is-callable.js");
	var tryToString = __webpack_require__(/*! ../internals/try-to-string */ "./node_modules/core-js/internals/try-to-string.js");

	var $TypeError = TypeError;

	// `Assert: IsCallable(argument) is true`
	module.exports = function (argument) {
	  if (isCallable(argument)) return argument;
	  throw new $TypeError(tryToString(argument) + ' is not a function');
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/a-constructor.js":
	/*!*********************************************************!*\
	  !*** ./node_modules/core-js/internals/a-constructor.js ***!
	  \*********************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var isConstructor = __webpack_require__(/*! ../internals/is-constructor */ "./node_modules/core-js/internals/is-constructor.js");
	var tryToString = __webpack_require__(/*! ../internals/try-to-string */ "./node_modules/core-js/internals/try-to-string.js");

	var $TypeError = TypeError;

	// `Assert: IsConstructor(argument) is true`
	module.exports = function (argument) {
	  if (isConstructor(argument)) return argument;
	  throw new $TypeError(tryToString(argument) + ' is not a constructor');
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/a-possible-prototype.js":
	/*!****************************************************************!*\
	  !*** ./node_modules/core-js/internals/a-possible-prototype.js ***!
	  \****************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var isPossiblePrototype = __webpack_require__(/*! ../internals/is-possible-prototype */ "./node_modules/core-js/internals/is-possible-prototype.js");

	var $String = String;
	var $TypeError = TypeError;

	module.exports = function (argument) {
	  if (isPossiblePrototype(argument)) return argument;
	  throw new $TypeError("Can't set " + $String(argument) + ' as a prototype');
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/a-set.js":
	/*!*************************************************!*\
	  !*** ./node_modules/core-js/internals/a-set.js ***!
	  \*************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var has = (__webpack_require__(/*! ../internals/set-helpers */ "./node_modules/core-js/internals/set-helpers.js").has);

	// Perform ? RequireInternalSlot(M, [[SetData]])
	module.exports = function (it) {
	  has(it);
	  return it;
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/add-to-unscopables.js":
	/*!**************************************************************!*\
	  !*** ./node_modules/core-js/internals/add-to-unscopables.js ***!
	  \**************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var wellKnownSymbol = __webpack_require__(/*! ../internals/well-known-symbol */ "./node_modules/core-js/internals/well-known-symbol.js");
	var create = __webpack_require__(/*! ../internals/object-create */ "./node_modules/core-js/internals/object-create.js");
	var defineProperty = (__webpack_require__(/*! ../internals/object-define-property */ "./node_modules/core-js/internals/object-define-property.js").f);

	var UNSCOPABLES = wellKnownSymbol('unscopables');
	var ArrayPrototype = Array.prototype;

	// Array.prototype[@@unscopables]
	// https://tc39.es/ecma262/#sec-array.prototype-@@unscopables
	if (ArrayPrototype[UNSCOPABLES] === undefined) {
	  defineProperty(ArrayPrototype, UNSCOPABLES, {
	    configurable: true,
	    value: create(null)
	  });
	}

	// add a key to Array.prototype[@@unscopables]
	module.exports = function (key) {
	  ArrayPrototype[UNSCOPABLES][key] = true;
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/an-instance.js":
	/*!*******************************************************!*\
	  !*** ./node_modules/core-js/internals/an-instance.js ***!
	  \*******************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var isPrototypeOf = __webpack_require__(/*! ../internals/object-is-prototype-of */ "./node_modules/core-js/internals/object-is-prototype-of.js");

	var $TypeError = TypeError;

	module.exports = function (it, Prototype) {
	  if (isPrototypeOf(Prototype, it)) return it;
	  throw new $TypeError('Incorrect invocation');
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/an-object.js":
	/*!*****************************************************!*\
	  !*** ./node_modules/core-js/internals/an-object.js ***!
	  \*****************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var isObject = __webpack_require__(/*! ../internals/is-object */ "./node_modules/core-js/internals/is-object.js");

	var $String = String;
	var $TypeError = TypeError;

	// `Assert: Type(argument) is Object`
	module.exports = function (argument) {
	  if (isObject(argument)) return argument;
	  throw new $TypeError($String(argument) + ' is not an object');
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/array-buffer-non-extensible.js":
	/*!***********************************************************************!*\
	  !*** ./node_modules/core-js/internals/array-buffer-non-extensible.js ***!
	  \***********************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	// FF26- bug: ArrayBuffers are non-extensible, but Object.isExtensible does not report it
	var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/core-js/internals/fails.js");

	module.exports = fails(function () {
	  if (typeof ArrayBuffer == 'function') {
	    var buffer = new ArrayBuffer(8);
	    // eslint-disable-next-line es/no-object-isextensible, es/no-object-defineproperty -- safe
	    if (Object.isExtensible(buffer)) Object.defineProperty(buffer, 'a', { value: 8 });
	  }
	});


	/***/ }),

	/***/ "./node_modules/core-js/internals/array-for-each.js":
	/*!**********************************************************!*\
	  !*** ./node_modules/core-js/internals/array-for-each.js ***!
	  \**********************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var $forEach = (__webpack_require__(/*! ../internals/array-iteration */ "./node_modules/core-js/internals/array-iteration.js").forEach);
	var arrayMethodIsStrict = __webpack_require__(/*! ../internals/array-method-is-strict */ "./node_modules/core-js/internals/array-method-is-strict.js");

	var STRICT_METHOD = arrayMethodIsStrict('forEach');

	// `Array.prototype.forEach` method implementation
	// https://tc39.es/ecma262/#sec-array.prototype.foreach
	module.exports = !STRICT_METHOD ? function forEach(callbackfn /* , thisArg */) {
	  return $forEach(this, callbackfn, arguments.length > 1 ? arguments[1] : undefined);
	// eslint-disable-next-line es/no-array-prototype-foreach -- safe
	} : [].forEach;


	/***/ }),

	/***/ "./node_modules/core-js/internals/array-from.js":
	/*!******************************************************!*\
	  !*** ./node_modules/core-js/internals/array-from.js ***!
	  \******************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var bind = __webpack_require__(/*! ../internals/function-bind-context */ "./node_modules/core-js/internals/function-bind-context.js");
	var call = __webpack_require__(/*! ../internals/function-call */ "./node_modules/core-js/internals/function-call.js");
	var toObject = __webpack_require__(/*! ../internals/to-object */ "./node_modules/core-js/internals/to-object.js");
	var callWithSafeIterationClosing = __webpack_require__(/*! ../internals/call-with-safe-iteration-closing */ "./node_modules/core-js/internals/call-with-safe-iteration-closing.js");
	var isArrayIteratorMethod = __webpack_require__(/*! ../internals/is-array-iterator-method */ "./node_modules/core-js/internals/is-array-iterator-method.js");
	var isConstructor = __webpack_require__(/*! ../internals/is-constructor */ "./node_modules/core-js/internals/is-constructor.js");
	var lengthOfArrayLike = __webpack_require__(/*! ../internals/length-of-array-like */ "./node_modules/core-js/internals/length-of-array-like.js");
	var createProperty = __webpack_require__(/*! ../internals/create-property */ "./node_modules/core-js/internals/create-property.js");
	var getIterator = __webpack_require__(/*! ../internals/get-iterator */ "./node_modules/core-js/internals/get-iterator.js");
	var getIteratorMethod = __webpack_require__(/*! ../internals/get-iterator-method */ "./node_modules/core-js/internals/get-iterator-method.js");

	var $Array = Array;

	// `Array.from` method implementation
	// https://tc39.es/ecma262/#sec-array.from
	module.exports = function from(arrayLike /* , mapfn = undefined, thisArg = undefined */) {
	  var O = toObject(arrayLike);
	  var IS_CONSTRUCTOR = isConstructor(this);
	  var argumentsLength = arguments.length;
	  var mapfn = argumentsLength > 1 ? arguments[1] : undefined;
	  var mapping = mapfn !== undefined;
	  if (mapping) mapfn = bind(mapfn, argumentsLength > 2 ? arguments[2] : undefined);
	  var iteratorMethod = getIteratorMethod(O);
	  var index = 0;
	  var length, result, step, iterator, next, value;
	  // if the target is not iterable or it's an array with the default iterator - use a simple case
	  if (iteratorMethod && !(this === $Array && isArrayIteratorMethod(iteratorMethod))) {
	    result = IS_CONSTRUCTOR ? new this() : [];
	    iterator = getIterator(O, iteratorMethod);
	    next = iterator.next;
	    for (;!(step = call(next, iterator)).done; index++) {
	      value = mapping ? callWithSafeIterationClosing(iterator, mapfn, [step.value, index], true) : step.value;
	      createProperty(result, index, value);
	    }
	  } else {
	    length = lengthOfArrayLike(O);
	    result = IS_CONSTRUCTOR ? new this(length) : $Array(length);
	    for (;length > index; index++) {
	      value = mapping ? mapfn(O[index], index) : O[index];
	      createProperty(result, index, value);
	    }
	  }
	  result.length = index;
	  return result;
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/array-includes.js":
	/*!**********************************************************!*\
	  !*** ./node_modules/core-js/internals/array-includes.js ***!
	  \**********************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var toIndexedObject = __webpack_require__(/*! ../internals/to-indexed-object */ "./node_modules/core-js/internals/to-indexed-object.js");
	var toAbsoluteIndex = __webpack_require__(/*! ../internals/to-absolute-index */ "./node_modules/core-js/internals/to-absolute-index.js");
	var lengthOfArrayLike = __webpack_require__(/*! ../internals/length-of-array-like */ "./node_modules/core-js/internals/length-of-array-like.js");

	// `Array.prototype.{ indexOf, includes }` methods implementation
	var createMethod = function (IS_INCLUDES) {
	  return function ($this, el, fromIndex) {
	    var O = toIndexedObject($this);
	    var length = lengthOfArrayLike(O);
	    if (length === 0) return !IS_INCLUDES && -1;
	    var index = toAbsoluteIndex(fromIndex, length);
	    var value;
	    // Array#includes uses SameValueZero equality algorithm
	    // eslint-disable-next-line no-self-compare -- NaN check
	    if (IS_INCLUDES && el !== el) while (length > index) {
	      value = O[index++];
	      // eslint-disable-next-line no-self-compare -- NaN check
	      if (value !== value) return true;
	    // Array#indexOf ignores holes, Array#includes - not
	    } else for (;length > index; index++) {
	      if ((IS_INCLUDES || index in O) && O[index] === el) return IS_INCLUDES || index || 0;
	    } return !IS_INCLUDES && -1;
	  };
	};

	module.exports = {
	  // `Array.prototype.includes` method
	  // https://tc39.es/ecma262/#sec-array.prototype.includes
	  includes: createMethod(true),
	  // `Array.prototype.indexOf` method
	  // https://tc39.es/ecma262/#sec-array.prototype.indexof
	  indexOf: createMethod(false)
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/array-iteration.js":
	/*!***********************************************************!*\
	  !*** ./node_modules/core-js/internals/array-iteration.js ***!
	  \***********************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var bind = __webpack_require__(/*! ../internals/function-bind-context */ "./node_modules/core-js/internals/function-bind-context.js");
	var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/core-js/internals/function-uncurry-this.js");
	var IndexedObject = __webpack_require__(/*! ../internals/indexed-object */ "./node_modules/core-js/internals/indexed-object.js");
	var toObject = __webpack_require__(/*! ../internals/to-object */ "./node_modules/core-js/internals/to-object.js");
	var lengthOfArrayLike = __webpack_require__(/*! ../internals/length-of-array-like */ "./node_modules/core-js/internals/length-of-array-like.js");
	var arraySpeciesCreate = __webpack_require__(/*! ../internals/array-species-create */ "./node_modules/core-js/internals/array-species-create.js");

	var push = uncurryThis([].push);

	// `Array.prototype.{ forEach, map, filter, some, every, find, findIndex, filterReject }` methods implementation
	var createMethod = function (TYPE) {
	  var IS_MAP = TYPE === 1;
	  var IS_FILTER = TYPE === 2;
	  var IS_SOME = TYPE === 3;
	  var IS_EVERY = TYPE === 4;
	  var IS_FIND_INDEX = TYPE === 6;
	  var IS_FILTER_REJECT = TYPE === 7;
	  var NO_HOLES = TYPE === 5 || IS_FIND_INDEX;
	  return function ($this, callbackfn, that, specificCreate) {
	    var O = toObject($this);
	    var self = IndexedObject(O);
	    var length = lengthOfArrayLike(self);
	    var boundFunction = bind(callbackfn, that);
	    var index = 0;
	    var create = specificCreate || arraySpeciesCreate;
	    var target = IS_MAP ? create($this, length) : IS_FILTER || IS_FILTER_REJECT ? create($this, 0) : undefined;
	    var value, result;
	    for (;length > index; index++) if (NO_HOLES || index in self) {
	      value = self[index];
	      result = boundFunction(value, index, O);
	      if (TYPE) {
	        if (IS_MAP) target[index] = result; // map
	        else if (result) switch (TYPE) {
	          case 3: return true;              // some
	          case 5: return value;             // find
	          case 6: return index;             // findIndex
	          case 2: push(target, value);      // filter
	        } else switch (TYPE) {
	          case 4: return false;             // every
	          case 7: push(target, value);      // filterReject
	        }
	      }
	    }
	    return IS_FIND_INDEX ? -1 : IS_SOME || IS_EVERY ? IS_EVERY : target;
	  };
	};

	module.exports = {
	  // `Array.prototype.forEach` method
	  // https://tc39.es/ecma262/#sec-array.prototype.foreach
	  forEach: createMethod(0),
	  // `Array.prototype.map` method
	  // https://tc39.es/ecma262/#sec-array.prototype.map
	  map: createMethod(1),
	  // `Array.prototype.filter` method
	  // https://tc39.es/ecma262/#sec-array.prototype.filter
	  filter: createMethod(2),
	  // `Array.prototype.some` method
	  // https://tc39.es/ecma262/#sec-array.prototype.some
	  some: createMethod(3),
	  // `Array.prototype.every` method
	  // https://tc39.es/ecma262/#sec-array.prototype.every
	  every: createMethod(4),
	  // `Array.prototype.find` method
	  // https://tc39.es/ecma262/#sec-array.prototype.find
	  find: createMethod(5),
	  // `Array.prototype.findIndex` method
	  // https://tc39.es/ecma262/#sec-array.prototype.findIndex
	  findIndex: createMethod(6),
	  // `Array.prototype.filterReject` method
	  // https://github.com/tc39/proposal-array-filtering
	  filterReject: createMethod(7)
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/array-method-has-species-support.js":
	/*!****************************************************************************!*\
	  !*** ./node_modules/core-js/internals/array-method-has-species-support.js ***!
	  \****************************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/core-js/internals/fails.js");
	var wellKnownSymbol = __webpack_require__(/*! ../internals/well-known-symbol */ "./node_modules/core-js/internals/well-known-symbol.js");
	var V8_VERSION = __webpack_require__(/*! ../internals/environment-v8-version */ "./node_modules/core-js/internals/environment-v8-version.js");

	var SPECIES = wellKnownSymbol('species');

	module.exports = function (METHOD_NAME) {
	  // We can't use this feature detection in V8 since it causes
	  // deoptimization and serious performance degradation
	  // https://github.com/zloirock/core-js/issues/677
	  return V8_VERSION >= 51 || !fails(function () {
	    var array = [];
	    var constructor = array.constructor = {};
	    constructor[SPECIES] = function () {
	      return { foo: 1 };
	    };
	    return array[METHOD_NAME](Boolean).foo !== 1;
	  });
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/array-method-is-strict.js":
	/*!******************************************************************!*\
	  !*** ./node_modules/core-js/internals/array-method-is-strict.js ***!
	  \******************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/core-js/internals/fails.js");

	module.exports = function (METHOD_NAME, argument) {
	  var method = [][METHOD_NAME];
	  return !!method && fails(function () {
	    // eslint-disable-next-line no-useless-call -- required for testing
	    method.call(null, argument || function () { return 1; }, 1);
	  });
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/array-slice.js":
	/*!*******************************************************!*\
	  !*** ./node_modules/core-js/internals/array-slice.js ***!
	  \*******************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/core-js/internals/function-uncurry-this.js");

	module.exports = uncurryThis([].slice);


	/***/ }),

	/***/ "./node_modules/core-js/internals/array-species-constructor.js":
	/*!*********************************************************************!*\
	  !*** ./node_modules/core-js/internals/array-species-constructor.js ***!
	  \*********************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var isArray = __webpack_require__(/*! ../internals/is-array */ "./node_modules/core-js/internals/is-array.js");
	var isConstructor = __webpack_require__(/*! ../internals/is-constructor */ "./node_modules/core-js/internals/is-constructor.js");
	var isObject = __webpack_require__(/*! ../internals/is-object */ "./node_modules/core-js/internals/is-object.js");
	var wellKnownSymbol = __webpack_require__(/*! ../internals/well-known-symbol */ "./node_modules/core-js/internals/well-known-symbol.js");

	var SPECIES = wellKnownSymbol('species');
	var $Array = Array;

	// a part of `ArraySpeciesCreate` abstract operation
	// https://tc39.es/ecma262/#sec-arrayspeciescreate
	module.exports = function (originalArray) {
	  var C;
	  if (isArray(originalArray)) {
	    C = originalArray.constructor;
	    // cross-realm fallback
	    if (isConstructor(C) && (C === $Array || isArray(C.prototype))) C = undefined;
	    else if (isObject(C)) {
	      C = C[SPECIES];
	      if (C === null) C = undefined;
	    }
	  } return C === undefined ? $Array : C;
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/array-species-create.js":
	/*!****************************************************************!*\
	  !*** ./node_modules/core-js/internals/array-species-create.js ***!
	  \****************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var arraySpeciesConstructor = __webpack_require__(/*! ../internals/array-species-constructor */ "./node_modules/core-js/internals/array-species-constructor.js");

	// `ArraySpeciesCreate` abstract operation
	// https://tc39.es/ecma262/#sec-arrayspeciescreate
	module.exports = function (originalArray, length) {
	  return new (arraySpeciesConstructor(originalArray))(length === 0 ? 0 : length);
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/call-with-safe-iteration-closing.js":
	/*!****************************************************************************!*\
	  !*** ./node_modules/core-js/internals/call-with-safe-iteration-closing.js ***!
	  \****************************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var anObject = __webpack_require__(/*! ../internals/an-object */ "./node_modules/core-js/internals/an-object.js");
	var iteratorClose = __webpack_require__(/*! ../internals/iterator-close */ "./node_modules/core-js/internals/iterator-close.js");

	// call something on iterator step with safe closing on error
	module.exports = function (iterator, fn, value, ENTRIES) {
	  try {
	    return ENTRIES ? fn(anObject(value)[0], value[1]) : fn(value);
	  } catch (error) {
	    iteratorClose(iterator, 'throw', error);
	  }
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/check-correctness-of-iteration.js":
	/*!**************************************************************************!*\
	  !*** ./node_modules/core-js/internals/check-correctness-of-iteration.js ***!
	  \**************************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var wellKnownSymbol = __webpack_require__(/*! ../internals/well-known-symbol */ "./node_modules/core-js/internals/well-known-symbol.js");

	var ITERATOR = wellKnownSymbol('iterator');
	var SAFE_CLOSING = false;

	try {
	  var called = 0;
	  var iteratorWithReturn = {
	    next: function () {
	      return { done: !!called++ };
	    },
	    'return': function () {
	      SAFE_CLOSING = true;
	    }
	  };
	  iteratorWithReturn[ITERATOR] = function () {
	    return this;
	  };
	  // eslint-disable-next-line es/no-array-from, no-throw-literal -- required for testing
	  Array.from(iteratorWithReturn, function () { throw 2; });
	} catch (error) { /* empty */ }

	module.exports = function (exec, SKIP_CLOSING) {
	  try {
	    if (!SKIP_CLOSING && !SAFE_CLOSING) return false;
	  } catch (error) { return false; } // workaround of old WebKit + `eval` bug
	  var ITERATION_SUPPORT = false;
	  try {
	    var object = {};
	    object[ITERATOR] = function () {
	      return {
	        next: function () {
	          return { done: ITERATION_SUPPORT = true };
	        }
	      };
	    };
	    exec(object);
	  } catch (error) { /* empty */ }
	  return ITERATION_SUPPORT;
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/classof-raw.js":
	/*!*******************************************************!*\
	  !*** ./node_modules/core-js/internals/classof-raw.js ***!
	  \*******************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/core-js/internals/function-uncurry-this.js");

	var toString = uncurryThis({}.toString);
	var stringSlice = uncurryThis(''.slice);

	module.exports = function (it) {
	  return stringSlice(toString(it), 8, -1);
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/classof.js":
	/*!***************************************************!*\
	  !*** ./node_modules/core-js/internals/classof.js ***!
	  \***************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var TO_STRING_TAG_SUPPORT = __webpack_require__(/*! ../internals/to-string-tag-support */ "./node_modules/core-js/internals/to-string-tag-support.js");
	var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/core-js/internals/is-callable.js");
	var classofRaw = __webpack_require__(/*! ../internals/classof-raw */ "./node_modules/core-js/internals/classof-raw.js");
	var wellKnownSymbol = __webpack_require__(/*! ../internals/well-known-symbol */ "./node_modules/core-js/internals/well-known-symbol.js");

	var TO_STRING_TAG = wellKnownSymbol('toStringTag');
	var $Object = Object;

	// ES3 wrong here
	var CORRECT_ARGUMENTS = classofRaw(function () { return arguments; }()) === 'Arguments';

	// fallback for IE11 Script Access Denied error
	var tryGet = function (it, key) {
	  try {
	    return it[key];
	  } catch (error) { /* empty */ }
	};

	// getting tag from ES6+ `Object.prototype.toString`
	module.exports = TO_STRING_TAG_SUPPORT ? classofRaw : function (it) {
	  var O, tag, result;
	  return it === undefined ? 'Undefined' : it === null ? 'Null'
	    // @@toStringTag case
	    : typeof (tag = tryGet(O = $Object(it), TO_STRING_TAG)) == 'string' ? tag
	    // builtinTag case
	    : CORRECT_ARGUMENTS ? classofRaw(O)
	    // ES3 arguments fallback
	    : (result = classofRaw(O)) === 'Object' && isCallable(O.callee) ? 'Arguments' : result;
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/collection-strong.js":
	/*!*************************************************************!*\
	  !*** ./node_modules/core-js/internals/collection-strong.js ***!
	  \*************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var create = __webpack_require__(/*! ../internals/object-create */ "./node_modules/core-js/internals/object-create.js");
	var defineBuiltInAccessor = __webpack_require__(/*! ../internals/define-built-in-accessor */ "./node_modules/core-js/internals/define-built-in-accessor.js");
	var defineBuiltIns = __webpack_require__(/*! ../internals/define-built-ins */ "./node_modules/core-js/internals/define-built-ins.js");
	var bind = __webpack_require__(/*! ../internals/function-bind-context */ "./node_modules/core-js/internals/function-bind-context.js");
	var anInstance = __webpack_require__(/*! ../internals/an-instance */ "./node_modules/core-js/internals/an-instance.js");
	var isNullOrUndefined = __webpack_require__(/*! ../internals/is-null-or-undefined */ "./node_modules/core-js/internals/is-null-or-undefined.js");
	var iterate = __webpack_require__(/*! ../internals/iterate */ "./node_modules/core-js/internals/iterate.js");
	var defineIterator = __webpack_require__(/*! ../internals/iterator-define */ "./node_modules/core-js/internals/iterator-define.js");
	var createIterResultObject = __webpack_require__(/*! ../internals/create-iter-result-object */ "./node_modules/core-js/internals/create-iter-result-object.js");
	var setSpecies = __webpack_require__(/*! ../internals/set-species */ "./node_modules/core-js/internals/set-species.js");
	var DESCRIPTORS = __webpack_require__(/*! ../internals/descriptors */ "./node_modules/core-js/internals/descriptors.js");
	var fastKey = (__webpack_require__(/*! ../internals/internal-metadata */ "./node_modules/core-js/internals/internal-metadata.js").fastKey);
	var InternalStateModule = __webpack_require__(/*! ../internals/internal-state */ "./node_modules/core-js/internals/internal-state.js");

	var setInternalState = InternalStateModule.set;
	var internalStateGetterFor = InternalStateModule.getterFor;

	module.exports = {
	  getConstructor: function (wrapper, CONSTRUCTOR_NAME, IS_MAP, ADDER) {
	    var Constructor = wrapper(function (that, iterable) {
	      anInstance(that, Prototype);
	      setInternalState(that, {
	        type: CONSTRUCTOR_NAME,
	        index: create(null),
	        first: null,
	        last: null,
	        size: 0
	      });
	      if (!DESCRIPTORS) that.size = 0;
	      if (!isNullOrUndefined(iterable)) iterate(iterable, that[ADDER], { that: that, AS_ENTRIES: IS_MAP });
	    });

	    var Prototype = Constructor.prototype;

	    var getInternalState = internalStateGetterFor(CONSTRUCTOR_NAME);

	    var define = function (that, key, value) {
	      var state = getInternalState(that);
	      var entry = getEntry(that, key);
	      var previous, index;
	      // change existing entry
	      if (entry) {
	        entry.value = value;
	      // create new entry
	      } else {
	        state.last = entry = {
	          index: index = fastKey(key, true),
	          key: key,
	          value: value,
	          previous: previous = state.last,
	          next: null,
	          removed: false
	        };
	        if (!state.first) state.first = entry;
	        if (previous) previous.next = entry;
	        if (DESCRIPTORS) state.size++;
	        else that.size++;
	        // add to index
	        if (index !== 'F') state.index[index] = entry;
	      } return that;
	    };

	    var getEntry = function (that, key) {
	      var state = getInternalState(that);
	      // fast case
	      var index = fastKey(key);
	      var entry;
	      if (index !== 'F') return state.index[index];
	      // frozen object case
	      for (entry = state.first; entry; entry = entry.next) {
	        if (entry.key === key) return entry;
	      }
	    };

	    defineBuiltIns(Prototype, {
	      // `{ Map, Set }.prototype.clear()` methods
	      // https://tc39.es/ecma262/#sec-map.prototype.clear
	      // https://tc39.es/ecma262/#sec-set.prototype.clear
	      clear: function clear() {
	        var that = this;
	        var state = getInternalState(that);
	        var entry = state.first;
	        while (entry) {
	          entry.removed = true;
	          if (entry.previous) entry.previous = entry.previous.next = null;
	          entry = entry.next;
	        }
	        state.first = state.last = null;
	        state.index = create(null);
	        if (DESCRIPTORS) state.size = 0;
	        else that.size = 0;
	      },
	      // `{ Map, Set }.prototype.delete(key)` methods
	      // https://tc39.es/ecma262/#sec-map.prototype.delete
	      // https://tc39.es/ecma262/#sec-set.prototype.delete
	      'delete': function (key) {
	        var that = this;
	        var state = getInternalState(that);
	        var entry = getEntry(that, key);
	        if (entry) {
	          var next = entry.next;
	          var prev = entry.previous;
	          delete state.index[entry.index];
	          entry.removed = true;
	          if (prev) prev.next = next;
	          if (next) next.previous = prev;
	          if (state.first === entry) state.first = next;
	          if (state.last === entry) state.last = prev;
	          if (DESCRIPTORS) state.size--;
	          else that.size--;
	        } return !!entry;
	      },
	      // `{ Map, Set }.prototype.forEach(callbackfn, thisArg = undefined)` methods
	      // https://tc39.es/ecma262/#sec-map.prototype.foreach
	      // https://tc39.es/ecma262/#sec-set.prototype.foreach
	      forEach: function forEach(callbackfn /* , that = undefined */) {
	        var state = getInternalState(this);
	        var boundFunction = bind(callbackfn, arguments.length > 1 ? arguments[1] : undefined);
	        var entry;
	        while (entry = entry ? entry.next : state.first) {
	          boundFunction(entry.value, entry.key, this);
	          // revert to the last existing entry
	          while (entry && entry.removed) entry = entry.previous;
	        }
	      },
	      // `{ Map, Set}.prototype.has(key)` methods
	      // https://tc39.es/ecma262/#sec-map.prototype.has
	      // https://tc39.es/ecma262/#sec-set.prototype.has
	      has: function has(key) {
	        return !!getEntry(this, key);
	      }
	    });

	    defineBuiltIns(Prototype, IS_MAP ? {
	      // `Map.prototype.get(key)` method
	      // https://tc39.es/ecma262/#sec-map.prototype.get
	      get: function get(key) {
	        var entry = getEntry(this, key);
	        return entry && entry.value;
	      },
	      // `Map.prototype.set(key, value)` method
	      // https://tc39.es/ecma262/#sec-map.prototype.set
	      set: function set(key, value) {
	        return define(this, key === 0 ? 0 : key, value);
	      }
	    } : {
	      // `Set.prototype.add(value)` method
	      // https://tc39.es/ecma262/#sec-set.prototype.add
	      add: function add(value) {
	        return define(this, value = value === 0 ? 0 : value, value);
	      }
	    });
	    if (DESCRIPTORS) defineBuiltInAccessor(Prototype, 'size', {
	      configurable: true,
	      get: function () {
	        return getInternalState(this).size;
	      }
	    });
	    return Constructor;
	  },
	  setStrong: function (Constructor, CONSTRUCTOR_NAME, IS_MAP) {
	    var ITERATOR_NAME = CONSTRUCTOR_NAME + ' Iterator';
	    var getInternalCollectionState = internalStateGetterFor(CONSTRUCTOR_NAME);
	    var getInternalIteratorState = internalStateGetterFor(ITERATOR_NAME);
	    // `{ Map, Set }.prototype.{ keys, values, entries, @@iterator }()` methods
	    // https://tc39.es/ecma262/#sec-map.prototype.entries
	    // https://tc39.es/ecma262/#sec-map.prototype.keys
	    // https://tc39.es/ecma262/#sec-map.prototype.values
	    // https://tc39.es/ecma262/#sec-map.prototype-@@iterator
	    // https://tc39.es/ecma262/#sec-set.prototype.entries
	    // https://tc39.es/ecma262/#sec-set.prototype.keys
	    // https://tc39.es/ecma262/#sec-set.prototype.values
	    // https://tc39.es/ecma262/#sec-set.prototype-@@iterator
	    defineIterator(Constructor, CONSTRUCTOR_NAME, function (iterated, kind) {
	      setInternalState(this, {
	        type: ITERATOR_NAME,
	        target: iterated,
	        state: getInternalCollectionState(iterated),
	        kind: kind,
	        last: null
	      });
	    }, function () {
	      var state = getInternalIteratorState(this);
	      var kind = state.kind;
	      var entry = state.last;
	      // revert to the last existing entry
	      while (entry && entry.removed) entry = entry.previous;
	      // get next entry
	      if (!state.target || !(state.last = entry = entry ? entry.next : state.state.first)) {
	        // or finish the iteration
	        state.target = null;
	        return createIterResultObject(undefined, true);
	      }
	      // return step by kind
	      if (kind === 'keys') return createIterResultObject(entry.key, false);
	      if (kind === 'values') return createIterResultObject(entry.value, false);
	      return createIterResultObject([entry.key, entry.value], false);
	    }, IS_MAP ? 'entries' : 'values', !IS_MAP, true);

	    // `{ Map, Set }.prototype[@@species]` accessors
	    // https://tc39.es/ecma262/#sec-get-map-@@species
	    // https://tc39.es/ecma262/#sec-get-set-@@species
	    setSpecies(CONSTRUCTOR_NAME);
	  }
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/collection.js":
	/*!******************************************************!*\
	  !*** ./node_modules/core-js/internals/collection.js ***!
	  \******************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
	var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/core-js/internals/global-this.js");
	var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/core-js/internals/function-uncurry-this.js");
	var isForced = __webpack_require__(/*! ../internals/is-forced */ "./node_modules/core-js/internals/is-forced.js");
	var defineBuiltIn = __webpack_require__(/*! ../internals/define-built-in */ "./node_modules/core-js/internals/define-built-in.js");
	var InternalMetadataModule = __webpack_require__(/*! ../internals/internal-metadata */ "./node_modules/core-js/internals/internal-metadata.js");
	var iterate = __webpack_require__(/*! ../internals/iterate */ "./node_modules/core-js/internals/iterate.js");
	var anInstance = __webpack_require__(/*! ../internals/an-instance */ "./node_modules/core-js/internals/an-instance.js");
	var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/core-js/internals/is-callable.js");
	var isNullOrUndefined = __webpack_require__(/*! ../internals/is-null-or-undefined */ "./node_modules/core-js/internals/is-null-or-undefined.js");
	var isObject = __webpack_require__(/*! ../internals/is-object */ "./node_modules/core-js/internals/is-object.js");
	var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/core-js/internals/fails.js");
	var checkCorrectnessOfIteration = __webpack_require__(/*! ../internals/check-correctness-of-iteration */ "./node_modules/core-js/internals/check-correctness-of-iteration.js");
	var setToStringTag = __webpack_require__(/*! ../internals/set-to-string-tag */ "./node_modules/core-js/internals/set-to-string-tag.js");
	var inheritIfRequired = __webpack_require__(/*! ../internals/inherit-if-required */ "./node_modules/core-js/internals/inherit-if-required.js");

	module.exports = function (CONSTRUCTOR_NAME, wrapper, common) {
	  var IS_MAP = CONSTRUCTOR_NAME.indexOf('Map') !== -1;
	  var IS_WEAK = CONSTRUCTOR_NAME.indexOf('Weak') !== -1;
	  var ADDER = IS_MAP ? 'set' : 'add';
	  var NativeConstructor = globalThis[CONSTRUCTOR_NAME];
	  var NativePrototype = NativeConstructor && NativeConstructor.prototype;
	  var Constructor = NativeConstructor;
	  var exported = {};

	  var fixMethod = function (KEY) {
	    var uncurriedNativeMethod = uncurryThis(NativePrototype[KEY]);
	    defineBuiltIn(NativePrototype, KEY,
	      KEY === 'add' ? function add(value) {
	        uncurriedNativeMethod(this, value === 0 ? 0 : value);
	        return this;
	      } : KEY === 'delete' ? function (key) {
	        return IS_WEAK && !isObject(key) ? false : uncurriedNativeMethod(this, key === 0 ? 0 : key);
	      } : KEY === 'get' ? function get(key) {
	        return IS_WEAK && !isObject(key) ? undefined : uncurriedNativeMethod(this, key === 0 ? 0 : key);
	      } : KEY === 'has' ? function has(key) {
	        return IS_WEAK && !isObject(key) ? false : uncurriedNativeMethod(this, key === 0 ? 0 : key);
	      } : function set(key, value) {
	        uncurriedNativeMethod(this, key === 0 ? 0 : key, value);
	        return this;
	      }
	    );
	  };

	  var REPLACE = isForced(
	    CONSTRUCTOR_NAME,
	    !isCallable(NativeConstructor) || !(IS_WEAK || NativePrototype.forEach && !fails(function () {
	      new NativeConstructor().entries().next();
	    }))
	  );

	  if (REPLACE) {
	    // create collection constructor
	    Constructor = common.getConstructor(wrapper, CONSTRUCTOR_NAME, IS_MAP, ADDER);
	    InternalMetadataModule.enable();
	  } else if (isForced(CONSTRUCTOR_NAME, true)) {
	    var instance = new Constructor();
	    // early implementations not supports chaining
	    var HASNT_CHAINING = instance[ADDER](IS_WEAK ? {} : -0, 1) !== instance;
	    // V8 ~ Chromium 40- weak-collections throws on primitives, but should return false
	    var THROWS_ON_PRIMITIVES = fails(function () { instance.has(1); });
	    // most early implementations doesn't supports iterables, most modern - not close it correctly
	    // eslint-disable-next-line no-new -- required for testing
	    var ACCEPT_ITERABLES = checkCorrectnessOfIteration(function (iterable) { new NativeConstructor(iterable); });
	    // for early implementations -0 and +0 not the same
	    var BUGGY_ZERO = !IS_WEAK && fails(function () {
	      // V8 ~ Chromium 42- fails only with 5+ elements
	      var $instance = new NativeConstructor();
	      var index = 5;
	      while (index--) $instance[ADDER](index, index);
	      return !$instance.has(-0);
	    });

	    if (!ACCEPT_ITERABLES) {
	      Constructor = wrapper(function (dummy, iterable) {
	        anInstance(dummy, NativePrototype);
	        var that = inheritIfRequired(new NativeConstructor(), dummy, Constructor);
	        if (!isNullOrUndefined(iterable)) iterate(iterable, that[ADDER], { that: that, AS_ENTRIES: IS_MAP });
	        return that;
	      });
	      Constructor.prototype = NativePrototype;
	      NativePrototype.constructor = Constructor;
	    }

	    if (THROWS_ON_PRIMITIVES || BUGGY_ZERO) {
	      fixMethod('delete');
	      fixMethod('has');
	      IS_MAP && fixMethod('get');
	    }

	    if (BUGGY_ZERO || HASNT_CHAINING) fixMethod(ADDER);

	    // weak collections should not contains .clear method
	    if (IS_WEAK && NativePrototype.clear) delete NativePrototype.clear;
	  }

	  exported[CONSTRUCTOR_NAME] = Constructor;
	  $({ global: true, constructor: true, forced: Constructor !== NativeConstructor }, exported);

	  setToStringTag(Constructor, CONSTRUCTOR_NAME);

	  if (!IS_WEAK) common.setStrong(Constructor, CONSTRUCTOR_NAME, IS_MAP);

	  return Constructor;
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/copy-constructor-properties.js":
	/*!***********************************************************************!*\
	  !*** ./node_modules/core-js/internals/copy-constructor-properties.js ***!
	  \***********************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var hasOwn = __webpack_require__(/*! ../internals/has-own-property */ "./node_modules/core-js/internals/has-own-property.js");
	var ownKeys = __webpack_require__(/*! ../internals/own-keys */ "./node_modules/core-js/internals/own-keys.js");
	var getOwnPropertyDescriptorModule = __webpack_require__(/*! ../internals/object-get-own-property-descriptor */ "./node_modules/core-js/internals/object-get-own-property-descriptor.js");
	var definePropertyModule = __webpack_require__(/*! ../internals/object-define-property */ "./node_modules/core-js/internals/object-define-property.js");

	module.exports = function (target, source, exceptions) {
	  var keys = ownKeys(source);
	  var defineProperty = definePropertyModule.f;
	  var getOwnPropertyDescriptor = getOwnPropertyDescriptorModule.f;
	  for (var i = 0; i < keys.length; i++) {
	    var key = keys[i];
	    if (!hasOwn(target, key) && !(exceptions && hasOwn(exceptions, key))) {
	      defineProperty(target, key, getOwnPropertyDescriptor(source, key));
	    }
	  }
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/correct-prototype-getter.js":
	/*!********************************************************************!*\
	  !*** ./node_modules/core-js/internals/correct-prototype-getter.js ***!
	  \********************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/core-js/internals/fails.js");

	module.exports = !fails(function () {
	  function F() { /* empty */ }
	  F.prototype.constructor = null;
	  // eslint-disable-next-line es/no-object-getprototypeof -- required for testing
	  return Object.getPrototypeOf(new F()) !== F.prototype;
	});


	/***/ }),

	/***/ "./node_modules/core-js/internals/create-html.js":
	/*!*******************************************************!*\
	  !*** ./node_modules/core-js/internals/create-html.js ***!
	  \*******************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/core-js/internals/function-uncurry-this.js");
	var requireObjectCoercible = __webpack_require__(/*! ../internals/require-object-coercible */ "./node_modules/core-js/internals/require-object-coercible.js");
	var toString = __webpack_require__(/*! ../internals/to-string */ "./node_modules/core-js/internals/to-string.js");

	var quot = /"/g;
	var replace = uncurryThis(''.replace);

	// `CreateHTML` abstract operation
	// https://tc39.es/ecma262/#sec-createhtml
	module.exports = function (string, tag, attribute, value) {
	  var S = toString(requireObjectCoercible(string));
	  var p1 = '<' + tag;
	  if (attribute !== '') p1 += ' ' + attribute + '="' + replace(toString(value), quot, '&quot;') + '"';
	  return p1 + '>' + S + '</' + tag + '>';
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/create-iter-result-object.js":
	/*!*********************************************************************!*\
	  !*** ./node_modules/core-js/internals/create-iter-result-object.js ***!
	  \*********************************************************************/
	/***/ (function(module) {


	// `CreateIterResultObject` abstract operation
	// https://tc39.es/ecma262/#sec-createiterresultobject
	module.exports = function (value, done) {
	  return { value: value, done: done };
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/create-non-enumerable-property.js":
	/*!**************************************************************************!*\
	  !*** ./node_modules/core-js/internals/create-non-enumerable-property.js ***!
	  \**************************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var DESCRIPTORS = __webpack_require__(/*! ../internals/descriptors */ "./node_modules/core-js/internals/descriptors.js");
	var definePropertyModule = __webpack_require__(/*! ../internals/object-define-property */ "./node_modules/core-js/internals/object-define-property.js");
	var createPropertyDescriptor = __webpack_require__(/*! ../internals/create-property-descriptor */ "./node_modules/core-js/internals/create-property-descriptor.js");

	module.exports = DESCRIPTORS ? function (object, key, value) {
	  return definePropertyModule.f(object, key, createPropertyDescriptor(1, value));
	} : function (object, key, value) {
	  object[key] = value;
	  return object;
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/create-property-descriptor.js":
	/*!**********************************************************************!*\
	  !*** ./node_modules/core-js/internals/create-property-descriptor.js ***!
	  \**********************************************************************/
	/***/ (function(module) {


	module.exports = function (bitmap, value) {
	  return {
	    enumerable: !(bitmap & 1),
	    configurable: !(bitmap & 2),
	    writable: !(bitmap & 4),
	    value: value
	  };
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/create-property.js":
	/*!***********************************************************!*\
	  !*** ./node_modules/core-js/internals/create-property.js ***!
	  \***********************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var DESCRIPTORS = __webpack_require__(/*! ../internals/descriptors */ "./node_modules/core-js/internals/descriptors.js");
	var definePropertyModule = __webpack_require__(/*! ../internals/object-define-property */ "./node_modules/core-js/internals/object-define-property.js");
	var createPropertyDescriptor = __webpack_require__(/*! ../internals/create-property-descriptor */ "./node_modules/core-js/internals/create-property-descriptor.js");

	module.exports = function (object, key, value) {
	  if (DESCRIPTORS) definePropertyModule.f(object, key, createPropertyDescriptor(0, value));
	  else object[key] = value;
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/define-built-in-accessor.js":
	/*!********************************************************************!*\
	  !*** ./node_modules/core-js/internals/define-built-in-accessor.js ***!
	  \********************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var makeBuiltIn = __webpack_require__(/*! ../internals/make-built-in */ "./node_modules/core-js/internals/make-built-in.js");
	var defineProperty = __webpack_require__(/*! ../internals/object-define-property */ "./node_modules/core-js/internals/object-define-property.js");

	module.exports = function (target, name, descriptor) {
	  if (descriptor.get) makeBuiltIn(descriptor.get, name, { getter: true });
	  if (descriptor.set) makeBuiltIn(descriptor.set, name, { setter: true });
	  return defineProperty.f(target, name, descriptor);
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/define-built-in.js":
	/*!***********************************************************!*\
	  !*** ./node_modules/core-js/internals/define-built-in.js ***!
	  \***********************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/core-js/internals/is-callable.js");
	var definePropertyModule = __webpack_require__(/*! ../internals/object-define-property */ "./node_modules/core-js/internals/object-define-property.js");
	var makeBuiltIn = __webpack_require__(/*! ../internals/make-built-in */ "./node_modules/core-js/internals/make-built-in.js");
	var defineGlobalProperty = __webpack_require__(/*! ../internals/define-global-property */ "./node_modules/core-js/internals/define-global-property.js");

	module.exports = function (O, key, value, options) {
	  if (!options) options = {};
	  var simple = options.enumerable;
	  var name = options.name !== undefined ? options.name : key;
	  if (isCallable(value)) makeBuiltIn(value, name, options);
	  if (options.global) {
	    if (simple) O[key] = value;
	    else defineGlobalProperty(key, value);
	  } else {
	    try {
	      if (!options.unsafe) delete O[key];
	      else if (O[key]) simple = true;
	    } catch (error) { /* empty */ }
	    if (simple) O[key] = value;
	    else definePropertyModule.f(O, key, {
	      value: value,
	      enumerable: false,
	      configurable: !options.nonConfigurable,
	      writable: !options.nonWritable
	    });
	  } return O;
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/define-built-ins.js":
	/*!************************************************************!*\
	  !*** ./node_modules/core-js/internals/define-built-ins.js ***!
	  \************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var defineBuiltIn = __webpack_require__(/*! ../internals/define-built-in */ "./node_modules/core-js/internals/define-built-in.js");

	module.exports = function (target, src, options) {
	  for (var key in src) defineBuiltIn(target, key, src[key], options);
	  return target;
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/define-global-property.js":
	/*!******************************************************************!*\
	  !*** ./node_modules/core-js/internals/define-global-property.js ***!
	  \******************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/core-js/internals/global-this.js");

	// eslint-disable-next-line es/no-object-defineproperty -- safe
	var defineProperty = Object.defineProperty;

	module.exports = function (key, value) {
	  try {
	    defineProperty(globalThis, key, { value: value, configurable: true, writable: true });
	  } catch (error) {
	    globalThis[key] = value;
	  } return value;
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/descriptors.js":
	/*!*******************************************************!*\
	  !*** ./node_modules/core-js/internals/descriptors.js ***!
	  \*******************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/core-js/internals/fails.js");

	// Detect IE8's incomplete defineProperty implementation
	module.exports = !fails(function () {
	  // eslint-disable-next-line es/no-object-defineproperty -- required for testing
	  return Object.defineProperty({}, 1, { get: function () { return 7; } })[1] !== 7;
	});


	/***/ }),

	/***/ "./node_modules/core-js/internals/document-create-element.js":
	/*!*******************************************************************!*\
	  !*** ./node_modules/core-js/internals/document-create-element.js ***!
	  \*******************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/core-js/internals/global-this.js");
	var isObject = __webpack_require__(/*! ../internals/is-object */ "./node_modules/core-js/internals/is-object.js");

	var document = globalThis.document;
	// typeof document.createElement is 'object' in old IE
	var EXISTS = isObject(document) && isObject(document.createElement);

	module.exports = function (it) {
	  return EXISTS ? document.createElement(it) : {};
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/does-not-exceed-safe-integer.js":
	/*!************************************************************************!*\
	  !*** ./node_modules/core-js/internals/does-not-exceed-safe-integer.js ***!
	  \************************************************************************/
	/***/ (function(module) {


	var $TypeError = TypeError;
	var MAX_SAFE_INTEGER = 0x1FFFFFFFFFFFFF; // 2 ** 53 - 1 == 9007199254740991

	module.exports = function (it) {
	  if (it > MAX_SAFE_INTEGER) throw $TypeError('Maximum allowed index exceeded');
	  return it;
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/dom-iterables.js":
	/*!*********************************************************!*\
	  !*** ./node_modules/core-js/internals/dom-iterables.js ***!
	  \*********************************************************/
	/***/ (function(module) {


	// iterable DOM collections
	// flag - `iterable` interface - 'entries', 'keys', 'values', 'forEach' methods
	module.exports = {
	  CSSRuleList: 0,
	  CSSStyleDeclaration: 0,
	  CSSValueList: 0,
	  ClientRectList: 0,
	  DOMRectList: 0,
	  DOMStringList: 0,
	  DOMTokenList: 1,
	  DataTransferItemList: 0,
	  FileList: 0,
	  HTMLAllCollection: 0,
	  HTMLCollection: 0,
	  HTMLFormElement: 0,
	  HTMLSelectElement: 0,
	  MediaList: 0,
	  MimeTypeArray: 0,
	  NamedNodeMap: 0,
	  NodeList: 1,
	  PaintRequestList: 0,
	  Plugin: 0,
	  PluginArray: 0,
	  SVGLengthList: 0,
	  SVGNumberList: 0,
	  SVGPathSegList: 0,
	  SVGPointList: 0,
	  SVGStringList: 0,
	  SVGTransformList: 0,
	  SourceBufferList: 0,
	  StyleSheetList: 0,
	  TextTrackCueList: 0,
	  TextTrackList: 0,
	  TouchList: 0
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/dom-token-list-prototype.js":
	/*!********************************************************************!*\
	  !*** ./node_modules/core-js/internals/dom-token-list-prototype.js ***!
	  \********************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	// in old WebKit versions, `element.classList` is not an instance of global `DOMTokenList`
	var documentCreateElement = __webpack_require__(/*! ../internals/document-create-element */ "./node_modules/core-js/internals/document-create-element.js");

	var classList = documentCreateElement('span').classList;
	var DOMTokenListPrototype = classList && classList.constructor && classList.constructor.prototype;

	module.exports = DOMTokenListPrototype === Object.prototype ? undefined : DOMTokenListPrototype;


	/***/ }),

	/***/ "./node_modules/core-js/internals/enum-bug-keys.js":
	/*!*********************************************************!*\
	  !*** ./node_modules/core-js/internals/enum-bug-keys.js ***!
	  \*********************************************************/
	/***/ (function(module) {


	// IE8- don't enum bug keys
	module.exports = [
	  'constructor',
	  'hasOwnProperty',
	  'isPrototypeOf',
	  'propertyIsEnumerable',
	  'toLocaleString',
	  'toString',
	  'valueOf'
	];


	/***/ }),

	/***/ "./node_modules/core-js/internals/environment-is-ios-pebble.js":
	/*!*********************************************************************!*\
	  !*** ./node_modules/core-js/internals/environment-is-ios-pebble.js ***!
	  \*********************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var userAgent = __webpack_require__(/*! ../internals/environment-user-agent */ "./node_modules/core-js/internals/environment-user-agent.js");

	module.exports = /ipad|iphone|ipod/i.test(userAgent) && typeof Pebble != 'undefined';


	/***/ }),

	/***/ "./node_modules/core-js/internals/environment-is-ios.js":
	/*!**************************************************************!*\
	  !*** ./node_modules/core-js/internals/environment-is-ios.js ***!
	  \**************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var userAgent = __webpack_require__(/*! ../internals/environment-user-agent */ "./node_modules/core-js/internals/environment-user-agent.js");

	// eslint-disable-next-line redos/no-vulnerable -- safe
	module.exports = /(?:ipad|iphone|ipod).*applewebkit/i.test(userAgent);


	/***/ }),

	/***/ "./node_modules/core-js/internals/environment-is-node.js":
	/*!***************************************************************!*\
	  !*** ./node_modules/core-js/internals/environment-is-node.js ***!
	  \***************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var ENVIRONMENT = __webpack_require__(/*! ../internals/environment */ "./node_modules/core-js/internals/environment.js");

	module.exports = ENVIRONMENT === 'NODE';


	/***/ }),

	/***/ "./node_modules/core-js/internals/environment-is-webos-webkit.js":
	/*!***********************************************************************!*\
	  !*** ./node_modules/core-js/internals/environment-is-webos-webkit.js ***!
	  \***********************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var userAgent = __webpack_require__(/*! ../internals/environment-user-agent */ "./node_modules/core-js/internals/environment-user-agent.js");

	module.exports = /web0s(?!.*chrome)/i.test(userAgent);


	/***/ }),

	/***/ "./node_modules/core-js/internals/environment-user-agent.js":
	/*!******************************************************************!*\
	  !*** ./node_modules/core-js/internals/environment-user-agent.js ***!
	  \******************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/core-js/internals/global-this.js");

	var navigator = globalThis.navigator;
	var userAgent = navigator && navigator.userAgent;

	module.exports = userAgent ? String(userAgent) : '';


	/***/ }),

	/***/ "./node_modules/core-js/internals/environment-v8-version.js":
	/*!******************************************************************!*\
	  !*** ./node_modules/core-js/internals/environment-v8-version.js ***!
	  \******************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/core-js/internals/global-this.js");
	var userAgent = __webpack_require__(/*! ../internals/environment-user-agent */ "./node_modules/core-js/internals/environment-user-agent.js");

	var process = globalThis.process;
	var Deno = globalThis.Deno;
	var versions = process && process.versions || Deno && Deno.version;
	var v8 = versions && versions.v8;
	var match, version;

	if (v8) {
	  match = v8.split('.');
	  // in old Chrome, versions of V8 isn't V8 = Chrome / 10
	  // but their correct versions are not interesting for us
	  version = match[0] > 0 && match[0] < 4 ? 1 : +(match[0] + match[1]);
	}

	// BrowserFS NodeJS `process` polyfill incorrectly set `.v8` to `0.0`
	// so check `userAgent` even if `.v8` exists, but 0
	if (!version && userAgent) {
	  match = userAgent.match(/Edge\/(\d+)/);
	  if (!match || match[1] >= 74) {
	    match = userAgent.match(/Chrome\/(\d+)/);
	    if (match) version = +match[1];
	  }
	}

	module.exports = version;


	/***/ }),

	/***/ "./node_modules/core-js/internals/environment.js":
	/*!*******************************************************!*\
	  !*** ./node_modules/core-js/internals/environment.js ***!
	  \*******************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	/* global Bun, Deno -- detection */
	var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/core-js/internals/global-this.js");
	var userAgent = __webpack_require__(/*! ../internals/environment-user-agent */ "./node_modules/core-js/internals/environment-user-agent.js");
	var classof = __webpack_require__(/*! ../internals/classof-raw */ "./node_modules/core-js/internals/classof-raw.js");

	var userAgentStartsWith = function (string) {
	  return userAgent.slice(0, string.length) === string;
	};

	module.exports = (function () {
	  if (userAgentStartsWith('Bun/')) return 'BUN';
	  if (userAgentStartsWith('Cloudflare-Workers')) return 'CLOUDFLARE';
	  if (userAgentStartsWith('Deno/')) return 'DENO';
	  if (userAgentStartsWith('Node.js/')) return 'NODE';
	  if (globalThis.Bun && typeof Bun.version == 'string') return 'BUN';
	  if (globalThis.Deno && typeof Deno.version == 'object') return 'DENO';
	  if (classof(globalThis.process) === 'process') return 'NODE';
	  if (globalThis.window && globalThis.document) return 'BROWSER';
	  return 'REST';
	})();


	/***/ }),

	/***/ "./node_modules/core-js/internals/export.js":
	/*!**************************************************!*\
	  !*** ./node_modules/core-js/internals/export.js ***!
	  \**************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/core-js/internals/global-this.js");
	var getOwnPropertyDescriptor = (__webpack_require__(/*! ../internals/object-get-own-property-descriptor */ "./node_modules/core-js/internals/object-get-own-property-descriptor.js").f);
	var createNonEnumerableProperty = __webpack_require__(/*! ../internals/create-non-enumerable-property */ "./node_modules/core-js/internals/create-non-enumerable-property.js");
	var defineBuiltIn = __webpack_require__(/*! ../internals/define-built-in */ "./node_modules/core-js/internals/define-built-in.js");
	var defineGlobalProperty = __webpack_require__(/*! ../internals/define-global-property */ "./node_modules/core-js/internals/define-global-property.js");
	var copyConstructorProperties = __webpack_require__(/*! ../internals/copy-constructor-properties */ "./node_modules/core-js/internals/copy-constructor-properties.js");
	var isForced = __webpack_require__(/*! ../internals/is-forced */ "./node_modules/core-js/internals/is-forced.js");

	/*
	  options.target         - name of the target object
	  options.global         - target is the global object
	  options.stat           - export as static methods of target
	  options.proto          - export as prototype methods of target
	  options.real           - real prototype method for the `pure` version
	  options.forced         - export even if the native feature is available
	  options.bind           - bind methods to the target, required for the `pure` version
	  options.wrap           - wrap constructors to preventing global pollution, required for the `pure` version
	  options.unsafe         - use the simple assignment of property instead of delete + defineProperty
	  options.sham           - add a flag to not completely full polyfills
	  options.enumerable     - export as enumerable property
	  options.dontCallGetSet - prevent calling a getter on target
	  options.name           - the .name of the function if it does not match the key
	*/
	module.exports = function (options, source) {
	  var TARGET = options.target;
	  var GLOBAL = options.global;
	  var STATIC = options.stat;
	  var FORCED, target, key, targetProperty, sourceProperty, descriptor;
	  if (GLOBAL) {
	    target = globalThis;
	  } else if (STATIC) {
	    target = globalThis[TARGET] || defineGlobalProperty(TARGET, {});
	  } else {
	    target = globalThis[TARGET] && globalThis[TARGET].prototype;
	  }
	  if (target) for (key in source) {
	    sourceProperty = source[key];
	    if (options.dontCallGetSet) {
	      descriptor = getOwnPropertyDescriptor(target, key);
	      targetProperty = descriptor && descriptor.value;
	    } else targetProperty = target[key];
	    FORCED = isForced(GLOBAL ? key : TARGET + (STATIC ? '.' : '#') + key, options.forced);
	    // contained in target
	    if (!FORCED && targetProperty !== undefined) {
	      if (typeof sourceProperty == typeof targetProperty) continue;
	      copyConstructorProperties(sourceProperty, targetProperty);
	    }
	    // add a flag to not completely full polyfills
	    if (options.sham || (targetProperty && targetProperty.sham)) {
	      createNonEnumerableProperty(sourceProperty, 'sham', true);
	    }
	    defineBuiltIn(target, key, sourceProperty, options);
	  }
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/fails.js":
	/*!*************************************************!*\
	  !*** ./node_modules/core-js/internals/fails.js ***!
	  \*************************************************/
	/***/ (function(module) {


	module.exports = function (exec) {
	  try {
	    return !!exec();
	  } catch (error) {
	    return true;
	  }
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/freezing.js":
	/*!****************************************************!*\
	  !*** ./node_modules/core-js/internals/freezing.js ***!
	  \****************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/core-js/internals/fails.js");

	module.exports = !fails(function () {
	  // eslint-disable-next-line es/no-object-isextensible, es/no-object-preventextensions -- required for testing
	  return Object.isExtensible(Object.preventExtensions({}));
	});


	/***/ }),

	/***/ "./node_modules/core-js/internals/function-apply.js":
	/*!**********************************************************!*\
	  !*** ./node_modules/core-js/internals/function-apply.js ***!
	  \**********************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var NATIVE_BIND = __webpack_require__(/*! ../internals/function-bind-native */ "./node_modules/core-js/internals/function-bind-native.js");

	var FunctionPrototype = Function.prototype;
	var apply = FunctionPrototype.apply;
	var call = FunctionPrototype.call;

	// eslint-disable-next-line es/no-function-prototype-bind, es/no-reflect -- safe
	module.exports = typeof Reflect == 'object' && Reflect.apply || (NATIVE_BIND ? call.bind(apply) : function () {
	  return call.apply(apply, arguments);
	});


	/***/ }),

	/***/ "./node_modules/core-js/internals/function-bind-context.js":
	/*!*****************************************************************!*\
	  !*** ./node_modules/core-js/internals/function-bind-context.js ***!
	  \*****************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this-clause */ "./node_modules/core-js/internals/function-uncurry-this-clause.js");
	var aCallable = __webpack_require__(/*! ../internals/a-callable */ "./node_modules/core-js/internals/a-callable.js");
	var NATIVE_BIND = __webpack_require__(/*! ../internals/function-bind-native */ "./node_modules/core-js/internals/function-bind-native.js");

	var bind = uncurryThis(uncurryThis.bind);

	// optional / simple context binding
	module.exports = function (fn, that) {
	  aCallable(fn);
	  return that === undefined ? fn : NATIVE_BIND ? bind(fn, that) : function (/* ...args */) {
	    return fn.apply(that, arguments);
	  };
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/function-bind-native.js":
	/*!****************************************************************!*\
	  !*** ./node_modules/core-js/internals/function-bind-native.js ***!
	  \****************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/core-js/internals/fails.js");

	module.exports = !fails(function () {
	  // eslint-disable-next-line es/no-function-prototype-bind -- safe
	  var test = (function () { /* empty */ }).bind();
	  // eslint-disable-next-line no-prototype-builtins -- safe
	  return typeof test != 'function' || test.hasOwnProperty('prototype');
	});


	/***/ }),

	/***/ "./node_modules/core-js/internals/function-call.js":
	/*!*********************************************************!*\
	  !*** ./node_modules/core-js/internals/function-call.js ***!
	  \*********************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var NATIVE_BIND = __webpack_require__(/*! ../internals/function-bind-native */ "./node_modules/core-js/internals/function-bind-native.js");

	var call = Function.prototype.call;
	// eslint-disable-next-line es/no-function-prototype-bind -- safe
	module.exports = NATIVE_BIND ? call.bind(call) : function () {
	  return call.apply(call, arguments);
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/function-name.js":
	/*!*********************************************************!*\
	  !*** ./node_modules/core-js/internals/function-name.js ***!
	  \*********************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var DESCRIPTORS = __webpack_require__(/*! ../internals/descriptors */ "./node_modules/core-js/internals/descriptors.js");
	var hasOwn = __webpack_require__(/*! ../internals/has-own-property */ "./node_modules/core-js/internals/has-own-property.js");

	var FunctionPrototype = Function.prototype;
	// eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
	var getDescriptor = DESCRIPTORS && Object.getOwnPropertyDescriptor;

	var EXISTS = hasOwn(FunctionPrototype, 'name');
	// additional protection from minified / mangled / dropped function names
	var PROPER = EXISTS && (function something() { /* empty */ }).name === 'something';
	var CONFIGURABLE = EXISTS && (!DESCRIPTORS || (DESCRIPTORS && getDescriptor(FunctionPrototype, 'name').configurable));

	module.exports = {
	  EXISTS: EXISTS,
	  PROPER: PROPER,
	  CONFIGURABLE: CONFIGURABLE
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/function-uncurry-this-accessor.js":
	/*!**************************************************************************!*\
	  !*** ./node_modules/core-js/internals/function-uncurry-this-accessor.js ***!
	  \**************************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/core-js/internals/function-uncurry-this.js");
	var aCallable = __webpack_require__(/*! ../internals/a-callable */ "./node_modules/core-js/internals/a-callable.js");

	module.exports = function (object, key, method) {
	  try {
	    // eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
	    return uncurryThis(aCallable(Object.getOwnPropertyDescriptor(object, key)[method]));
	  } catch (error) { /* empty */ }
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/function-uncurry-this-clause.js":
	/*!************************************************************************!*\
	  !*** ./node_modules/core-js/internals/function-uncurry-this-clause.js ***!
	  \************************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var classofRaw = __webpack_require__(/*! ../internals/classof-raw */ "./node_modules/core-js/internals/classof-raw.js");
	var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/core-js/internals/function-uncurry-this.js");

	module.exports = function (fn) {
	  // Nashorn bug:
	  //   https://github.com/zloirock/core-js/issues/1128
	  //   https://github.com/zloirock/core-js/issues/1130
	  if (classofRaw(fn) === 'Function') return uncurryThis(fn);
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/function-uncurry-this.js":
	/*!*****************************************************************!*\
	  !*** ./node_modules/core-js/internals/function-uncurry-this.js ***!
	  \*****************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var NATIVE_BIND = __webpack_require__(/*! ../internals/function-bind-native */ "./node_modules/core-js/internals/function-bind-native.js");

	var FunctionPrototype = Function.prototype;
	var call = FunctionPrototype.call;
	// eslint-disable-next-line es/no-function-prototype-bind -- safe
	var uncurryThisWithBind = NATIVE_BIND && FunctionPrototype.bind.bind(call, call);

	module.exports = NATIVE_BIND ? uncurryThisWithBind : function (fn) {
	  return function () {
	    return call.apply(fn, arguments);
	  };
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/get-built-in.js":
	/*!********************************************************!*\
	  !*** ./node_modules/core-js/internals/get-built-in.js ***!
	  \********************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/core-js/internals/global-this.js");
	var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/core-js/internals/is-callable.js");

	var aFunction = function (argument) {
	  return isCallable(argument) ? argument : undefined;
	};

	module.exports = function (namespace, method) {
	  return arguments.length < 2 ? aFunction(globalThis[namespace]) : globalThis[namespace] && globalThis[namespace][method];
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/get-iterator-direct.js":
	/*!***************************************************************!*\
	  !*** ./node_modules/core-js/internals/get-iterator-direct.js ***!
	  \***************************************************************/
	/***/ (function(module) {


	// `GetIteratorDirect(obj)` abstract operation
	// https://tc39.es/ecma262/#sec-getiteratordirect
	module.exports = function (obj) {
	  return {
	    iterator: obj,
	    next: obj.next,
	    done: false
	  };
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/get-iterator-method.js":
	/*!***************************************************************!*\
	  !*** ./node_modules/core-js/internals/get-iterator-method.js ***!
	  \***************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var classof = __webpack_require__(/*! ../internals/classof */ "./node_modules/core-js/internals/classof.js");
	var getMethod = __webpack_require__(/*! ../internals/get-method */ "./node_modules/core-js/internals/get-method.js");
	var isNullOrUndefined = __webpack_require__(/*! ../internals/is-null-or-undefined */ "./node_modules/core-js/internals/is-null-or-undefined.js");
	var Iterators = __webpack_require__(/*! ../internals/iterators */ "./node_modules/core-js/internals/iterators.js");
	var wellKnownSymbol = __webpack_require__(/*! ../internals/well-known-symbol */ "./node_modules/core-js/internals/well-known-symbol.js");

	var ITERATOR = wellKnownSymbol('iterator');

	module.exports = function (it) {
	  if (!isNullOrUndefined(it)) return getMethod(it, ITERATOR)
	    || getMethod(it, '@@iterator')
	    || Iterators[classof(it)];
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/get-iterator.js":
	/*!********************************************************!*\
	  !*** ./node_modules/core-js/internals/get-iterator.js ***!
	  \********************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var call = __webpack_require__(/*! ../internals/function-call */ "./node_modules/core-js/internals/function-call.js");
	var aCallable = __webpack_require__(/*! ../internals/a-callable */ "./node_modules/core-js/internals/a-callable.js");
	var anObject = __webpack_require__(/*! ../internals/an-object */ "./node_modules/core-js/internals/an-object.js");
	var tryToString = __webpack_require__(/*! ../internals/try-to-string */ "./node_modules/core-js/internals/try-to-string.js");
	var getIteratorMethod = __webpack_require__(/*! ../internals/get-iterator-method */ "./node_modules/core-js/internals/get-iterator-method.js");

	var $TypeError = TypeError;

	module.exports = function (argument, usingIterator) {
	  var iteratorMethod = arguments.length < 2 ? getIteratorMethod(argument) : usingIterator;
	  if (aCallable(iteratorMethod)) return anObject(call(iteratorMethod, argument));
	  throw new $TypeError(tryToString(argument) + ' is not iterable');
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/get-json-replacer-function.js":
	/*!**********************************************************************!*\
	  !*** ./node_modules/core-js/internals/get-json-replacer-function.js ***!
	  \**********************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/core-js/internals/function-uncurry-this.js");
	var isArray = __webpack_require__(/*! ../internals/is-array */ "./node_modules/core-js/internals/is-array.js");
	var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/core-js/internals/is-callable.js");
	var classof = __webpack_require__(/*! ../internals/classof-raw */ "./node_modules/core-js/internals/classof-raw.js");
	var toString = __webpack_require__(/*! ../internals/to-string */ "./node_modules/core-js/internals/to-string.js");

	var push = uncurryThis([].push);

	module.exports = function (replacer) {
	  if (isCallable(replacer)) return replacer;
	  if (!isArray(replacer)) return;
	  var rawLength = replacer.length;
	  var keys = [];
	  for (var i = 0; i < rawLength; i++) {
	    var element = replacer[i];
	    if (typeof element == 'string') push(keys, element);
	    else if (typeof element == 'number' || classof(element) === 'Number' || classof(element) === 'String') push(keys, toString(element));
	  }
	  var keysLength = keys.length;
	  var root = true;
	  return function (key, value) {
	    if (root) {
	      root = false;
	      return value;
	    }
	    if (isArray(this)) return value;
	    for (var j = 0; j < keysLength; j++) if (keys[j] === key) return value;
	  };
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/get-method.js":
	/*!******************************************************!*\
	  !*** ./node_modules/core-js/internals/get-method.js ***!
	  \******************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var aCallable = __webpack_require__(/*! ../internals/a-callable */ "./node_modules/core-js/internals/a-callable.js");
	var isNullOrUndefined = __webpack_require__(/*! ../internals/is-null-or-undefined */ "./node_modules/core-js/internals/is-null-or-undefined.js");

	// `GetMethod` abstract operation
	// https://tc39.es/ecma262/#sec-getmethod
	module.exports = function (V, P) {
	  var func = V[P];
	  return isNullOrUndefined(func) ? undefined : aCallable(func);
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/get-set-record.js":
	/*!**********************************************************!*\
	  !*** ./node_modules/core-js/internals/get-set-record.js ***!
	  \**********************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var aCallable = __webpack_require__(/*! ../internals/a-callable */ "./node_modules/core-js/internals/a-callable.js");
	var anObject = __webpack_require__(/*! ../internals/an-object */ "./node_modules/core-js/internals/an-object.js");
	var call = __webpack_require__(/*! ../internals/function-call */ "./node_modules/core-js/internals/function-call.js");
	var toIntegerOrInfinity = __webpack_require__(/*! ../internals/to-integer-or-infinity */ "./node_modules/core-js/internals/to-integer-or-infinity.js");
	var getIteratorDirect = __webpack_require__(/*! ../internals/get-iterator-direct */ "./node_modules/core-js/internals/get-iterator-direct.js");

	var INVALID_SIZE = 'Invalid size';
	var $RangeError = RangeError;
	var $TypeError = TypeError;
	var max = Math.max;

	var SetRecord = function (set, intSize) {
	  this.set = set;
	  this.size = max(intSize, 0);
	  this.has = aCallable(set.has);
	  this.keys = aCallable(set.keys);
	};

	SetRecord.prototype = {
	  getIterator: function () {
	    return getIteratorDirect(anObject(call(this.keys, this.set)));
	  },
	  includes: function (it) {
	    return call(this.has, this.set, it);
	  }
	};

	// `GetSetRecord` abstract operation
	// https://tc39.es/proposal-set-methods/#sec-getsetrecord
	module.exports = function (obj) {
	  anObject(obj);
	  var numSize = +obj.size;
	  // NOTE: If size is undefined, then numSize will be NaN
	  // eslint-disable-next-line no-self-compare -- NaN check
	  if (numSize !== numSize) throw new $TypeError(INVALID_SIZE);
	  var intSize = toIntegerOrInfinity(numSize);
	  if (intSize < 0) throw new $RangeError(INVALID_SIZE);
	  return new SetRecord(obj, intSize);
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/global-this.js":
	/*!*******************************************************!*\
	  !*** ./node_modules/core-js/internals/global-this.js ***!
	  \*******************************************************/
	/***/ (function(module) {


	var check = function (it) {
	  return it && it.Math === Math && it;
	};

	// https://github.com/zloirock/core-js/issues/86#issuecomment-115759028
	module.exports =
	  // eslint-disable-next-line es/no-global-this -- safe
	  check(typeof globalThis == 'object' && globalThis) ||
	  check("undefined" == 'object') ||
	  // eslint-disable-next-line no-restricted-globals -- safe
	  check(typeof self == 'object' && self) ||
	  check(typeof commonjsGlobal == 'object' && commonjsGlobal) ||
	  check(typeof this == 'object' && this) ||
	  // eslint-disable-next-line no-new-func -- fallback
	  (function () { return this; })() || Function('return this')();


	/***/ }),

	/***/ "./node_modules/core-js/internals/has-own-property.js":
	/*!************************************************************!*\
	  !*** ./node_modules/core-js/internals/has-own-property.js ***!
	  \************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/core-js/internals/function-uncurry-this.js");
	var toObject = __webpack_require__(/*! ../internals/to-object */ "./node_modules/core-js/internals/to-object.js");

	var hasOwnProperty = uncurryThis({}.hasOwnProperty);

	// `HasOwnProperty` abstract operation
	// https://tc39.es/ecma262/#sec-hasownproperty
	// eslint-disable-next-line es/no-object-hasown -- safe
	module.exports = Object.hasOwn || function hasOwn(it, key) {
	  return hasOwnProperty(toObject(it), key);
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/hidden-keys.js":
	/*!*******************************************************!*\
	  !*** ./node_modules/core-js/internals/hidden-keys.js ***!
	  \*******************************************************/
	/***/ (function(module) {


	module.exports = {};


	/***/ }),

	/***/ "./node_modules/core-js/internals/host-report-errors.js":
	/*!**************************************************************!*\
	  !*** ./node_modules/core-js/internals/host-report-errors.js ***!
	  \**************************************************************/
	/***/ (function(module) {


	module.exports = function (a, b) {
	  try {
	    // eslint-disable-next-line no-console -- safe
	    arguments.length === 1 ? console.error(a) : console.error(a, b);
	  } catch (error) { /* empty */ }
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/html.js":
	/*!************************************************!*\
	  !*** ./node_modules/core-js/internals/html.js ***!
	  \************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var getBuiltIn = __webpack_require__(/*! ../internals/get-built-in */ "./node_modules/core-js/internals/get-built-in.js");

	module.exports = getBuiltIn('document', 'documentElement');


	/***/ }),

	/***/ "./node_modules/core-js/internals/ie8-dom-define.js":
	/*!**********************************************************!*\
	  !*** ./node_modules/core-js/internals/ie8-dom-define.js ***!
	  \**********************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var DESCRIPTORS = __webpack_require__(/*! ../internals/descriptors */ "./node_modules/core-js/internals/descriptors.js");
	var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/core-js/internals/fails.js");
	var createElement = __webpack_require__(/*! ../internals/document-create-element */ "./node_modules/core-js/internals/document-create-element.js");

	// Thanks to IE8 for its funny defineProperty
	module.exports = !DESCRIPTORS && !fails(function () {
	  // eslint-disable-next-line es/no-object-defineproperty -- required for testing
	  return Object.defineProperty(createElement('div'), 'a', {
	    get: function () { return 7; }
	  }).a !== 7;
	});


	/***/ }),

	/***/ "./node_modules/core-js/internals/indexed-object.js":
	/*!**********************************************************!*\
	  !*** ./node_modules/core-js/internals/indexed-object.js ***!
	  \**********************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/core-js/internals/function-uncurry-this.js");
	var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/core-js/internals/fails.js");
	var classof = __webpack_require__(/*! ../internals/classof-raw */ "./node_modules/core-js/internals/classof-raw.js");

	var $Object = Object;
	var split = uncurryThis(''.split);

	// fallback for non-array-like ES3 and non-enumerable old V8 strings
	module.exports = fails(function () {
	  // throws an error in rhino, see https://github.com/mozilla/rhino/issues/346
	  // eslint-disable-next-line no-prototype-builtins -- safe
	  return !$Object('z').propertyIsEnumerable(0);
	}) ? function (it) {
	  return classof(it) === 'String' ? split(it, '') : $Object(it);
	} : $Object;


	/***/ }),

	/***/ "./node_modules/core-js/internals/inherit-if-required.js":
	/*!***************************************************************!*\
	  !*** ./node_modules/core-js/internals/inherit-if-required.js ***!
	  \***************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/core-js/internals/is-callable.js");
	var isObject = __webpack_require__(/*! ../internals/is-object */ "./node_modules/core-js/internals/is-object.js");
	var setPrototypeOf = __webpack_require__(/*! ../internals/object-set-prototype-of */ "./node_modules/core-js/internals/object-set-prototype-of.js");

	// makes subclassing work correct for wrapped built-ins
	module.exports = function ($this, dummy, Wrapper) {
	  var NewTarget, NewTargetPrototype;
	  if (
	    // it can work only with native `setPrototypeOf`
	    setPrototypeOf &&
	    // we haven't completely correct pre-ES6 way for getting `new.target`, so use this
	    isCallable(NewTarget = dummy.constructor) &&
	    NewTarget !== Wrapper &&
	    isObject(NewTargetPrototype = NewTarget.prototype) &&
	    NewTargetPrototype !== Wrapper.prototype
	  ) setPrototypeOf($this, NewTargetPrototype);
	  return $this;
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/inspect-source.js":
	/*!**********************************************************!*\
	  !*** ./node_modules/core-js/internals/inspect-source.js ***!
	  \**********************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/core-js/internals/function-uncurry-this.js");
	var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/core-js/internals/is-callable.js");
	var store = __webpack_require__(/*! ../internals/shared-store */ "./node_modules/core-js/internals/shared-store.js");

	var functionToString = uncurryThis(Function.toString);

	// this helper broken in `core-js@3.4.1-3.4.4`, so we can't use `shared` helper
	if (!isCallable(store.inspectSource)) {
	  store.inspectSource = function (it) {
	    return functionToString(it);
	  };
	}

	module.exports = store.inspectSource;


	/***/ }),

	/***/ "./node_modules/core-js/internals/internal-metadata.js":
	/*!*************************************************************!*\
	  !*** ./node_modules/core-js/internals/internal-metadata.js ***!
	  \*************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
	var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/core-js/internals/function-uncurry-this.js");
	var hiddenKeys = __webpack_require__(/*! ../internals/hidden-keys */ "./node_modules/core-js/internals/hidden-keys.js");
	var isObject = __webpack_require__(/*! ../internals/is-object */ "./node_modules/core-js/internals/is-object.js");
	var hasOwn = __webpack_require__(/*! ../internals/has-own-property */ "./node_modules/core-js/internals/has-own-property.js");
	var defineProperty = (__webpack_require__(/*! ../internals/object-define-property */ "./node_modules/core-js/internals/object-define-property.js").f);
	var getOwnPropertyNamesModule = __webpack_require__(/*! ../internals/object-get-own-property-names */ "./node_modules/core-js/internals/object-get-own-property-names.js");
	var getOwnPropertyNamesExternalModule = __webpack_require__(/*! ../internals/object-get-own-property-names-external */ "./node_modules/core-js/internals/object-get-own-property-names-external.js");
	var isExtensible = __webpack_require__(/*! ../internals/object-is-extensible */ "./node_modules/core-js/internals/object-is-extensible.js");
	var uid = __webpack_require__(/*! ../internals/uid */ "./node_modules/core-js/internals/uid.js");
	var FREEZING = __webpack_require__(/*! ../internals/freezing */ "./node_modules/core-js/internals/freezing.js");

	var REQUIRED = false;
	var METADATA = uid('meta');
	var id = 0;

	var setMetadata = function (it) {
	  defineProperty(it, METADATA, { value: {
	    objectID: 'O' + id++, // object ID
	    weakData: {}          // weak collections IDs
	  } });
	};

	var fastKey = function (it, create) {
	  // return a primitive with prefix
	  if (!isObject(it)) return typeof it == 'symbol' ? it : (typeof it == 'string' ? 'S' : 'P') + it;
	  if (!hasOwn(it, METADATA)) {
	    // can't set metadata to uncaught frozen object
	    if (!isExtensible(it)) return 'F';
	    // not necessary to add metadata
	    if (!create) return 'E';
	    // add missing metadata
	    setMetadata(it);
	  // return object ID
	  } return it[METADATA].objectID;
	};

	var getWeakData = function (it, create) {
	  if (!hasOwn(it, METADATA)) {
	    // can't set metadata to uncaught frozen object
	    if (!isExtensible(it)) return true;
	    // not necessary to add metadata
	    if (!create) return false;
	    // add missing metadata
	    setMetadata(it);
	  // return the store of weak collections IDs
	  } return it[METADATA].weakData;
	};

	// add metadata on freeze-family methods calling
	var onFreeze = function (it) {
	  if (FREEZING && REQUIRED && isExtensible(it) && !hasOwn(it, METADATA)) setMetadata(it);
	  return it;
	};

	var enable = function () {
	  meta.enable = function () { /* empty */ };
	  REQUIRED = true;
	  var getOwnPropertyNames = getOwnPropertyNamesModule.f;
	  var splice = uncurryThis([].splice);
	  var test = {};
	  test[METADATA] = 1;

	  // prevent exposing of metadata key
	  if (getOwnPropertyNames(test).length) {
	    getOwnPropertyNamesModule.f = function (it) {
	      var result = getOwnPropertyNames(it);
	      for (var i = 0, length = result.length; i < length; i++) {
	        if (result[i] === METADATA) {
	          splice(result, i, 1);
	          break;
	        }
	      } return result;
	    };

	    $({ target: 'Object', stat: true, forced: true }, {
	      getOwnPropertyNames: getOwnPropertyNamesExternalModule.f
	    });
	  }
	};

	var meta = module.exports = {
	  enable: enable,
	  fastKey: fastKey,
	  getWeakData: getWeakData,
	  onFreeze: onFreeze
	};

	hiddenKeys[METADATA] = true;


	/***/ }),

	/***/ "./node_modules/core-js/internals/internal-state.js":
	/*!**********************************************************!*\
	  !*** ./node_modules/core-js/internals/internal-state.js ***!
	  \**********************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var NATIVE_WEAK_MAP = __webpack_require__(/*! ../internals/weak-map-basic-detection */ "./node_modules/core-js/internals/weak-map-basic-detection.js");
	var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/core-js/internals/global-this.js");
	var isObject = __webpack_require__(/*! ../internals/is-object */ "./node_modules/core-js/internals/is-object.js");
	var createNonEnumerableProperty = __webpack_require__(/*! ../internals/create-non-enumerable-property */ "./node_modules/core-js/internals/create-non-enumerable-property.js");
	var hasOwn = __webpack_require__(/*! ../internals/has-own-property */ "./node_modules/core-js/internals/has-own-property.js");
	var shared = __webpack_require__(/*! ../internals/shared-store */ "./node_modules/core-js/internals/shared-store.js");
	var sharedKey = __webpack_require__(/*! ../internals/shared-key */ "./node_modules/core-js/internals/shared-key.js");
	var hiddenKeys = __webpack_require__(/*! ../internals/hidden-keys */ "./node_modules/core-js/internals/hidden-keys.js");

	var OBJECT_ALREADY_INITIALIZED = 'Object already initialized';
	var TypeError = globalThis.TypeError;
	var WeakMap = globalThis.WeakMap;
	var set, get, has;

	var enforce = function (it) {
	  return has(it) ? get(it) : set(it, {});
	};

	var getterFor = function (TYPE) {
	  return function (it) {
	    var state;
	    if (!isObject(it) || (state = get(it)).type !== TYPE) {
	      throw new TypeError('Incompatible receiver, ' + TYPE + ' required');
	    } return state;
	  };
	};

	if (NATIVE_WEAK_MAP || shared.state) {
	  var store = shared.state || (shared.state = new WeakMap());
	  /* eslint-disable no-self-assign -- prototype methods protection */
	  store.get = store.get;
	  store.has = store.has;
	  store.set = store.set;
	  /* eslint-enable no-self-assign -- prototype methods protection */
	  set = function (it, metadata) {
	    if (store.has(it)) throw new TypeError(OBJECT_ALREADY_INITIALIZED);
	    metadata.facade = it;
	    store.set(it, metadata);
	    return metadata;
	  };
	  get = function (it) {
	    return store.get(it) || {};
	  };
	  has = function (it) {
	    return store.has(it);
	  };
	} else {
	  var STATE = sharedKey('state');
	  hiddenKeys[STATE] = true;
	  set = function (it, metadata) {
	    if (hasOwn(it, STATE)) throw new TypeError(OBJECT_ALREADY_INITIALIZED);
	    metadata.facade = it;
	    createNonEnumerableProperty(it, STATE, metadata);
	    return metadata;
	  };
	  get = function (it) {
	    return hasOwn(it, STATE) ? it[STATE] : {};
	  };
	  has = function (it) {
	    return hasOwn(it, STATE);
	  };
	}

	module.exports = {
	  set: set,
	  get: get,
	  has: has,
	  enforce: enforce,
	  getterFor: getterFor
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/is-array-iterator-method.js":
	/*!********************************************************************!*\
	  !*** ./node_modules/core-js/internals/is-array-iterator-method.js ***!
	  \********************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var wellKnownSymbol = __webpack_require__(/*! ../internals/well-known-symbol */ "./node_modules/core-js/internals/well-known-symbol.js");
	var Iterators = __webpack_require__(/*! ../internals/iterators */ "./node_modules/core-js/internals/iterators.js");

	var ITERATOR = wellKnownSymbol('iterator');
	var ArrayPrototype = Array.prototype;

	// check on default Array iterator
	module.exports = function (it) {
	  return it !== undefined && (Iterators.Array === it || ArrayPrototype[ITERATOR] === it);
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/is-array.js":
	/*!****************************************************!*\
	  !*** ./node_modules/core-js/internals/is-array.js ***!
	  \****************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var classof = __webpack_require__(/*! ../internals/classof-raw */ "./node_modules/core-js/internals/classof-raw.js");

	// `IsArray` abstract operation
	// https://tc39.es/ecma262/#sec-isarray
	// eslint-disable-next-line es/no-array-isarray -- safe
	module.exports = Array.isArray || function isArray(argument) {
	  return classof(argument) === 'Array';
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/is-callable.js":
	/*!*******************************************************!*\
	  !*** ./node_modules/core-js/internals/is-callable.js ***!
	  \*******************************************************/
	/***/ (function(module) {


	// https://tc39.es/ecma262/#sec-IsHTMLDDA-internal-slot
	var documentAll = typeof document == 'object' && document.all;

	// `IsCallable` abstract operation
	// https://tc39.es/ecma262/#sec-iscallable
	// eslint-disable-next-line unicorn/no-typeof-undefined -- required for testing
	module.exports = typeof documentAll == 'undefined' && documentAll !== undefined ? function (argument) {
	  return typeof argument == 'function' || argument === documentAll;
	} : function (argument) {
	  return typeof argument == 'function';
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/is-constructor.js":
	/*!**********************************************************!*\
	  !*** ./node_modules/core-js/internals/is-constructor.js ***!
	  \**********************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/core-js/internals/function-uncurry-this.js");
	var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/core-js/internals/fails.js");
	var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/core-js/internals/is-callable.js");
	var classof = __webpack_require__(/*! ../internals/classof */ "./node_modules/core-js/internals/classof.js");
	var getBuiltIn = __webpack_require__(/*! ../internals/get-built-in */ "./node_modules/core-js/internals/get-built-in.js");
	var inspectSource = __webpack_require__(/*! ../internals/inspect-source */ "./node_modules/core-js/internals/inspect-source.js");

	var noop = function () { /* empty */ };
	var construct = getBuiltIn('Reflect', 'construct');
	var constructorRegExp = /^\s*(?:class|function)\b/;
	var exec = uncurryThis(constructorRegExp.exec);
	var INCORRECT_TO_STRING = !constructorRegExp.test(noop);

	var isConstructorModern = function isConstructor(argument) {
	  if (!isCallable(argument)) return false;
	  try {
	    construct(noop, [], argument);
	    return true;
	  } catch (error) {
	    return false;
	  }
	};

	var isConstructorLegacy = function isConstructor(argument) {
	  if (!isCallable(argument)) return false;
	  switch (classof(argument)) {
	    case 'AsyncFunction':
	    case 'GeneratorFunction':
	    case 'AsyncGeneratorFunction': return false;
	  }
	  try {
	    // we can't check .prototype since constructors produced by .bind haven't it
	    // `Function#toString` throws on some built-it function in some legacy engines
	    // (for example, `DOMQuad` and similar in FF41-)
	    return INCORRECT_TO_STRING || !!exec(constructorRegExp, inspectSource(argument));
	  } catch (error) {
	    return true;
	  }
	};

	isConstructorLegacy.sham = true;

	// `IsConstructor` abstract operation
	// https://tc39.es/ecma262/#sec-isconstructor
	module.exports = !construct || fails(function () {
	  var called;
	  return isConstructorModern(isConstructorModern.call)
	    || !isConstructorModern(Object)
	    || !isConstructorModern(function () { called = true; })
	    || called;
	}) ? isConstructorLegacy : isConstructorModern;


	/***/ }),

	/***/ "./node_modules/core-js/internals/is-forced.js":
	/*!*****************************************************!*\
	  !*** ./node_modules/core-js/internals/is-forced.js ***!
	  \*****************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/core-js/internals/fails.js");
	var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/core-js/internals/is-callable.js");

	var replacement = /#|\.prototype\./;

	var isForced = function (feature, detection) {
	  var value = data[normalize(feature)];
	  return value === POLYFILL ? true
	    : value === NATIVE ? false
	    : isCallable(detection) ? fails(detection)
	    : !!detection;
	};

	var normalize = isForced.normalize = function (string) {
	  return String(string).replace(replacement, '.').toLowerCase();
	};

	var data = isForced.data = {};
	var NATIVE = isForced.NATIVE = 'N';
	var POLYFILL = isForced.POLYFILL = 'P';

	module.exports = isForced;


	/***/ }),

	/***/ "./node_modules/core-js/internals/is-iterable.js":
	/*!*******************************************************!*\
	  !*** ./node_modules/core-js/internals/is-iterable.js ***!
	  \*******************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var classof = __webpack_require__(/*! ../internals/classof */ "./node_modules/core-js/internals/classof.js");
	var hasOwn = __webpack_require__(/*! ../internals/has-own-property */ "./node_modules/core-js/internals/has-own-property.js");
	var isNullOrUndefined = __webpack_require__(/*! ../internals/is-null-or-undefined */ "./node_modules/core-js/internals/is-null-or-undefined.js");
	var wellKnownSymbol = __webpack_require__(/*! ../internals/well-known-symbol */ "./node_modules/core-js/internals/well-known-symbol.js");
	var Iterators = __webpack_require__(/*! ../internals/iterators */ "./node_modules/core-js/internals/iterators.js");

	var ITERATOR = wellKnownSymbol('iterator');
	var $Object = Object;

	module.exports = function (it) {
	  if (isNullOrUndefined(it)) return false;
	  var O = $Object(it);
	  return O[ITERATOR] !== undefined
	    || '@@iterator' in O
	    || hasOwn(Iterators, classof(O));
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/is-null-or-undefined.js":
	/*!****************************************************************!*\
	  !*** ./node_modules/core-js/internals/is-null-or-undefined.js ***!
	  \****************************************************************/
	/***/ (function(module) {


	// we can't use just `it == null` since of `document.all` special case
	// https://tc39.es/ecma262/#sec-IsHTMLDDA-internal-slot-aec
	module.exports = function (it) {
	  return it === null || it === undefined;
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/is-object.js":
	/*!*****************************************************!*\
	  !*** ./node_modules/core-js/internals/is-object.js ***!
	  \*****************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/core-js/internals/is-callable.js");

	module.exports = function (it) {
	  return typeof it == 'object' ? it !== null : isCallable(it);
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/is-possible-prototype.js":
	/*!*****************************************************************!*\
	  !*** ./node_modules/core-js/internals/is-possible-prototype.js ***!
	  \*****************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var isObject = __webpack_require__(/*! ../internals/is-object */ "./node_modules/core-js/internals/is-object.js");

	module.exports = function (argument) {
	  return isObject(argument) || argument === null;
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/is-pure.js":
	/*!***************************************************!*\
	  !*** ./node_modules/core-js/internals/is-pure.js ***!
	  \***************************************************/
	/***/ (function(module) {


	module.exports = false;


	/***/ }),

	/***/ "./node_modules/core-js/internals/is-symbol.js":
	/*!*****************************************************!*\
	  !*** ./node_modules/core-js/internals/is-symbol.js ***!
	  \*****************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var getBuiltIn = __webpack_require__(/*! ../internals/get-built-in */ "./node_modules/core-js/internals/get-built-in.js");
	var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/core-js/internals/is-callable.js");
	var isPrototypeOf = __webpack_require__(/*! ../internals/object-is-prototype-of */ "./node_modules/core-js/internals/object-is-prototype-of.js");
	var USE_SYMBOL_AS_UID = __webpack_require__(/*! ../internals/use-symbol-as-uid */ "./node_modules/core-js/internals/use-symbol-as-uid.js");

	var $Object = Object;

	module.exports = USE_SYMBOL_AS_UID ? function (it) {
	  return typeof it == 'symbol';
	} : function (it) {
	  var $Symbol = getBuiltIn('Symbol');
	  return isCallable($Symbol) && isPrototypeOf($Symbol.prototype, $Object(it));
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/iterate-simple.js":
	/*!**********************************************************!*\
	  !*** ./node_modules/core-js/internals/iterate-simple.js ***!
	  \**********************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var call = __webpack_require__(/*! ../internals/function-call */ "./node_modules/core-js/internals/function-call.js");

	module.exports = function (record, fn, ITERATOR_INSTEAD_OF_RECORD) {
	  var iterator = ITERATOR_INSTEAD_OF_RECORD ? record : record.iterator;
	  var next = record.next;
	  var step, result;
	  while (!(step = call(next, iterator)).done) {
	    result = fn(step.value);
	    if (result !== undefined) return result;
	  }
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/iterate.js":
	/*!***************************************************!*\
	  !*** ./node_modules/core-js/internals/iterate.js ***!
	  \***************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var bind = __webpack_require__(/*! ../internals/function-bind-context */ "./node_modules/core-js/internals/function-bind-context.js");
	var call = __webpack_require__(/*! ../internals/function-call */ "./node_modules/core-js/internals/function-call.js");
	var anObject = __webpack_require__(/*! ../internals/an-object */ "./node_modules/core-js/internals/an-object.js");
	var tryToString = __webpack_require__(/*! ../internals/try-to-string */ "./node_modules/core-js/internals/try-to-string.js");
	var isArrayIteratorMethod = __webpack_require__(/*! ../internals/is-array-iterator-method */ "./node_modules/core-js/internals/is-array-iterator-method.js");
	var lengthOfArrayLike = __webpack_require__(/*! ../internals/length-of-array-like */ "./node_modules/core-js/internals/length-of-array-like.js");
	var isPrototypeOf = __webpack_require__(/*! ../internals/object-is-prototype-of */ "./node_modules/core-js/internals/object-is-prototype-of.js");
	var getIterator = __webpack_require__(/*! ../internals/get-iterator */ "./node_modules/core-js/internals/get-iterator.js");
	var getIteratorMethod = __webpack_require__(/*! ../internals/get-iterator-method */ "./node_modules/core-js/internals/get-iterator-method.js");
	var iteratorClose = __webpack_require__(/*! ../internals/iterator-close */ "./node_modules/core-js/internals/iterator-close.js");

	var $TypeError = TypeError;

	var Result = function (stopped, result) {
	  this.stopped = stopped;
	  this.result = result;
	};

	var ResultPrototype = Result.prototype;

	module.exports = function (iterable, unboundFunction, options) {
	  var that = options && options.that;
	  var AS_ENTRIES = !!(options && options.AS_ENTRIES);
	  var IS_RECORD = !!(options && options.IS_RECORD);
	  var IS_ITERATOR = !!(options && options.IS_ITERATOR);
	  var INTERRUPTED = !!(options && options.INTERRUPTED);
	  var fn = bind(unboundFunction, that);
	  var iterator, iterFn, index, length, result, next, step;

	  var stop = function (condition) {
	    if (iterator) iteratorClose(iterator, 'normal');
	    return new Result(true, condition);
	  };

	  var callFn = function (value) {
	    if (AS_ENTRIES) {
	      anObject(value);
	      return INTERRUPTED ? fn(value[0], value[1], stop) : fn(value[0], value[1]);
	    } return INTERRUPTED ? fn(value, stop) : fn(value);
	  };

	  if (IS_RECORD) {
	    iterator = iterable.iterator;
	  } else if (IS_ITERATOR) {
	    iterator = iterable;
	  } else {
	    iterFn = getIteratorMethod(iterable);
	    if (!iterFn) throw new $TypeError(tryToString(iterable) + ' is not iterable');
	    // optimisation for array iterators
	    if (isArrayIteratorMethod(iterFn)) {
	      for (index = 0, length = lengthOfArrayLike(iterable); length > index; index++) {
	        result = callFn(iterable[index]);
	        if (result && isPrototypeOf(ResultPrototype, result)) return result;
	      } return new Result(false);
	    }
	    iterator = getIterator(iterable, iterFn);
	  }

	  next = IS_RECORD ? iterable.next : iterator.next;
	  while (!(step = call(next, iterator)).done) {
	    try {
	      result = callFn(step.value);
	    } catch (error) {
	      iteratorClose(iterator, 'throw', error);
	    }
	    if (typeof result == 'object' && result && isPrototypeOf(ResultPrototype, result)) return result;
	  } return new Result(false);
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/iterator-close-all.js":
	/*!**************************************************************!*\
	  !*** ./node_modules/core-js/internals/iterator-close-all.js ***!
	  \**************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var iteratorClose = __webpack_require__(/*! ../internals/iterator-close */ "./node_modules/core-js/internals/iterator-close.js");

	module.exports = function (iters, kind, value) {
	  for (var i = iters.length - 1; i >= 0; i--) {
	    if (iters[i] === undefined) continue;
	    try {
	      value = iteratorClose(iters[i].iterator, kind, value);
	    } catch (error) {
	      kind = 'throw';
	      value = error;
	    }
	  }
	  if (kind === 'throw') throw value;
	  return value;
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/iterator-close.js":
	/*!**********************************************************!*\
	  !*** ./node_modules/core-js/internals/iterator-close.js ***!
	  \**********************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var call = __webpack_require__(/*! ../internals/function-call */ "./node_modules/core-js/internals/function-call.js");
	var anObject = __webpack_require__(/*! ../internals/an-object */ "./node_modules/core-js/internals/an-object.js");
	var getMethod = __webpack_require__(/*! ../internals/get-method */ "./node_modules/core-js/internals/get-method.js");

	module.exports = function (iterator, kind, value) {
	  var innerResult, innerError;
	  anObject(iterator);
	  try {
	    innerResult = getMethod(iterator, 'return');
	    if (!innerResult) {
	      if (kind === 'throw') throw value;
	      return value;
	    }
	    innerResult = call(innerResult, iterator);
	  } catch (error) {
	    innerError = true;
	    innerResult = error;
	  }
	  if (kind === 'throw') throw value;
	  if (innerError) throw innerResult;
	  anObject(innerResult);
	  return value;
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/iterator-create-constructor.js":
	/*!***********************************************************************!*\
	  !*** ./node_modules/core-js/internals/iterator-create-constructor.js ***!
	  \***********************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var IteratorPrototype = (__webpack_require__(/*! ../internals/iterators-core */ "./node_modules/core-js/internals/iterators-core.js").IteratorPrototype);
	var create = __webpack_require__(/*! ../internals/object-create */ "./node_modules/core-js/internals/object-create.js");
	var createPropertyDescriptor = __webpack_require__(/*! ../internals/create-property-descriptor */ "./node_modules/core-js/internals/create-property-descriptor.js");
	var setToStringTag = __webpack_require__(/*! ../internals/set-to-string-tag */ "./node_modules/core-js/internals/set-to-string-tag.js");
	var Iterators = __webpack_require__(/*! ../internals/iterators */ "./node_modules/core-js/internals/iterators.js");

	var returnThis = function () { return this; };

	module.exports = function (IteratorConstructor, NAME, next, ENUMERABLE_NEXT) {
	  var TO_STRING_TAG = NAME + ' Iterator';
	  IteratorConstructor.prototype = create(IteratorPrototype, { next: createPropertyDescriptor(+!ENUMERABLE_NEXT, next) });
	  setToStringTag(IteratorConstructor, TO_STRING_TAG, false, true);
	  Iterators[TO_STRING_TAG] = returnThis;
	  return IteratorConstructor;
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/iterator-create-proxy.js":
	/*!*****************************************************************!*\
	  !*** ./node_modules/core-js/internals/iterator-create-proxy.js ***!
	  \*****************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var call = __webpack_require__(/*! ../internals/function-call */ "./node_modules/core-js/internals/function-call.js");
	var create = __webpack_require__(/*! ../internals/object-create */ "./node_modules/core-js/internals/object-create.js");
	var createNonEnumerableProperty = __webpack_require__(/*! ../internals/create-non-enumerable-property */ "./node_modules/core-js/internals/create-non-enumerable-property.js");
	var defineBuiltIns = __webpack_require__(/*! ../internals/define-built-ins */ "./node_modules/core-js/internals/define-built-ins.js");
	var wellKnownSymbol = __webpack_require__(/*! ../internals/well-known-symbol */ "./node_modules/core-js/internals/well-known-symbol.js");
	var InternalStateModule = __webpack_require__(/*! ../internals/internal-state */ "./node_modules/core-js/internals/internal-state.js");
	var getMethod = __webpack_require__(/*! ../internals/get-method */ "./node_modules/core-js/internals/get-method.js");
	var IteratorPrototype = (__webpack_require__(/*! ../internals/iterators-core */ "./node_modules/core-js/internals/iterators-core.js").IteratorPrototype);
	var createIterResultObject = __webpack_require__(/*! ../internals/create-iter-result-object */ "./node_modules/core-js/internals/create-iter-result-object.js");
	var iteratorClose = __webpack_require__(/*! ../internals/iterator-close */ "./node_modules/core-js/internals/iterator-close.js");
	var iteratorCloseAll = __webpack_require__(/*! ../internals/iterator-close-all */ "./node_modules/core-js/internals/iterator-close-all.js");

	var TO_STRING_TAG = wellKnownSymbol('toStringTag');
	var ITERATOR_HELPER = 'IteratorHelper';
	var WRAP_FOR_VALID_ITERATOR = 'WrapForValidIterator';
	var NORMAL = 'normal';
	var THROW = 'throw';
	var setInternalState = InternalStateModule.set;

	var createIteratorProxyPrototype = function (IS_ITERATOR) {
	  var getInternalState = InternalStateModule.getterFor(IS_ITERATOR ? WRAP_FOR_VALID_ITERATOR : ITERATOR_HELPER);

	  return defineBuiltIns(create(IteratorPrototype), {
	    next: function next() {
	      var state = getInternalState(this);
	      // for simplification:
	      //   for `%WrapForValidIteratorPrototype%.next` or with `state.returnHandlerResult` our `nextHandler` returns `IterResultObject`
	      //   for `%IteratorHelperPrototype%.next` - just a value
	      if (IS_ITERATOR) return state.nextHandler();
	      if (state.done) return createIterResultObject(undefined, true);
	      try {
	        var result = state.nextHandler();
	        return state.returnHandlerResult ? result : createIterResultObject(result, state.done);
	      } catch (error) {
	        state.done = true;
	        throw error;
	      }
	    },
	    'return': function () {
	      var state = getInternalState(this);
	      var iterator = state.iterator;
	      state.done = true;
	      if (IS_ITERATOR) {
	        var returnMethod = getMethod(iterator, 'return');
	        return returnMethod ? call(returnMethod, iterator) : createIterResultObject(undefined, true);
	      }
	      if (state.inner) try {
	        iteratorClose(state.inner.iterator, NORMAL);
	      } catch (error) {
	        return iteratorClose(iterator, THROW, error);
	      }
	      if (state.openIters) try {
	        iteratorCloseAll(state.openIters, NORMAL);
	      } catch (error) {
	        return iteratorClose(iterator, THROW, error);
	      }
	      if (iterator) iteratorClose(iterator, NORMAL);
	      return createIterResultObject(undefined, true);
	    }
	  });
	};

	var WrapForValidIteratorPrototype = createIteratorProxyPrototype(true);
	var IteratorHelperPrototype = createIteratorProxyPrototype(false);

	createNonEnumerableProperty(IteratorHelperPrototype, TO_STRING_TAG, 'Iterator Helper');

	module.exports = function (nextHandler, IS_ITERATOR, RETURN_HANDLER_RESULT) {
	  var IteratorProxy = function Iterator(record, state) {
	    if (state) {
	      state.iterator = record.iterator;
	      state.next = record.next;
	    } else state = record;
	    state.type = IS_ITERATOR ? WRAP_FOR_VALID_ITERATOR : ITERATOR_HELPER;
	    state.returnHandlerResult = !!RETURN_HANDLER_RESULT;
	    state.nextHandler = nextHandler;
	    state.counter = 0;
	    state.done = false;
	    setInternalState(this, state);
	  };

	  IteratorProxy.prototype = IS_ITERATOR ? WrapForValidIteratorPrototype : IteratorHelperPrototype;

	  return IteratorProxy;
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/iterator-define.js":
	/*!***********************************************************!*\
	  !*** ./node_modules/core-js/internals/iterator-define.js ***!
	  \***********************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
	var call = __webpack_require__(/*! ../internals/function-call */ "./node_modules/core-js/internals/function-call.js");
	var IS_PURE = __webpack_require__(/*! ../internals/is-pure */ "./node_modules/core-js/internals/is-pure.js");
	var FunctionName = __webpack_require__(/*! ../internals/function-name */ "./node_modules/core-js/internals/function-name.js");
	var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/core-js/internals/is-callable.js");
	var createIteratorConstructor = __webpack_require__(/*! ../internals/iterator-create-constructor */ "./node_modules/core-js/internals/iterator-create-constructor.js");
	var getPrototypeOf = __webpack_require__(/*! ../internals/object-get-prototype-of */ "./node_modules/core-js/internals/object-get-prototype-of.js");
	var setPrototypeOf = __webpack_require__(/*! ../internals/object-set-prototype-of */ "./node_modules/core-js/internals/object-set-prototype-of.js");
	var setToStringTag = __webpack_require__(/*! ../internals/set-to-string-tag */ "./node_modules/core-js/internals/set-to-string-tag.js");
	var createNonEnumerableProperty = __webpack_require__(/*! ../internals/create-non-enumerable-property */ "./node_modules/core-js/internals/create-non-enumerable-property.js");
	var defineBuiltIn = __webpack_require__(/*! ../internals/define-built-in */ "./node_modules/core-js/internals/define-built-in.js");
	var wellKnownSymbol = __webpack_require__(/*! ../internals/well-known-symbol */ "./node_modules/core-js/internals/well-known-symbol.js");
	var Iterators = __webpack_require__(/*! ../internals/iterators */ "./node_modules/core-js/internals/iterators.js");
	var IteratorsCore = __webpack_require__(/*! ../internals/iterators-core */ "./node_modules/core-js/internals/iterators-core.js");

	var PROPER_FUNCTION_NAME = FunctionName.PROPER;
	var CONFIGURABLE_FUNCTION_NAME = FunctionName.CONFIGURABLE;
	var IteratorPrototype = IteratorsCore.IteratorPrototype;
	var BUGGY_SAFARI_ITERATORS = IteratorsCore.BUGGY_SAFARI_ITERATORS;
	var ITERATOR = wellKnownSymbol('iterator');
	var KEYS = 'keys';
	var VALUES = 'values';
	var ENTRIES = 'entries';

	var returnThis = function () { return this; };

	module.exports = function (Iterable, NAME, IteratorConstructor, next, DEFAULT, IS_SET, FORCED) {
	  createIteratorConstructor(IteratorConstructor, NAME, next);

	  var getIterationMethod = function (KIND) {
	    if (KIND === DEFAULT && defaultIterator) return defaultIterator;
	    if (!BUGGY_SAFARI_ITERATORS && KIND && KIND in IterablePrototype) return IterablePrototype[KIND];

	    switch (KIND) {
	      case KEYS: return function keys() { return new IteratorConstructor(this, KIND); };
	      case VALUES: return function values() { return new IteratorConstructor(this, KIND); };
	      case ENTRIES: return function entries() { return new IteratorConstructor(this, KIND); };
	    }

	    return function () { return new IteratorConstructor(this); };
	  };

	  var TO_STRING_TAG = NAME + ' Iterator';
	  var INCORRECT_VALUES_NAME = false;
	  var IterablePrototype = Iterable.prototype;
	  var nativeIterator = IterablePrototype[ITERATOR]
	    || IterablePrototype['@@iterator']
	    || DEFAULT && IterablePrototype[DEFAULT];
	  var defaultIterator = !BUGGY_SAFARI_ITERATORS && nativeIterator || getIterationMethod(DEFAULT);
	  var anyNativeIterator = NAME === 'Array' ? IterablePrototype.entries || nativeIterator : nativeIterator;
	  var CurrentIteratorPrototype, methods, KEY;

	  // fix native
	  if (anyNativeIterator) {
	    CurrentIteratorPrototype = getPrototypeOf(anyNativeIterator.call(new Iterable()));
	    if (CurrentIteratorPrototype !== Object.prototype && CurrentIteratorPrototype.next) {
	      if (!IS_PURE && getPrototypeOf(CurrentIteratorPrototype) !== IteratorPrototype) {
	        if (setPrototypeOf) {
	          setPrototypeOf(CurrentIteratorPrototype, IteratorPrototype);
	        } else if (!isCallable(CurrentIteratorPrototype[ITERATOR])) {
	          defineBuiltIn(CurrentIteratorPrototype, ITERATOR, returnThis);
	        }
	      }
	      // Set @@toStringTag to native iterators
	      setToStringTag(CurrentIteratorPrototype, TO_STRING_TAG, true, true);
	      if (IS_PURE) Iterators[TO_STRING_TAG] = returnThis;
	    }
	  }

	  // fix Array.prototype.{ values, @@iterator }.name in V8 / FF
	  if (PROPER_FUNCTION_NAME && DEFAULT === VALUES && nativeIterator && nativeIterator.name !== VALUES) {
	    if (!IS_PURE && CONFIGURABLE_FUNCTION_NAME) {
	      createNonEnumerableProperty(IterablePrototype, 'name', VALUES);
	    } else {
	      INCORRECT_VALUES_NAME = true;
	      defaultIterator = function values() { return call(nativeIterator, this); };
	    }
	  }

	  // export additional methods
	  if (DEFAULT) {
	    methods = {
	      values: getIterationMethod(VALUES),
	      keys: IS_SET ? defaultIterator : getIterationMethod(KEYS),
	      entries: getIterationMethod(ENTRIES)
	    };
	    if (FORCED) for (KEY in methods) {
	      if (BUGGY_SAFARI_ITERATORS || INCORRECT_VALUES_NAME || !(KEY in IterablePrototype)) {
	        defineBuiltIn(IterablePrototype, KEY, methods[KEY]);
	      }
	    } else $({ target: NAME, proto: true, forced: BUGGY_SAFARI_ITERATORS || INCORRECT_VALUES_NAME }, methods);
	  }

	  // define iterator
	  if ((!IS_PURE || FORCED) && IterablePrototype[ITERATOR] !== defaultIterator) {
	    defineBuiltIn(IterablePrototype, ITERATOR, defaultIterator, { name: DEFAULT });
	  }
	  Iterators[NAME] = defaultIterator;

	  return methods;
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/iterator-helper-throws-on-invalid-iterator.js":
	/*!**************************************************************************************!*\
	  !*** ./node_modules/core-js/internals/iterator-helper-throws-on-invalid-iterator.js ***!
	  \**************************************************************************************/
	/***/ (function(module) {


	// Should throw an error on invalid iterator
	// https://issues.chromium.org/issues/336839115
	module.exports = function (methodName, argument) {
	  // eslint-disable-next-line es/no-iterator -- required for testing
	  var method = typeof Iterator == 'function' && Iterator.prototype[methodName];
	  if (method) try {
	    method.call({ next: null }, argument).next();
	  } catch (error) {
	    return true;
	  }
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/iterator-helper-without-closing-on-early-error.js":
	/*!******************************************************************************************!*\
	  !*** ./node_modules/core-js/internals/iterator-helper-without-closing-on-early-error.js ***!
	  \******************************************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/core-js/internals/global-this.js");

	// https://github.com/tc39/ecma262/pull/3467
	module.exports = function (METHOD_NAME, ExpectedError) {
	  var Iterator = globalThis.Iterator;
	  var IteratorPrototype = Iterator && Iterator.prototype;
	  var method = IteratorPrototype && IteratorPrototype[METHOD_NAME];

	  var CLOSED = false;

	  if (method) try {
	    method.call({
	      next: function () { return { done: true }; },
	      'return': function () { CLOSED = true; }
	    }, -1);
	  } catch (error) {
	    // https://bugs.webkit.org/show_bug.cgi?id=291195
	    if (!(error instanceof ExpectedError)) CLOSED = false;
	  }

	  if (!CLOSED) return method;
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/iterators-core.js":
	/*!**********************************************************!*\
	  !*** ./node_modules/core-js/internals/iterators-core.js ***!
	  \**********************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/core-js/internals/fails.js");
	var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/core-js/internals/is-callable.js");
	var isObject = __webpack_require__(/*! ../internals/is-object */ "./node_modules/core-js/internals/is-object.js");
	var create = __webpack_require__(/*! ../internals/object-create */ "./node_modules/core-js/internals/object-create.js");
	var getPrototypeOf = __webpack_require__(/*! ../internals/object-get-prototype-of */ "./node_modules/core-js/internals/object-get-prototype-of.js");
	var defineBuiltIn = __webpack_require__(/*! ../internals/define-built-in */ "./node_modules/core-js/internals/define-built-in.js");
	var wellKnownSymbol = __webpack_require__(/*! ../internals/well-known-symbol */ "./node_modules/core-js/internals/well-known-symbol.js");
	var IS_PURE = __webpack_require__(/*! ../internals/is-pure */ "./node_modules/core-js/internals/is-pure.js");

	var ITERATOR = wellKnownSymbol('iterator');
	var BUGGY_SAFARI_ITERATORS = false;

	// `%IteratorPrototype%` object
	// https://tc39.es/ecma262/#sec-%iteratorprototype%-object
	var IteratorPrototype, PrototypeOfArrayIteratorPrototype, arrayIterator;

	/* eslint-disable es/no-array-prototype-keys -- safe */
	if ([].keys) {
	  arrayIterator = [].keys();
	  // Safari 8 has buggy iterators w/o `next`
	  if (!('next' in arrayIterator)) BUGGY_SAFARI_ITERATORS = true;
	  else {
	    PrototypeOfArrayIteratorPrototype = getPrototypeOf(getPrototypeOf(arrayIterator));
	    if (PrototypeOfArrayIteratorPrototype !== Object.prototype) IteratorPrototype = PrototypeOfArrayIteratorPrototype;
	  }
	}

	var NEW_ITERATOR_PROTOTYPE = !isObject(IteratorPrototype) || fails(function () {
	  var test = {};
	  // FF44- legacy iterators case
	  return IteratorPrototype[ITERATOR].call(test) !== test;
	});

	if (NEW_ITERATOR_PROTOTYPE) IteratorPrototype = {};
	else if (IS_PURE) IteratorPrototype = create(IteratorPrototype);

	// `%IteratorPrototype%[@@iterator]()` method
	// https://tc39.es/ecma262/#sec-%iteratorprototype%-@@iterator
	if (!isCallable(IteratorPrototype[ITERATOR])) {
	  defineBuiltIn(IteratorPrototype, ITERATOR, function () {
	    return this;
	  });
	}

	module.exports = {
	  IteratorPrototype: IteratorPrototype,
	  BUGGY_SAFARI_ITERATORS: BUGGY_SAFARI_ITERATORS
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/iterators.js":
	/*!*****************************************************!*\
	  !*** ./node_modules/core-js/internals/iterators.js ***!
	  \*****************************************************/
	/***/ (function(module) {


	module.exports = {};


	/***/ }),

	/***/ "./node_modules/core-js/internals/length-of-array-like.js":
	/*!****************************************************************!*\
	  !*** ./node_modules/core-js/internals/length-of-array-like.js ***!
	  \****************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var toLength = __webpack_require__(/*! ../internals/to-length */ "./node_modules/core-js/internals/to-length.js");

	// `LengthOfArrayLike` abstract operation
	// https://tc39.es/ecma262/#sec-lengthofarraylike
	module.exports = function (obj) {
	  return toLength(obj.length);
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/make-built-in.js":
	/*!*********************************************************!*\
	  !*** ./node_modules/core-js/internals/make-built-in.js ***!
	  \*********************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/core-js/internals/function-uncurry-this.js");
	var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/core-js/internals/fails.js");
	var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/core-js/internals/is-callable.js");
	var hasOwn = __webpack_require__(/*! ../internals/has-own-property */ "./node_modules/core-js/internals/has-own-property.js");
	var DESCRIPTORS = __webpack_require__(/*! ../internals/descriptors */ "./node_modules/core-js/internals/descriptors.js");
	var CONFIGURABLE_FUNCTION_NAME = (__webpack_require__(/*! ../internals/function-name */ "./node_modules/core-js/internals/function-name.js").CONFIGURABLE);
	var inspectSource = __webpack_require__(/*! ../internals/inspect-source */ "./node_modules/core-js/internals/inspect-source.js");
	var InternalStateModule = __webpack_require__(/*! ../internals/internal-state */ "./node_modules/core-js/internals/internal-state.js");

	var enforceInternalState = InternalStateModule.enforce;
	var getInternalState = InternalStateModule.get;
	var $String = String;
	// eslint-disable-next-line es/no-object-defineproperty -- safe
	var defineProperty = Object.defineProperty;
	var stringSlice = uncurryThis(''.slice);
	var replace = uncurryThis(''.replace);
	var join = uncurryThis([].join);

	var CONFIGURABLE_LENGTH = DESCRIPTORS && !fails(function () {
	  return defineProperty(function () { /* empty */ }, 'length', { value: 8 }).length !== 8;
	});

	var TEMPLATE = String(String).split('String');

	var makeBuiltIn = module.exports = function (value, name, options) {
	  if (stringSlice($String(name), 0, 7) === 'Symbol(') {
	    name = '[' + replace($String(name), /^Symbol\(([^)]*)\).*$/, '$1') + ']';
	  }
	  if (options && options.getter) name = 'get ' + name;
	  if (options && options.setter) name = 'set ' + name;
	  if (!hasOwn(value, 'name') || (CONFIGURABLE_FUNCTION_NAME && value.name !== name)) {
	    if (DESCRIPTORS) defineProperty(value, 'name', { value: name, configurable: true });
	    else value.name = name;
	  }
	  if (CONFIGURABLE_LENGTH && options && hasOwn(options, 'arity') && value.length !== options.arity) {
	    defineProperty(value, 'length', { value: options.arity });
	  }
	  try {
	    if (options && hasOwn(options, 'constructor') && options.constructor) {
	      if (DESCRIPTORS) defineProperty(value, 'prototype', { writable: false });
	    // in V8 ~ Chrome 53, prototypes of some methods, like `Array.prototype.values`, are non-writable
	    } else if (value.prototype) value.prototype = undefined;
	  } catch (error) { /* empty */ }
	  var state = enforceInternalState(value);
	  if (!hasOwn(state, 'source')) {
	    state.source = join(TEMPLATE, typeof name == 'string' ? name : '');
	  } return value;
	};

	// add fake Function#toString for correct work wrapped methods / constructors with methods like LoDash isNative
	// eslint-disable-next-line no-extend-native -- required
	Function.prototype.toString = makeBuiltIn(function toString() {
	  return isCallable(this) && getInternalState(this).source || inspectSource(this);
	}, 'toString');


	/***/ }),

	/***/ "./node_modules/core-js/internals/math-trunc.js":
	/*!******************************************************!*\
	  !*** ./node_modules/core-js/internals/math-trunc.js ***!
	  \******************************************************/
	/***/ (function(module) {


	var ceil = Math.ceil;
	var floor = Math.floor;

	// `Math.trunc` method
	// https://tc39.es/ecma262/#sec-math.trunc
	// eslint-disable-next-line es/no-math-trunc -- safe
	module.exports = Math.trunc || function trunc(x) {
	  var n = +x;
	  return (n > 0 ? floor : ceil)(n);
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/microtask.js":
	/*!*****************************************************!*\
	  !*** ./node_modules/core-js/internals/microtask.js ***!
	  \*****************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/core-js/internals/global-this.js");
	var safeGetBuiltIn = __webpack_require__(/*! ../internals/safe-get-built-in */ "./node_modules/core-js/internals/safe-get-built-in.js");
	var bind = __webpack_require__(/*! ../internals/function-bind-context */ "./node_modules/core-js/internals/function-bind-context.js");
	var macrotask = (__webpack_require__(/*! ../internals/task */ "./node_modules/core-js/internals/task.js").set);
	var Queue = __webpack_require__(/*! ../internals/queue */ "./node_modules/core-js/internals/queue.js");
	var IS_IOS = __webpack_require__(/*! ../internals/environment-is-ios */ "./node_modules/core-js/internals/environment-is-ios.js");
	var IS_IOS_PEBBLE = __webpack_require__(/*! ../internals/environment-is-ios-pebble */ "./node_modules/core-js/internals/environment-is-ios-pebble.js");
	var IS_WEBOS_WEBKIT = __webpack_require__(/*! ../internals/environment-is-webos-webkit */ "./node_modules/core-js/internals/environment-is-webos-webkit.js");
	var IS_NODE = __webpack_require__(/*! ../internals/environment-is-node */ "./node_modules/core-js/internals/environment-is-node.js");

	var MutationObserver = globalThis.MutationObserver || globalThis.WebKitMutationObserver;
	var document = globalThis.document;
	var process = globalThis.process;
	var Promise = globalThis.Promise;
	var microtask = safeGetBuiltIn('queueMicrotask');
	var notify, toggle, node, promise, then;

	// modern engines have queueMicrotask method
	if (!microtask) {
	  var queue = new Queue();

	  var flush = function () {
	    var parent, fn;
	    if (IS_NODE && (parent = process.domain)) parent.exit();
	    while (fn = queue.get()) try {
	      fn();
	    } catch (error) {
	      if (queue.head) notify();
	      throw error;
	    }
	    if (parent) parent.enter();
	  };

	  // browsers with MutationObserver, except iOS - https://github.com/zloirock/core-js/issues/339
	  // also except WebOS Webkit https://github.com/zloirock/core-js/issues/898
	  if (!IS_IOS && !IS_NODE && !IS_WEBOS_WEBKIT && MutationObserver && document) {
	    toggle = true;
	    node = document.createTextNode('');
	    new MutationObserver(flush).observe(node, { characterData: true });
	    notify = function () {
	      node.data = toggle = !toggle;
	    };
	  // environments with maybe non-completely correct, but existent Promise
	  } else if (!IS_IOS_PEBBLE && Promise && Promise.resolve) {
	    // Promise.resolve without an argument throws an error in LG WebOS 2
	    promise = Promise.resolve(undefined);
	    // workaround of WebKit ~ iOS Safari 10.1 bug
	    promise.constructor = Promise;
	    then = bind(promise.then, promise);
	    notify = function () {
	      then(flush);
	    };
	  // Node.js without promises
	  } else if (IS_NODE) {
	    notify = function () {
	      process.nextTick(flush);
	    };
	  // for other environments - macrotask based on:
	  // - setImmediate
	  // - MessageChannel
	  // - window.postMessage
	  // - onreadystatechange
	  // - setTimeout
	  } else {
	    // `webpack` dev server bug on IE global methods - use bind(fn, global)
	    macrotask = bind(macrotask, globalThis);
	    notify = function () {
	      macrotask(flush);
	    };
	  }

	  microtask = function (fn) {
	    if (!queue.head) notify();
	    queue.add(fn);
	  };
	}

	module.exports = microtask;


	/***/ }),

	/***/ "./node_modules/core-js/internals/new-promise-capability.js":
	/*!******************************************************************!*\
	  !*** ./node_modules/core-js/internals/new-promise-capability.js ***!
	  \******************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var aCallable = __webpack_require__(/*! ../internals/a-callable */ "./node_modules/core-js/internals/a-callable.js");

	var $TypeError = TypeError;

	var PromiseCapability = function (C) {
	  var resolve, reject;
	  this.promise = new C(function ($$resolve, $$reject) {
	    if (resolve !== undefined || reject !== undefined) throw new $TypeError('Bad Promise constructor');
	    resolve = $$resolve;
	    reject = $$reject;
	  });
	  this.resolve = aCallable(resolve);
	  this.reject = aCallable(reject);
	};

	// `NewPromiseCapability` abstract operation
	// https://tc39.es/ecma262/#sec-newpromisecapability
	module.exports.f = function (C) {
	  return new PromiseCapability(C);
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/object-assign.js":
	/*!*********************************************************!*\
	  !*** ./node_modules/core-js/internals/object-assign.js ***!
	  \*********************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var DESCRIPTORS = __webpack_require__(/*! ../internals/descriptors */ "./node_modules/core-js/internals/descriptors.js");
	var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/core-js/internals/function-uncurry-this.js");
	var call = __webpack_require__(/*! ../internals/function-call */ "./node_modules/core-js/internals/function-call.js");
	var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/core-js/internals/fails.js");
	var objectKeys = __webpack_require__(/*! ../internals/object-keys */ "./node_modules/core-js/internals/object-keys.js");
	var getOwnPropertySymbolsModule = __webpack_require__(/*! ../internals/object-get-own-property-symbols */ "./node_modules/core-js/internals/object-get-own-property-symbols.js");
	var propertyIsEnumerableModule = __webpack_require__(/*! ../internals/object-property-is-enumerable */ "./node_modules/core-js/internals/object-property-is-enumerable.js");
	var toObject = __webpack_require__(/*! ../internals/to-object */ "./node_modules/core-js/internals/to-object.js");
	var IndexedObject = __webpack_require__(/*! ../internals/indexed-object */ "./node_modules/core-js/internals/indexed-object.js");

	// eslint-disable-next-line es/no-object-assign -- safe
	var $assign = Object.assign;
	// eslint-disable-next-line es/no-object-defineproperty -- required for testing
	var defineProperty = Object.defineProperty;
	var concat = uncurryThis([].concat);

	// `Object.assign` method
	// https://tc39.es/ecma262/#sec-object.assign
	module.exports = !$assign || fails(function () {
	  // should have correct order of operations (Edge bug)
	  if (DESCRIPTORS && $assign({ b: 1 }, $assign(defineProperty({}, 'a', {
	    enumerable: true,
	    get: function () {
	      defineProperty(this, 'b', {
	        value: 3,
	        enumerable: false
	      });
	    }
	  }), { b: 2 })).b !== 1) return true;
	  // should work with symbols and should have deterministic property order (V8 bug)
	  var A = {};
	  var B = {};
	  // eslint-disable-next-line es/no-symbol -- safe
	  var symbol = Symbol('assign detection');
	  var alphabet = 'abcdefghijklmnopqrst';
	  A[symbol] = 7;
	  // eslint-disable-next-line es/no-array-prototype-foreach -- safe
	  alphabet.split('').forEach(function (chr) { B[chr] = chr; });
	  return $assign({}, A)[symbol] !== 7 || objectKeys($assign({}, B)).join('') !== alphabet;
	}) ? function assign(target, source) { // eslint-disable-line no-unused-vars -- required for `.length`
	  var T = toObject(target);
	  var argumentsLength = arguments.length;
	  var index = 1;
	  var getOwnPropertySymbols = getOwnPropertySymbolsModule.f;
	  var propertyIsEnumerable = propertyIsEnumerableModule.f;
	  while (argumentsLength > index) {
	    var S = IndexedObject(arguments[index++]);
	    var keys = getOwnPropertySymbols ? concat(objectKeys(S), getOwnPropertySymbols(S)) : objectKeys(S);
	    var length = keys.length;
	    var j = 0;
	    var key;
	    while (length > j) {
	      key = keys[j++];
	      if (!DESCRIPTORS || call(propertyIsEnumerable, S, key)) T[key] = S[key];
	    }
	  } return T;
	} : $assign;


	/***/ }),

	/***/ "./node_modules/core-js/internals/object-create.js":
	/*!*********************************************************!*\
	  !*** ./node_modules/core-js/internals/object-create.js ***!
	  \*********************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	/* global ActiveXObject -- old IE, WSH */
	var anObject = __webpack_require__(/*! ../internals/an-object */ "./node_modules/core-js/internals/an-object.js");
	var definePropertiesModule = __webpack_require__(/*! ../internals/object-define-properties */ "./node_modules/core-js/internals/object-define-properties.js");
	var enumBugKeys = __webpack_require__(/*! ../internals/enum-bug-keys */ "./node_modules/core-js/internals/enum-bug-keys.js");
	var hiddenKeys = __webpack_require__(/*! ../internals/hidden-keys */ "./node_modules/core-js/internals/hidden-keys.js");
	var html = __webpack_require__(/*! ../internals/html */ "./node_modules/core-js/internals/html.js");
	var documentCreateElement = __webpack_require__(/*! ../internals/document-create-element */ "./node_modules/core-js/internals/document-create-element.js");
	var sharedKey = __webpack_require__(/*! ../internals/shared-key */ "./node_modules/core-js/internals/shared-key.js");

	var GT = '>';
	var LT = '<';
	var PROTOTYPE = 'prototype';
	var SCRIPT = 'script';
	var IE_PROTO = sharedKey('IE_PROTO');

	var EmptyConstructor = function () { /* empty */ };

	var scriptTag = function (content) {
	  return LT + SCRIPT + GT + content + LT + '/' + SCRIPT + GT;
	};

	// Create object with fake `null` prototype: use ActiveX Object with cleared prototype
	var NullProtoObjectViaActiveX = function (activeXDocument) {
	  activeXDocument.write(scriptTag(''));
	  activeXDocument.close();
	  var temp = activeXDocument.parentWindow.Object;
	  // eslint-disable-next-line no-useless-assignment -- avoid memory leak
	  activeXDocument = null;
	  return temp;
	};

	// Create object with fake `null` prototype: use iframe Object with cleared prototype
	var NullProtoObjectViaIFrame = function () {
	  // Thrash, waste and sodomy: IE GC bug
	  var iframe = documentCreateElement('iframe');
	  var JS = 'java' + SCRIPT + ':';
	  var iframeDocument;
	  iframe.style.display = 'none';
	  html.appendChild(iframe);
	  // https://github.com/zloirock/core-js/issues/475
	  iframe.src = String(JS);
	  iframeDocument = iframe.contentWindow.document;
	  iframeDocument.open();
	  iframeDocument.write(scriptTag('document.F=Object'));
	  iframeDocument.close();
	  return iframeDocument.F;
	};

	// Check for document.domain and active x support
	// No need to use active x approach when document.domain is not set
	// see https://github.com/es-shims/es5-shim/issues/150
	// variation of https://github.com/kitcambridge/es5-shim/commit/4f738ac066346
	// avoid IE GC bug
	var activeXDocument;
	var NullProtoObject = function () {
	  try {
	    activeXDocument = new ActiveXObject('htmlfile');
	  } catch (error) { /* ignore */ }
	  NullProtoObject = typeof document != 'undefined'
	    ? document.domain && activeXDocument
	      ? NullProtoObjectViaActiveX(activeXDocument) // old IE
	      : NullProtoObjectViaIFrame()
	    : NullProtoObjectViaActiveX(activeXDocument); // WSH
	  var length = enumBugKeys.length;
	  while (length--) delete NullProtoObject[PROTOTYPE][enumBugKeys[length]];
	  return NullProtoObject();
	};

	hiddenKeys[IE_PROTO] = true;

	// `Object.create` method
	// https://tc39.es/ecma262/#sec-object.create
	// eslint-disable-next-line es/no-object-create -- safe
	module.exports = Object.create || function create(O, Properties) {
	  var result;
	  if (O !== null) {
	    EmptyConstructor[PROTOTYPE] = anObject(O);
	    result = new EmptyConstructor();
	    EmptyConstructor[PROTOTYPE] = null;
	    // add "__proto__" for Object.getPrototypeOf polyfill
	    result[IE_PROTO] = O;
	  } else result = NullProtoObject();
	  return Properties === undefined ? result : definePropertiesModule.f(result, Properties);
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/object-define-properties.js":
	/*!********************************************************************!*\
	  !*** ./node_modules/core-js/internals/object-define-properties.js ***!
	  \********************************************************************/
	/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


	var DESCRIPTORS = __webpack_require__(/*! ../internals/descriptors */ "./node_modules/core-js/internals/descriptors.js");
	var V8_PROTOTYPE_DEFINE_BUG = __webpack_require__(/*! ../internals/v8-prototype-define-bug */ "./node_modules/core-js/internals/v8-prototype-define-bug.js");
	var definePropertyModule = __webpack_require__(/*! ../internals/object-define-property */ "./node_modules/core-js/internals/object-define-property.js");
	var anObject = __webpack_require__(/*! ../internals/an-object */ "./node_modules/core-js/internals/an-object.js");
	var toIndexedObject = __webpack_require__(/*! ../internals/to-indexed-object */ "./node_modules/core-js/internals/to-indexed-object.js");
	var objectKeys = __webpack_require__(/*! ../internals/object-keys */ "./node_modules/core-js/internals/object-keys.js");

	// `Object.defineProperties` method
	// https://tc39.es/ecma262/#sec-object.defineproperties
	// eslint-disable-next-line es/no-object-defineproperties -- safe
	exports.f = DESCRIPTORS && !V8_PROTOTYPE_DEFINE_BUG ? Object.defineProperties : function defineProperties(O, Properties) {
	  anObject(O);
	  var props = toIndexedObject(Properties);
	  var keys = objectKeys(Properties);
	  var length = keys.length;
	  var index = 0;
	  var key;
	  while (length > index) definePropertyModule.f(O, key = keys[index++], props[key]);
	  return O;
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/object-define-property.js":
	/*!******************************************************************!*\
	  !*** ./node_modules/core-js/internals/object-define-property.js ***!
	  \******************************************************************/
	/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


	var DESCRIPTORS = __webpack_require__(/*! ../internals/descriptors */ "./node_modules/core-js/internals/descriptors.js");
	var IE8_DOM_DEFINE = __webpack_require__(/*! ../internals/ie8-dom-define */ "./node_modules/core-js/internals/ie8-dom-define.js");
	var V8_PROTOTYPE_DEFINE_BUG = __webpack_require__(/*! ../internals/v8-prototype-define-bug */ "./node_modules/core-js/internals/v8-prototype-define-bug.js");
	var anObject = __webpack_require__(/*! ../internals/an-object */ "./node_modules/core-js/internals/an-object.js");
	var toPropertyKey = __webpack_require__(/*! ../internals/to-property-key */ "./node_modules/core-js/internals/to-property-key.js");

	var $TypeError = TypeError;
	// eslint-disable-next-line es/no-object-defineproperty -- safe
	var $defineProperty = Object.defineProperty;
	// eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
	var $getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;
	var ENUMERABLE = 'enumerable';
	var CONFIGURABLE = 'configurable';
	var WRITABLE = 'writable';

	// `Object.defineProperty` method
	// https://tc39.es/ecma262/#sec-object.defineproperty
	exports.f = DESCRIPTORS ? V8_PROTOTYPE_DEFINE_BUG ? function defineProperty(O, P, Attributes) {
	  anObject(O);
	  P = toPropertyKey(P);
	  anObject(Attributes);
	  if (typeof O === 'function' && P === 'prototype' && 'value' in Attributes && WRITABLE in Attributes && !Attributes[WRITABLE]) {
	    var current = $getOwnPropertyDescriptor(O, P);
	    if (current && current[WRITABLE]) {
	      O[P] = Attributes.value;
	      Attributes = {
	        configurable: CONFIGURABLE in Attributes ? Attributes[CONFIGURABLE] : current[CONFIGURABLE],
	        enumerable: ENUMERABLE in Attributes ? Attributes[ENUMERABLE] : current[ENUMERABLE],
	        writable: false
	      };
	    }
	  } return $defineProperty(O, P, Attributes);
	} : $defineProperty : function defineProperty(O, P, Attributes) {
	  anObject(O);
	  P = toPropertyKey(P);
	  anObject(Attributes);
	  if (IE8_DOM_DEFINE) try {
	    return $defineProperty(O, P, Attributes);
	  } catch (error) { /* empty */ }
	  if ('get' in Attributes || 'set' in Attributes) throw new $TypeError('Accessors not supported');
	  if ('value' in Attributes) O[P] = Attributes.value;
	  return O;
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/object-get-own-property-descriptor.js":
	/*!******************************************************************************!*\
	  !*** ./node_modules/core-js/internals/object-get-own-property-descriptor.js ***!
	  \******************************************************************************/
	/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


	var DESCRIPTORS = __webpack_require__(/*! ../internals/descriptors */ "./node_modules/core-js/internals/descriptors.js");
	var call = __webpack_require__(/*! ../internals/function-call */ "./node_modules/core-js/internals/function-call.js");
	var propertyIsEnumerableModule = __webpack_require__(/*! ../internals/object-property-is-enumerable */ "./node_modules/core-js/internals/object-property-is-enumerable.js");
	var createPropertyDescriptor = __webpack_require__(/*! ../internals/create-property-descriptor */ "./node_modules/core-js/internals/create-property-descriptor.js");
	var toIndexedObject = __webpack_require__(/*! ../internals/to-indexed-object */ "./node_modules/core-js/internals/to-indexed-object.js");
	var toPropertyKey = __webpack_require__(/*! ../internals/to-property-key */ "./node_modules/core-js/internals/to-property-key.js");
	var hasOwn = __webpack_require__(/*! ../internals/has-own-property */ "./node_modules/core-js/internals/has-own-property.js");
	var IE8_DOM_DEFINE = __webpack_require__(/*! ../internals/ie8-dom-define */ "./node_modules/core-js/internals/ie8-dom-define.js");

	// eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
	var $getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;

	// `Object.getOwnPropertyDescriptor` method
	// https://tc39.es/ecma262/#sec-object.getownpropertydescriptor
	exports.f = DESCRIPTORS ? $getOwnPropertyDescriptor : function getOwnPropertyDescriptor(O, P) {
	  O = toIndexedObject(O);
	  P = toPropertyKey(P);
	  if (IE8_DOM_DEFINE) try {
	    return $getOwnPropertyDescriptor(O, P);
	  } catch (error) { /* empty */ }
	  if (hasOwn(O, P)) return createPropertyDescriptor(!call(propertyIsEnumerableModule.f, O, P), O[P]);
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/object-get-own-property-names-external.js":
	/*!**********************************************************************************!*\
	  !*** ./node_modules/core-js/internals/object-get-own-property-names-external.js ***!
	  \**********************************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	/* eslint-disable es/no-object-getownpropertynames -- safe */
	var classof = __webpack_require__(/*! ../internals/classof-raw */ "./node_modules/core-js/internals/classof-raw.js");
	var toIndexedObject = __webpack_require__(/*! ../internals/to-indexed-object */ "./node_modules/core-js/internals/to-indexed-object.js");
	var $getOwnPropertyNames = (__webpack_require__(/*! ../internals/object-get-own-property-names */ "./node_modules/core-js/internals/object-get-own-property-names.js").f);
	var arraySlice = __webpack_require__(/*! ../internals/array-slice */ "./node_modules/core-js/internals/array-slice.js");

	var windowNames = [];

	var getWindowNames = function (it) {
	  try {
	    return $getOwnPropertyNames(it);
	  } catch (error) {
	    return arraySlice(windowNames);
	  }
	};

	// fallback for IE11 buggy Object.getOwnPropertyNames with iframe and window
	module.exports.f = function getOwnPropertyNames(it) {
	  return windowNames && classof(it) === 'Window'
	    ? getWindowNames(it)
	    : $getOwnPropertyNames(toIndexedObject(it));
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/object-get-own-property-names.js":
	/*!*************************************************************************!*\
	  !*** ./node_modules/core-js/internals/object-get-own-property-names.js ***!
	  \*************************************************************************/
	/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


	var internalObjectKeys = __webpack_require__(/*! ../internals/object-keys-internal */ "./node_modules/core-js/internals/object-keys-internal.js");
	var enumBugKeys = __webpack_require__(/*! ../internals/enum-bug-keys */ "./node_modules/core-js/internals/enum-bug-keys.js");

	var hiddenKeys = enumBugKeys.concat('length', 'prototype');

	// `Object.getOwnPropertyNames` method
	// https://tc39.es/ecma262/#sec-object.getownpropertynames
	// eslint-disable-next-line es/no-object-getownpropertynames -- safe
	exports.f = Object.getOwnPropertyNames || function getOwnPropertyNames(O) {
	  return internalObjectKeys(O, hiddenKeys);
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/object-get-own-property-symbols.js":
	/*!***************************************************************************!*\
	  !*** ./node_modules/core-js/internals/object-get-own-property-symbols.js ***!
	  \***************************************************************************/
	/***/ (function(__unused_webpack_module, exports) {


	// eslint-disable-next-line es/no-object-getownpropertysymbols -- safe
	exports.f = Object.getOwnPropertySymbols;


	/***/ }),

	/***/ "./node_modules/core-js/internals/object-get-prototype-of.js":
	/*!*******************************************************************!*\
	  !*** ./node_modules/core-js/internals/object-get-prototype-of.js ***!
	  \*******************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var hasOwn = __webpack_require__(/*! ../internals/has-own-property */ "./node_modules/core-js/internals/has-own-property.js");
	var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/core-js/internals/is-callable.js");
	var toObject = __webpack_require__(/*! ../internals/to-object */ "./node_modules/core-js/internals/to-object.js");
	var sharedKey = __webpack_require__(/*! ../internals/shared-key */ "./node_modules/core-js/internals/shared-key.js");
	var CORRECT_PROTOTYPE_GETTER = __webpack_require__(/*! ../internals/correct-prototype-getter */ "./node_modules/core-js/internals/correct-prototype-getter.js");

	var IE_PROTO = sharedKey('IE_PROTO');
	var $Object = Object;
	var ObjectPrototype = $Object.prototype;

	// `Object.getPrototypeOf` method
	// https://tc39.es/ecma262/#sec-object.getprototypeof
	// eslint-disable-next-line es/no-object-getprototypeof -- safe
	module.exports = CORRECT_PROTOTYPE_GETTER ? $Object.getPrototypeOf : function (O) {
	  var object = toObject(O);
	  if (hasOwn(object, IE_PROTO)) return object[IE_PROTO];
	  var constructor = object.constructor;
	  if (isCallable(constructor) && object instanceof constructor) {
	    return constructor.prototype;
	  } return object instanceof $Object ? ObjectPrototype : null;
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/object-is-extensible.js":
	/*!****************************************************************!*\
	  !*** ./node_modules/core-js/internals/object-is-extensible.js ***!
	  \****************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/core-js/internals/fails.js");
	var isObject = __webpack_require__(/*! ../internals/is-object */ "./node_modules/core-js/internals/is-object.js");
	var classof = __webpack_require__(/*! ../internals/classof-raw */ "./node_modules/core-js/internals/classof-raw.js");
	var ARRAY_BUFFER_NON_EXTENSIBLE = __webpack_require__(/*! ../internals/array-buffer-non-extensible */ "./node_modules/core-js/internals/array-buffer-non-extensible.js");

	// eslint-disable-next-line es/no-object-isextensible -- safe
	var $isExtensible = Object.isExtensible;
	var FAILS_ON_PRIMITIVES = fails(function () { });

	// `Object.isExtensible` method
	// https://tc39.es/ecma262/#sec-object.isextensible
	module.exports = (FAILS_ON_PRIMITIVES || ARRAY_BUFFER_NON_EXTENSIBLE) ? function isExtensible(it) {
	  if (!isObject(it)) return false;
	  if (ARRAY_BUFFER_NON_EXTENSIBLE && classof(it) === 'ArrayBuffer') return false;
	  return $isExtensible ? $isExtensible(it) : true;
	} : $isExtensible;


	/***/ }),

	/***/ "./node_modules/core-js/internals/object-is-prototype-of.js":
	/*!******************************************************************!*\
	  !*** ./node_modules/core-js/internals/object-is-prototype-of.js ***!
	  \******************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/core-js/internals/function-uncurry-this.js");

	module.exports = uncurryThis({}.isPrototypeOf);


	/***/ }),

	/***/ "./node_modules/core-js/internals/object-keys-internal.js":
	/*!****************************************************************!*\
	  !*** ./node_modules/core-js/internals/object-keys-internal.js ***!
	  \****************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/core-js/internals/function-uncurry-this.js");
	var hasOwn = __webpack_require__(/*! ../internals/has-own-property */ "./node_modules/core-js/internals/has-own-property.js");
	var toIndexedObject = __webpack_require__(/*! ../internals/to-indexed-object */ "./node_modules/core-js/internals/to-indexed-object.js");
	var indexOf = (__webpack_require__(/*! ../internals/array-includes */ "./node_modules/core-js/internals/array-includes.js").indexOf);
	var hiddenKeys = __webpack_require__(/*! ../internals/hidden-keys */ "./node_modules/core-js/internals/hidden-keys.js");

	var push = uncurryThis([].push);

	module.exports = function (object, names) {
	  var O = toIndexedObject(object);
	  var i = 0;
	  var result = [];
	  var key;
	  for (key in O) !hasOwn(hiddenKeys, key) && hasOwn(O, key) && push(result, key);
	  // Don't enum bug & hidden keys
	  while (names.length > i) if (hasOwn(O, key = names[i++])) {
	    ~indexOf(result, key) || push(result, key);
	  }
	  return result;
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/object-keys.js":
	/*!*******************************************************!*\
	  !*** ./node_modules/core-js/internals/object-keys.js ***!
	  \*******************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var internalObjectKeys = __webpack_require__(/*! ../internals/object-keys-internal */ "./node_modules/core-js/internals/object-keys-internal.js");
	var enumBugKeys = __webpack_require__(/*! ../internals/enum-bug-keys */ "./node_modules/core-js/internals/enum-bug-keys.js");

	// `Object.keys` method
	// https://tc39.es/ecma262/#sec-object.keys
	// eslint-disable-next-line es/no-object-keys -- safe
	module.exports = Object.keys || function keys(O) {
	  return internalObjectKeys(O, enumBugKeys);
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/object-property-is-enumerable.js":
	/*!*************************************************************************!*\
	  !*** ./node_modules/core-js/internals/object-property-is-enumerable.js ***!
	  \*************************************************************************/
	/***/ (function(__unused_webpack_module, exports) {


	var $propertyIsEnumerable = {}.propertyIsEnumerable;
	// eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
	var getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;

	// Nashorn ~ JDK8 bug
	var NASHORN_BUG = getOwnPropertyDescriptor && !$propertyIsEnumerable.call({ 1: 2 }, 1);

	// `Object.prototype.propertyIsEnumerable` method implementation
	// https://tc39.es/ecma262/#sec-object.prototype.propertyisenumerable
	exports.f = NASHORN_BUG ? function propertyIsEnumerable(V) {
	  var descriptor = getOwnPropertyDescriptor(this, V);
	  return !!descriptor && descriptor.enumerable;
	} : $propertyIsEnumerable;


	/***/ }),

	/***/ "./node_modules/core-js/internals/object-set-prototype-of.js":
	/*!*******************************************************************!*\
	  !*** ./node_modules/core-js/internals/object-set-prototype-of.js ***!
	  \*******************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	/* eslint-disable no-proto -- safe */
	var uncurryThisAccessor = __webpack_require__(/*! ../internals/function-uncurry-this-accessor */ "./node_modules/core-js/internals/function-uncurry-this-accessor.js");
	var isObject = __webpack_require__(/*! ../internals/is-object */ "./node_modules/core-js/internals/is-object.js");
	var requireObjectCoercible = __webpack_require__(/*! ../internals/require-object-coercible */ "./node_modules/core-js/internals/require-object-coercible.js");
	var aPossiblePrototype = __webpack_require__(/*! ../internals/a-possible-prototype */ "./node_modules/core-js/internals/a-possible-prototype.js");

	// `Object.setPrototypeOf` method
	// https://tc39.es/ecma262/#sec-object.setprototypeof
	// Works with __proto__ only. Old v8 can't work with null proto objects.
	// eslint-disable-next-line es/no-object-setprototypeof -- safe
	module.exports = Object.setPrototypeOf || ('__proto__' in {} ? function () {
	  var CORRECT_SETTER = false;
	  var test = {};
	  var setter;
	  try {
	    setter = uncurryThisAccessor(Object.prototype, '__proto__', 'set');
	    setter(test, []);
	    CORRECT_SETTER = test instanceof Array;
	  } catch (error) { /* empty */ }
	  return function setPrototypeOf(O, proto) {
	    requireObjectCoercible(O);
	    aPossiblePrototype(proto);
	    if (!isObject(O)) return O;
	    if (CORRECT_SETTER) setter(O, proto);
	    else O.__proto__ = proto;
	    return O;
	  };
	}() : undefined);


	/***/ }),

	/***/ "./node_modules/core-js/internals/object-to-string.js":
	/*!************************************************************!*\
	  !*** ./node_modules/core-js/internals/object-to-string.js ***!
	  \************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var TO_STRING_TAG_SUPPORT = __webpack_require__(/*! ../internals/to-string-tag-support */ "./node_modules/core-js/internals/to-string-tag-support.js");
	var classof = __webpack_require__(/*! ../internals/classof */ "./node_modules/core-js/internals/classof.js");

	// `Object.prototype.toString` method implementation
	// https://tc39.es/ecma262/#sec-object.prototype.tostring
	module.exports = TO_STRING_TAG_SUPPORT ? {}.toString : function toString() {
	  return '[object ' + classof(this) + ']';
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/ordinary-to-primitive.js":
	/*!*****************************************************************!*\
	  !*** ./node_modules/core-js/internals/ordinary-to-primitive.js ***!
	  \*****************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var call = __webpack_require__(/*! ../internals/function-call */ "./node_modules/core-js/internals/function-call.js");
	var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/core-js/internals/is-callable.js");
	var isObject = __webpack_require__(/*! ../internals/is-object */ "./node_modules/core-js/internals/is-object.js");

	var $TypeError = TypeError;

	// `OrdinaryToPrimitive` abstract operation
	// https://tc39.es/ecma262/#sec-ordinarytoprimitive
	module.exports = function (input, pref) {
	  var fn, val;
	  if (pref === 'string' && isCallable(fn = input.toString) && !isObject(val = call(fn, input))) return val;
	  if (isCallable(fn = input.valueOf) && !isObject(val = call(fn, input))) return val;
	  if (pref !== 'string' && isCallable(fn = input.toString) && !isObject(val = call(fn, input))) return val;
	  throw new $TypeError("Can't convert object to primitive value");
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/own-keys.js":
	/*!****************************************************!*\
	  !*** ./node_modules/core-js/internals/own-keys.js ***!
	  \****************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var getBuiltIn = __webpack_require__(/*! ../internals/get-built-in */ "./node_modules/core-js/internals/get-built-in.js");
	var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/core-js/internals/function-uncurry-this.js");
	var getOwnPropertyNamesModule = __webpack_require__(/*! ../internals/object-get-own-property-names */ "./node_modules/core-js/internals/object-get-own-property-names.js");
	var getOwnPropertySymbolsModule = __webpack_require__(/*! ../internals/object-get-own-property-symbols */ "./node_modules/core-js/internals/object-get-own-property-symbols.js");
	var anObject = __webpack_require__(/*! ../internals/an-object */ "./node_modules/core-js/internals/an-object.js");

	var concat = uncurryThis([].concat);

	// all object keys, includes non-enumerable and symbols
	module.exports = getBuiltIn('Reflect', 'ownKeys') || function ownKeys(it) {
	  var keys = getOwnPropertyNamesModule.f(anObject(it));
	  var getOwnPropertySymbols = getOwnPropertySymbolsModule.f;
	  return getOwnPropertySymbols ? concat(keys, getOwnPropertySymbols(it)) : keys;
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/path.js":
	/*!************************************************!*\
	  !*** ./node_modules/core-js/internals/path.js ***!
	  \************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/core-js/internals/global-this.js");

	module.exports = globalThis;


	/***/ }),

	/***/ "./node_modules/core-js/internals/perform.js":
	/*!***************************************************!*\
	  !*** ./node_modules/core-js/internals/perform.js ***!
	  \***************************************************/
	/***/ (function(module) {


	module.exports = function (exec) {
	  try {
	    return { error: false, value: exec() };
	  } catch (error) {
	    return { error: true, value: error };
	  }
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/promise-constructor-detection.js":
	/*!*************************************************************************!*\
	  !*** ./node_modules/core-js/internals/promise-constructor-detection.js ***!
	  \*************************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/core-js/internals/global-this.js");
	var NativePromiseConstructor = __webpack_require__(/*! ../internals/promise-native-constructor */ "./node_modules/core-js/internals/promise-native-constructor.js");
	var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/core-js/internals/is-callable.js");
	var isForced = __webpack_require__(/*! ../internals/is-forced */ "./node_modules/core-js/internals/is-forced.js");
	var inspectSource = __webpack_require__(/*! ../internals/inspect-source */ "./node_modules/core-js/internals/inspect-source.js");
	var wellKnownSymbol = __webpack_require__(/*! ../internals/well-known-symbol */ "./node_modules/core-js/internals/well-known-symbol.js");
	var ENVIRONMENT = __webpack_require__(/*! ../internals/environment */ "./node_modules/core-js/internals/environment.js");
	var IS_PURE = __webpack_require__(/*! ../internals/is-pure */ "./node_modules/core-js/internals/is-pure.js");
	var V8_VERSION = __webpack_require__(/*! ../internals/environment-v8-version */ "./node_modules/core-js/internals/environment-v8-version.js");

	var NativePromisePrototype = NativePromiseConstructor && NativePromiseConstructor.prototype;
	var SPECIES = wellKnownSymbol('species');
	var SUBCLASSING = false;
	var NATIVE_PROMISE_REJECTION_EVENT = isCallable(globalThis.PromiseRejectionEvent);

	var FORCED_PROMISE_CONSTRUCTOR = isForced('Promise', function () {
	  var PROMISE_CONSTRUCTOR_SOURCE = inspectSource(NativePromiseConstructor);
	  var GLOBAL_CORE_JS_PROMISE = PROMISE_CONSTRUCTOR_SOURCE !== String(NativePromiseConstructor);
	  // V8 6.6 (Node 10 and Chrome 66) have a bug with resolving custom thenables
	  // https://bugs.chromium.org/p/chromium/issues/detail?id=830565
	  // We can't detect it synchronously, so just check versions
	  if (!GLOBAL_CORE_JS_PROMISE && V8_VERSION === 66) return true;
	  // We need Promise#{ catch, finally } in the pure version for preventing prototype pollution
	  if (IS_PURE && !(NativePromisePrototype['catch'] && NativePromisePrototype['finally'])) return true;
	  // We can't use @@species feature detection in V8 since it causes
	  // deoptimization and performance degradation
	  // https://github.com/zloirock/core-js/issues/679
	  if (!V8_VERSION || V8_VERSION < 51 || !/native code/.test(PROMISE_CONSTRUCTOR_SOURCE)) {
	    // Detect correctness of subclassing with @@species support
	    var promise = new NativePromiseConstructor(function (resolve) { resolve(1); });
	    var FakePromise = function (exec) {
	      exec(function () { /* empty */ }, function () { /* empty */ });
	    };
	    var constructor = promise.constructor = {};
	    constructor[SPECIES] = FakePromise;
	    SUBCLASSING = promise.then(function () { /* empty */ }) instanceof FakePromise;
	    if (!SUBCLASSING) return true;
	  // Unhandled rejections tracking support, NodeJS Promise without it fails @@species test
	  } return !GLOBAL_CORE_JS_PROMISE && (ENVIRONMENT === 'BROWSER' || ENVIRONMENT === 'DENO') && !NATIVE_PROMISE_REJECTION_EVENT;
	});

	module.exports = {
	  CONSTRUCTOR: FORCED_PROMISE_CONSTRUCTOR,
	  REJECTION_EVENT: NATIVE_PROMISE_REJECTION_EVENT,
	  SUBCLASSING: SUBCLASSING
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/promise-native-constructor.js":
	/*!**********************************************************************!*\
	  !*** ./node_modules/core-js/internals/promise-native-constructor.js ***!
	  \**********************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/core-js/internals/global-this.js");

	module.exports = globalThis.Promise;


	/***/ }),

	/***/ "./node_modules/core-js/internals/promise-resolve.js":
	/*!***********************************************************!*\
	  !*** ./node_modules/core-js/internals/promise-resolve.js ***!
	  \***********************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var anObject = __webpack_require__(/*! ../internals/an-object */ "./node_modules/core-js/internals/an-object.js");
	var isObject = __webpack_require__(/*! ../internals/is-object */ "./node_modules/core-js/internals/is-object.js");
	var newPromiseCapability = __webpack_require__(/*! ../internals/new-promise-capability */ "./node_modules/core-js/internals/new-promise-capability.js");

	module.exports = function (C, x) {
	  anObject(C);
	  if (isObject(x) && x.constructor === C) return x;
	  var promiseCapability = newPromiseCapability.f(C);
	  var resolve = promiseCapability.resolve;
	  resolve(x);
	  return promiseCapability.promise;
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/promise-statics-incorrect-iteration.js":
	/*!*******************************************************************************!*\
	  !*** ./node_modules/core-js/internals/promise-statics-incorrect-iteration.js ***!
	  \*******************************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var NativePromiseConstructor = __webpack_require__(/*! ../internals/promise-native-constructor */ "./node_modules/core-js/internals/promise-native-constructor.js");
	var checkCorrectnessOfIteration = __webpack_require__(/*! ../internals/check-correctness-of-iteration */ "./node_modules/core-js/internals/check-correctness-of-iteration.js");
	var FORCED_PROMISE_CONSTRUCTOR = (__webpack_require__(/*! ../internals/promise-constructor-detection */ "./node_modules/core-js/internals/promise-constructor-detection.js").CONSTRUCTOR);

	module.exports = FORCED_PROMISE_CONSTRUCTOR || !checkCorrectnessOfIteration(function (iterable) {
	  NativePromiseConstructor.all(iterable).then(undefined, function () { /* empty */ });
	});


	/***/ }),

	/***/ "./node_modules/core-js/internals/queue.js":
	/*!*************************************************!*\
	  !*** ./node_modules/core-js/internals/queue.js ***!
	  \*************************************************/
	/***/ (function(module) {


	var Queue = function () {
	  this.head = null;
	  this.tail = null;
	};

	Queue.prototype = {
	  add: function (item) {
	    var entry = { item: item, next: null };
	    var tail = this.tail;
	    if (tail) tail.next = entry;
	    else this.head = entry;
	    this.tail = entry;
	  },
	  get: function () {
	    var entry = this.head;
	    if (entry) {
	      var next = this.head = entry.next;
	      if (next === null) this.tail = null;
	      return entry.item;
	    }
	  }
	};

	module.exports = Queue;


	/***/ }),

	/***/ "./node_modules/core-js/internals/regexp-exec.js":
	/*!*******************************************************!*\
	  !*** ./node_modules/core-js/internals/regexp-exec.js ***!
	  \*******************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	/* eslint-disable regexp/no-empty-capturing-group, regexp/no-empty-group, regexp/no-lazy-ends -- testing */
	/* eslint-disable regexp/no-useless-quantifier -- testing */
	var call = __webpack_require__(/*! ../internals/function-call */ "./node_modules/core-js/internals/function-call.js");
	var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/core-js/internals/function-uncurry-this.js");
	var toString = __webpack_require__(/*! ../internals/to-string */ "./node_modules/core-js/internals/to-string.js");
	var regexpFlags = __webpack_require__(/*! ../internals/regexp-flags */ "./node_modules/core-js/internals/regexp-flags.js");
	var stickyHelpers = __webpack_require__(/*! ../internals/regexp-sticky-helpers */ "./node_modules/core-js/internals/regexp-sticky-helpers.js");
	var shared = __webpack_require__(/*! ../internals/shared */ "./node_modules/core-js/internals/shared.js");
	var create = __webpack_require__(/*! ../internals/object-create */ "./node_modules/core-js/internals/object-create.js");
	var getInternalState = (__webpack_require__(/*! ../internals/internal-state */ "./node_modules/core-js/internals/internal-state.js").get);
	var UNSUPPORTED_DOT_ALL = __webpack_require__(/*! ../internals/regexp-unsupported-dot-all */ "./node_modules/core-js/internals/regexp-unsupported-dot-all.js");
	var UNSUPPORTED_NCG = __webpack_require__(/*! ../internals/regexp-unsupported-ncg */ "./node_modules/core-js/internals/regexp-unsupported-ncg.js");

	var nativeReplace = shared('native-string-replace', String.prototype.replace);
	var nativeExec = RegExp.prototype.exec;
	var patchedExec = nativeExec;
	var charAt = uncurryThis(''.charAt);
	var indexOf = uncurryThis(''.indexOf);
	var replace = uncurryThis(''.replace);
	var stringSlice = uncurryThis(''.slice);

	var UPDATES_LAST_INDEX_WRONG = (function () {
	  var re1 = /a/;
	  var re2 = /b*/g;
	  call(nativeExec, re1, 'a');
	  call(nativeExec, re2, 'a');
	  return re1.lastIndex !== 0 || re2.lastIndex !== 0;
	})();

	var UNSUPPORTED_Y = stickyHelpers.BROKEN_CARET;

	// nonparticipating capturing group, copied from es5-shim's String#split patch.
	var NPCG_INCLUDED = /()??/.exec('')[1] !== undefined;

	var PATCH = UPDATES_LAST_INDEX_WRONG || NPCG_INCLUDED || UNSUPPORTED_Y || UNSUPPORTED_DOT_ALL || UNSUPPORTED_NCG;

	if (PATCH) {
	  patchedExec = function exec(string) {
	    var re = this;
	    var state = getInternalState(re);
	    var str = toString(string);
	    var raw = state.raw;
	    var result, reCopy, lastIndex, match, i, object, group;

	    if (raw) {
	      raw.lastIndex = re.lastIndex;
	      result = call(patchedExec, raw, str);
	      re.lastIndex = raw.lastIndex;
	      return result;
	    }

	    var groups = state.groups;
	    var sticky = UNSUPPORTED_Y && re.sticky;
	    var flags = call(regexpFlags, re);
	    var source = re.source;
	    var charsAdded = 0;
	    var strCopy = str;

	    if (sticky) {
	      flags = replace(flags, 'y', '');
	      if (indexOf(flags, 'g') === -1) {
	        flags += 'g';
	      }

	      strCopy = stringSlice(str, re.lastIndex);
	      // Support anchored sticky behavior.
	      if (re.lastIndex > 0 && (!re.multiline || re.multiline && charAt(str, re.lastIndex - 1) !== '\n')) {
	        source = '(?: ' + source + ')';
	        strCopy = ' ' + strCopy;
	        charsAdded++;
	      }
	      // ^(? + rx + ) is needed, in combination with some str slicing, to
	      // simulate the 'y' flag.
	      reCopy = new RegExp('^(?:' + source + ')', flags);
	    }

	    if (NPCG_INCLUDED) {
	      reCopy = new RegExp('^' + source + '$(?!\\s)', flags);
	    }
	    if (UPDATES_LAST_INDEX_WRONG) lastIndex = re.lastIndex;

	    match = call(nativeExec, sticky ? reCopy : re, strCopy);

	    if (sticky) {
	      if (match) {
	        match.input = stringSlice(match.input, charsAdded);
	        match[0] = stringSlice(match[0], charsAdded);
	        match.index = re.lastIndex;
	        re.lastIndex += match[0].length;
	      } else re.lastIndex = 0;
	    } else if (UPDATES_LAST_INDEX_WRONG && match) {
	      re.lastIndex = re.global ? match.index + match[0].length : lastIndex;
	    }
	    if (NPCG_INCLUDED && match && match.length > 1) {
	      // Fix browsers whose `exec` methods don't consistently return `undefined`
	      // for NPCG, like IE8. NOTE: This doesn't work for /(.?)?/
	      call(nativeReplace, match[0], reCopy, function () {
	        for (i = 1; i < arguments.length - 2; i++) {
	          if (arguments[i] === undefined) match[i] = undefined;
	        }
	      });
	    }

	    if (match && groups) {
	      match.groups = object = create(null);
	      for (i = 0; i < groups.length; i++) {
	        group = groups[i];
	        object[group[0]] = match[group[1]];
	      }
	    }

	    return match;
	  };
	}

	module.exports = patchedExec;


	/***/ }),

	/***/ "./node_modules/core-js/internals/regexp-flags-detection.js":
	/*!******************************************************************!*\
	  !*** ./node_modules/core-js/internals/regexp-flags-detection.js ***!
	  \******************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/core-js/internals/global-this.js");
	var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/core-js/internals/fails.js");

	// babel-minify and Closure Compiler transpiles RegExp('.', 'd') -> /./d and it causes SyntaxError
	var RegExp = globalThis.RegExp;

	var FLAGS_GETTER_IS_CORRECT = !fails(function () {
	  var INDICES_SUPPORT = true;
	  try {
	    RegExp('.', 'd');
	  } catch (error) {
	    INDICES_SUPPORT = false;
	  }

	  var O = {};
	  // modern V8 bug
	  var calls = '';
	  var expected = INDICES_SUPPORT ? 'dgimsy' : 'gimsy';

	  var addGetter = function (key, chr) {
	    // eslint-disable-next-line es/no-object-defineproperty -- safe
	    Object.defineProperty(O, key, { get: function () {
	      calls += chr;
	      return true;
	    } });
	  };

	  var pairs = {
	    dotAll: 's',
	    global: 'g',
	    ignoreCase: 'i',
	    multiline: 'm',
	    sticky: 'y'
	  };

	  if (INDICES_SUPPORT) pairs.hasIndices = 'd';

	  for (var key in pairs) addGetter(key, pairs[key]);

	  // eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
	  var result = Object.getOwnPropertyDescriptor(RegExp.prototype, 'flags').get.call(O);

	  return result !== expected || calls !== expected;
	});

	module.exports = { correct: FLAGS_GETTER_IS_CORRECT };


	/***/ }),

	/***/ "./node_modules/core-js/internals/regexp-flags.js":
	/*!********************************************************!*\
	  !*** ./node_modules/core-js/internals/regexp-flags.js ***!
	  \********************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var anObject = __webpack_require__(/*! ../internals/an-object */ "./node_modules/core-js/internals/an-object.js");

	// `RegExp.prototype.flags` getter implementation
	// https://tc39.es/ecma262/#sec-get-regexp.prototype.flags
	module.exports = function () {
	  var that = anObject(this);
	  var result = '';
	  if (that.hasIndices) result += 'd';
	  if (that.global) result += 'g';
	  if (that.ignoreCase) result += 'i';
	  if (that.multiline) result += 'm';
	  if (that.dotAll) result += 's';
	  if (that.unicode) result += 'u';
	  if (that.unicodeSets) result += 'v';
	  if (that.sticky) result += 'y';
	  return result;
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/regexp-get-flags.js":
	/*!************************************************************!*\
	  !*** ./node_modules/core-js/internals/regexp-get-flags.js ***!
	  \************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var call = __webpack_require__(/*! ../internals/function-call */ "./node_modules/core-js/internals/function-call.js");
	var hasOwn = __webpack_require__(/*! ../internals/has-own-property */ "./node_modules/core-js/internals/has-own-property.js");
	var isPrototypeOf = __webpack_require__(/*! ../internals/object-is-prototype-of */ "./node_modules/core-js/internals/object-is-prototype-of.js");
	var regExpFlagsDetection = __webpack_require__(/*! ../internals/regexp-flags-detection */ "./node_modules/core-js/internals/regexp-flags-detection.js");
	var regExpFlagsGetterImplementation = __webpack_require__(/*! ../internals/regexp-flags */ "./node_modules/core-js/internals/regexp-flags.js");

	var RegExpPrototype = RegExp.prototype;

	module.exports = regExpFlagsDetection.correct ? function (it) {
	  return it.flags;
	} : function (it) {
	  return (!regExpFlagsDetection.correct && isPrototypeOf(RegExpPrototype, it) && !hasOwn(it, 'flags'))
	    ? call(regExpFlagsGetterImplementation, it)
	    : it.flags;
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/regexp-sticky-helpers.js":
	/*!*****************************************************************!*\
	  !*** ./node_modules/core-js/internals/regexp-sticky-helpers.js ***!
	  \*****************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/core-js/internals/fails.js");
	var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/core-js/internals/global-this.js");

	// babel-minify and Closure Compiler transpiles RegExp('a', 'y') -> /a/y and it causes SyntaxError
	var $RegExp = globalThis.RegExp;

	var UNSUPPORTED_Y = fails(function () {
	  var re = $RegExp('a', 'y');
	  re.lastIndex = 2;
	  return re.exec('abcd') !== null;
	});

	// UC Browser bug
	// https://github.com/zloirock/core-js/issues/1008
	var MISSED_STICKY = UNSUPPORTED_Y || fails(function () {
	  return !$RegExp('a', 'y').sticky;
	});

	var BROKEN_CARET = UNSUPPORTED_Y || fails(function () {
	  // https://bugzilla.mozilla.org/show_bug.cgi?id=773687
	  var re = $RegExp('^r', 'gy');
	  re.lastIndex = 2;
	  return re.exec('str') !== null;
	});

	module.exports = {
	  BROKEN_CARET: BROKEN_CARET,
	  MISSED_STICKY: MISSED_STICKY,
	  UNSUPPORTED_Y: UNSUPPORTED_Y
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/regexp-unsupported-dot-all.js":
	/*!**********************************************************************!*\
	  !*** ./node_modules/core-js/internals/regexp-unsupported-dot-all.js ***!
	  \**********************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/core-js/internals/fails.js");
	var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/core-js/internals/global-this.js");

	// babel-minify and Closure Compiler transpiles RegExp('.', 's') -> /./s and it causes SyntaxError
	var $RegExp = globalThis.RegExp;

	module.exports = fails(function () {
	  var re = $RegExp('.', 's');
	  return !(re.dotAll && re.test('\n') && re.flags === 's');
	});


	/***/ }),

	/***/ "./node_modules/core-js/internals/regexp-unsupported-ncg.js":
	/*!******************************************************************!*\
	  !*** ./node_modules/core-js/internals/regexp-unsupported-ncg.js ***!
	  \******************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/core-js/internals/fails.js");
	var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/core-js/internals/global-this.js");

	// babel-minify and Closure Compiler transpiles RegExp('(?<a>b)', 'g') -> /(?<a>b)/g and it causes SyntaxError
	var $RegExp = globalThis.RegExp;

	module.exports = fails(function () {
	  var re = $RegExp('(?<a>b)', 'g');
	  return re.exec('b').groups.a !== 'b' ||
	    'b'.replace(re, '$<a>c') !== 'bc';
	});


	/***/ }),

	/***/ "./node_modules/core-js/internals/require-object-coercible.js":
	/*!********************************************************************!*\
	  !*** ./node_modules/core-js/internals/require-object-coercible.js ***!
	  \********************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var isNullOrUndefined = __webpack_require__(/*! ../internals/is-null-or-undefined */ "./node_modules/core-js/internals/is-null-or-undefined.js");

	var $TypeError = TypeError;

	// `RequireObjectCoercible` abstract operation
	// https://tc39.es/ecma262/#sec-requireobjectcoercible
	module.exports = function (it) {
	  if (isNullOrUndefined(it)) throw new $TypeError("Can't call method on " + it);
	  return it;
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/safe-get-built-in.js":
	/*!*************************************************************!*\
	  !*** ./node_modules/core-js/internals/safe-get-built-in.js ***!
	  \*************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/core-js/internals/global-this.js");
	var DESCRIPTORS = __webpack_require__(/*! ../internals/descriptors */ "./node_modules/core-js/internals/descriptors.js");

	// eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
	var getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;

	// Avoid NodeJS experimental warning
	module.exports = function (name) {
	  if (!DESCRIPTORS) return globalThis[name];
	  var descriptor = getOwnPropertyDescriptor(globalThis, name);
	  return descriptor && descriptor.value;
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/schedulers-fix.js":
	/*!**********************************************************!*\
	  !*** ./node_modules/core-js/internals/schedulers-fix.js ***!
	  \**********************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/core-js/internals/global-this.js");
	var apply = __webpack_require__(/*! ../internals/function-apply */ "./node_modules/core-js/internals/function-apply.js");
	var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/core-js/internals/is-callable.js");
	var ENVIRONMENT = __webpack_require__(/*! ../internals/environment */ "./node_modules/core-js/internals/environment.js");
	var USER_AGENT = __webpack_require__(/*! ../internals/environment-user-agent */ "./node_modules/core-js/internals/environment-user-agent.js");
	var arraySlice = __webpack_require__(/*! ../internals/array-slice */ "./node_modules/core-js/internals/array-slice.js");
	var validateArgumentsLength = __webpack_require__(/*! ../internals/validate-arguments-length */ "./node_modules/core-js/internals/validate-arguments-length.js");

	var Function = globalThis.Function;
	// dirty IE9- and Bun 0.3.0- checks
	var WRAP = /MSIE .\./.test(USER_AGENT) || ENVIRONMENT === 'BUN' && (function () {
	  var version = globalThis.Bun.version.split('.');
	  return version.length < 3 || version[0] === '0' && (version[1] < 3 || version[1] === '3' && version[2] === '0');
	})();

	// IE9- / Bun 0.3.0- setTimeout / setInterval / setImmediate additional parameters fix
	// https://html.spec.whatwg.org/multipage/timers-and-user-prompts.html#timers
	// https://github.com/oven-sh/bun/issues/1633
	module.exports = function (scheduler, hasTimeArg) {
	  var firstParamIndex = hasTimeArg ? 2 : 1;
	  return WRAP ? function (handler, timeout /* , ...arguments */) {
	    var boundArgs = validateArgumentsLength(arguments.length, 1) > firstParamIndex;
	    var fn = isCallable(handler) ? handler : Function(handler);
	    var params = boundArgs ? arraySlice(arguments, firstParamIndex) : [];
	    var callback = boundArgs ? function () {
	      apply(fn, this, params);
	    } : fn;
	    return hasTimeArg ? scheduler(callback, timeout) : scheduler(callback);
	  } : scheduler;
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/set-clone.js":
	/*!*****************************************************!*\
	  !*** ./node_modules/core-js/internals/set-clone.js ***!
	  \*****************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var SetHelpers = __webpack_require__(/*! ../internals/set-helpers */ "./node_modules/core-js/internals/set-helpers.js");
	var iterate = __webpack_require__(/*! ../internals/set-iterate */ "./node_modules/core-js/internals/set-iterate.js");

	var Set = SetHelpers.Set;
	var add = SetHelpers.add;

	module.exports = function (set) {
	  var result = new Set();
	  iterate(set, function (it) {
	    add(result, it);
	  });
	  return result;
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/set-difference.js":
	/*!**********************************************************!*\
	  !*** ./node_modules/core-js/internals/set-difference.js ***!
	  \**********************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var aSet = __webpack_require__(/*! ../internals/a-set */ "./node_modules/core-js/internals/a-set.js");
	var SetHelpers = __webpack_require__(/*! ../internals/set-helpers */ "./node_modules/core-js/internals/set-helpers.js");
	var clone = __webpack_require__(/*! ../internals/set-clone */ "./node_modules/core-js/internals/set-clone.js");
	var size = __webpack_require__(/*! ../internals/set-size */ "./node_modules/core-js/internals/set-size.js");
	var getSetRecord = __webpack_require__(/*! ../internals/get-set-record */ "./node_modules/core-js/internals/get-set-record.js");
	var iterateSet = __webpack_require__(/*! ../internals/set-iterate */ "./node_modules/core-js/internals/set-iterate.js");
	var iterateSimple = __webpack_require__(/*! ../internals/iterate-simple */ "./node_modules/core-js/internals/iterate-simple.js");

	var has = SetHelpers.has;
	var remove = SetHelpers.remove;

	// `Set.prototype.difference` method
	// https://tc39.es/ecma262/#sec-set.prototype.difference
	module.exports = function difference(other) {
	  var O = aSet(this);
	  var otherRec = getSetRecord(other);
	  var result = clone(O);
	  if (size(O) <= otherRec.size) iterateSet(O, function (e) {
	    if (otherRec.includes(e)) remove(result, e);
	  });
	  else iterateSimple(otherRec.getIterator(), function (e) {
	    if (has(result, e)) remove(result, e);
	  });
	  return result;
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/set-helpers.js":
	/*!*******************************************************!*\
	  !*** ./node_modules/core-js/internals/set-helpers.js ***!
	  \*******************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/core-js/internals/function-uncurry-this.js");

	// eslint-disable-next-line es/no-set -- safe
	var SetPrototype = Set.prototype;

	module.exports = {
	  // eslint-disable-next-line es/no-set -- safe
	  Set: Set,
	  add: uncurryThis(SetPrototype.add),
	  has: uncurryThis(SetPrototype.has),
	  remove: uncurryThis(SetPrototype['delete']),
	  proto: SetPrototype
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/set-intersection.js":
	/*!************************************************************!*\
	  !*** ./node_modules/core-js/internals/set-intersection.js ***!
	  \************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var aSet = __webpack_require__(/*! ../internals/a-set */ "./node_modules/core-js/internals/a-set.js");
	var SetHelpers = __webpack_require__(/*! ../internals/set-helpers */ "./node_modules/core-js/internals/set-helpers.js");
	var size = __webpack_require__(/*! ../internals/set-size */ "./node_modules/core-js/internals/set-size.js");
	var getSetRecord = __webpack_require__(/*! ../internals/get-set-record */ "./node_modules/core-js/internals/get-set-record.js");
	var iterateSet = __webpack_require__(/*! ../internals/set-iterate */ "./node_modules/core-js/internals/set-iterate.js");
	var iterateSimple = __webpack_require__(/*! ../internals/iterate-simple */ "./node_modules/core-js/internals/iterate-simple.js");

	var Set = SetHelpers.Set;
	var add = SetHelpers.add;
	var has = SetHelpers.has;

	// `Set.prototype.intersection` method
	// https://tc39.es/ecma262/#sec-set.prototype.intersection
	module.exports = function intersection(other) {
	  var O = aSet(this);
	  var otherRec = getSetRecord(other);
	  var result = new Set();

	  if (size(O) > otherRec.size) {
	    iterateSimple(otherRec.getIterator(), function (e) {
	      if (has(O, e)) add(result, e);
	    });
	  } else {
	    iterateSet(O, function (e) {
	      if (otherRec.includes(e)) add(result, e);
	    });
	  }

	  return result;
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/set-is-disjoint-from.js":
	/*!****************************************************************!*\
	  !*** ./node_modules/core-js/internals/set-is-disjoint-from.js ***!
	  \****************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var aSet = __webpack_require__(/*! ../internals/a-set */ "./node_modules/core-js/internals/a-set.js");
	var has = (__webpack_require__(/*! ../internals/set-helpers */ "./node_modules/core-js/internals/set-helpers.js").has);
	var size = __webpack_require__(/*! ../internals/set-size */ "./node_modules/core-js/internals/set-size.js");
	var getSetRecord = __webpack_require__(/*! ../internals/get-set-record */ "./node_modules/core-js/internals/get-set-record.js");
	var iterateSet = __webpack_require__(/*! ../internals/set-iterate */ "./node_modules/core-js/internals/set-iterate.js");
	var iterateSimple = __webpack_require__(/*! ../internals/iterate-simple */ "./node_modules/core-js/internals/iterate-simple.js");
	var iteratorClose = __webpack_require__(/*! ../internals/iterator-close */ "./node_modules/core-js/internals/iterator-close.js");

	// `Set.prototype.isDisjointFrom` method
	// https://tc39.es/ecma262/#sec-set.prototype.isdisjointfrom
	module.exports = function isDisjointFrom(other) {
	  var O = aSet(this);
	  var otherRec = getSetRecord(other);
	  if (size(O) <= otherRec.size) return iterateSet(O, function (e) {
	    if (otherRec.includes(e)) return false;
	  }, true) !== false;
	  var iterator = otherRec.getIterator();
	  return iterateSimple(iterator, function (e) {
	    if (has(O, e)) return iteratorClose(iterator, 'normal', false);
	  }) !== false;
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/set-is-subset-of.js":
	/*!************************************************************!*\
	  !*** ./node_modules/core-js/internals/set-is-subset-of.js ***!
	  \************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var aSet = __webpack_require__(/*! ../internals/a-set */ "./node_modules/core-js/internals/a-set.js");
	var size = __webpack_require__(/*! ../internals/set-size */ "./node_modules/core-js/internals/set-size.js");
	var iterate = __webpack_require__(/*! ../internals/set-iterate */ "./node_modules/core-js/internals/set-iterate.js");
	var getSetRecord = __webpack_require__(/*! ../internals/get-set-record */ "./node_modules/core-js/internals/get-set-record.js");

	// `Set.prototype.isSubsetOf` method
	// https://tc39.es/ecma262/#sec-set.prototype.issubsetof
	module.exports = function isSubsetOf(other) {
	  var O = aSet(this);
	  var otherRec = getSetRecord(other);
	  if (size(O) > otherRec.size) return false;
	  return iterate(O, function (e) {
	    if (!otherRec.includes(e)) return false;
	  }, true) !== false;
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/set-is-superset-of.js":
	/*!**************************************************************!*\
	  !*** ./node_modules/core-js/internals/set-is-superset-of.js ***!
	  \**************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var aSet = __webpack_require__(/*! ../internals/a-set */ "./node_modules/core-js/internals/a-set.js");
	var has = (__webpack_require__(/*! ../internals/set-helpers */ "./node_modules/core-js/internals/set-helpers.js").has);
	var size = __webpack_require__(/*! ../internals/set-size */ "./node_modules/core-js/internals/set-size.js");
	var getSetRecord = __webpack_require__(/*! ../internals/get-set-record */ "./node_modules/core-js/internals/get-set-record.js");
	var iterateSimple = __webpack_require__(/*! ../internals/iterate-simple */ "./node_modules/core-js/internals/iterate-simple.js");
	var iteratorClose = __webpack_require__(/*! ../internals/iterator-close */ "./node_modules/core-js/internals/iterator-close.js");

	// `Set.prototype.isSupersetOf` method
	// https://tc39.es/ecma262/#sec-set.prototype.issupersetof
	module.exports = function isSupersetOf(other) {
	  var O = aSet(this);
	  var otherRec = getSetRecord(other);
	  if (size(O) < otherRec.size) return false;
	  var iterator = otherRec.getIterator();
	  return iterateSimple(iterator, function (e) {
	    if (!has(O, e)) return iteratorClose(iterator, 'normal', false);
	  }) !== false;
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/set-iterate.js":
	/*!*******************************************************!*\
	  !*** ./node_modules/core-js/internals/set-iterate.js ***!
	  \*******************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/core-js/internals/function-uncurry-this.js");
	var iterateSimple = __webpack_require__(/*! ../internals/iterate-simple */ "./node_modules/core-js/internals/iterate-simple.js");
	var SetHelpers = __webpack_require__(/*! ../internals/set-helpers */ "./node_modules/core-js/internals/set-helpers.js");

	var Set = SetHelpers.Set;
	var SetPrototype = SetHelpers.proto;
	var forEach = uncurryThis(SetPrototype.forEach);
	var keys = uncurryThis(SetPrototype.keys);
	var next = keys(new Set()).next;

	module.exports = function (set, fn, interruptible) {
	  return interruptible ? iterateSimple({ iterator: keys(set), next: next }, fn) : forEach(set, fn);
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/set-size.js":
	/*!****************************************************!*\
	  !*** ./node_modules/core-js/internals/set-size.js ***!
	  \****************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var uncurryThisAccessor = __webpack_require__(/*! ../internals/function-uncurry-this-accessor */ "./node_modules/core-js/internals/function-uncurry-this-accessor.js");
	var SetHelpers = __webpack_require__(/*! ../internals/set-helpers */ "./node_modules/core-js/internals/set-helpers.js");

	module.exports = uncurryThisAccessor(SetHelpers.proto, 'size', 'get') || function (set) {
	  return set.size;
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/set-species.js":
	/*!*******************************************************!*\
	  !*** ./node_modules/core-js/internals/set-species.js ***!
	  \*******************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var getBuiltIn = __webpack_require__(/*! ../internals/get-built-in */ "./node_modules/core-js/internals/get-built-in.js");
	var defineBuiltInAccessor = __webpack_require__(/*! ../internals/define-built-in-accessor */ "./node_modules/core-js/internals/define-built-in-accessor.js");
	var wellKnownSymbol = __webpack_require__(/*! ../internals/well-known-symbol */ "./node_modules/core-js/internals/well-known-symbol.js");
	var DESCRIPTORS = __webpack_require__(/*! ../internals/descriptors */ "./node_modules/core-js/internals/descriptors.js");

	var SPECIES = wellKnownSymbol('species');

	module.exports = function (CONSTRUCTOR_NAME) {
	  var Constructor = getBuiltIn(CONSTRUCTOR_NAME);

	  if (DESCRIPTORS && Constructor && !Constructor[SPECIES]) {
	    defineBuiltInAccessor(Constructor, SPECIES, {
	      configurable: true,
	      get: function () { return this; }
	    });
	  }
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/set-symmetric-difference.js":
	/*!********************************************************************!*\
	  !*** ./node_modules/core-js/internals/set-symmetric-difference.js ***!
	  \********************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var aSet = __webpack_require__(/*! ../internals/a-set */ "./node_modules/core-js/internals/a-set.js");
	var SetHelpers = __webpack_require__(/*! ../internals/set-helpers */ "./node_modules/core-js/internals/set-helpers.js");
	var clone = __webpack_require__(/*! ../internals/set-clone */ "./node_modules/core-js/internals/set-clone.js");
	var getSetRecord = __webpack_require__(/*! ../internals/get-set-record */ "./node_modules/core-js/internals/get-set-record.js");
	var iterateSimple = __webpack_require__(/*! ../internals/iterate-simple */ "./node_modules/core-js/internals/iterate-simple.js");

	var add = SetHelpers.add;
	var has = SetHelpers.has;
	var remove = SetHelpers.remove;

	// `Set.prototype.symmetricDifference` method
	// https://tc39.es/ecma262/#sec-set.prototype.symmetricdifference
	module.exports = function symmetricDifference(other) {
	  var O = aSet(this);
	  var keysIter = getSetRecord(other).getIterator();
	  var result = clone(O);
	  iterateSimple(keysIter, function (e) {
	    if (has(O, e)) remove(result, e);
	    else add(result, e);
	  });
	  return result;
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/set-to-string-tag.js":
	/*!*************************************************************!*\
	  !*** ./node_modules/core-js/internals/set-to-string-tag.js ***!
	  \*************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var defineProperty = (__webpack_require__(/*! ../internals/object-define-property */ "./node_modules/core-js/internals/object-define-property.js").f);
	var hasOwn = __webpack_require__(/*! ../internals/has-own-property */ "./node_modules/core-js/internals/has-own-property.js");
	var wellKnownSymbol = __webpack_require__(/*! ../internals/well-known-symbol */ "./node_modules/core-js/internals/well-known-symbol.js");

	var TO_STRING_TAG = wellKnownSymbol('toStringTag');

	module.exports = function (target, TAG, STATIC) {
	  if (target && !STATIC) target = target.prototype;
	  if (target && !hasOwn(target, TO_STRING_TAG)) {
	    defineProperty(target, TO_STRING_TAG, { configurable: true, value: TAG });
	  }
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/set-union.js":
	/*!*****************************************************!*\
	  !*** ./node_modules/core-js/internals/set-union.js ***!
	  \*****************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var aSet = __webpack_require__(/*! ../internals/a-set */ "./node_modules/core-js/internals/a-set.js");
	var add = (__webpack_require__(/*! ../internals/set-helpers */ "./node_modules/core-js/internals/set-helpers.js").add);
	var clone = __webpack_require__(/*! ../internals/set-clone */ "./node_modules/core-js/internals/set-clone.js");
	var getSetRecord = __webpack_require__(/*! ../internals/get-set-record */ "./node_modules/core-js/internals/get-set-record.js");
	var iterateSimple = __webpack_require__(/*! ../internals/iterate-simple */ "./node_modules/core-js/internals/iterate-simple.js");

	// `Set.prototype.union` method
	// https://tc39.es/ecma262/#sec-set.prototype.union
	module.exports = function union(other) {
	  var O = aSet(this);
	  var keysIter = getSetRecord(other).getIterator();
	  var result = clone(O);
	  iterateSimple(keysIter, function (it) {
	    add(result, it);
	  });
	  return result;
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/shared-key.js":
	/*!******************************************************!*\
	  !*** ./node_modules/core-js/internals/shared-key.js ***!
	  \******************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var shared = __webpack_require__(/*! ../internals/shared */ "./node_modules/core-js/internals/shared.js");
	var uid = __webpack_require__(/*! ../internals/uid */ "./node_modules/core-js/internals/uid.js");

	var keys = shared('keys');

	module.exports = function (key) {
	  return keys[key] || (keys[key] = uid(key));
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/shared-store.js":
	/*!********************************************************!*\
	  !*** ./node_modules/core-js/internals/shared-store.js ***!
	  \********************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var IS_PURE = __webpack_require__(/*! ../internals/is-pure */ "./node_modules/core-js/internals/is-pure.js");
	var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/core-js/internals/global-this.js");
	var defineGlobalProperty = __webpack_require__(/*! ../internals/define-global-property */ "./node_modules/core-js/internals/define-global-property.js");

	var SHARED = '__core-js_shared__';
	var store = module.exports = globalThis[SHARED] || defineGlobalProperty(SHARED, {});

	(store.versions || (store.versions = [])).push({
	  version: '3.45.1',
	  mode: IS_PURE ? 'pure' : 'global',
	  copyright: '© 2014-2025 Denis Pushkarev (zloirock.ru)',
	  license: 'https://github.com/zloirock/core-js/blob/v3.45.1/LICENSE',
	  source: 'https://github.com/zloirock/core-js'
	});


	/***/ }),

	/***/ "./node_modules/core-js/internals/shared.js":
	/*!**************************************************!*\
	  !*** ./node_modules/core-js/internals/shared.js ***!
	  \**************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var store = __webpack_require__(/*! ../internals/shared-store */ "./node_modules/core-js/internals/shared-store.js");

	module.exports = function (key, value) {
	  return store[key] || (store[key] = value || {});
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/species-constructor.js":
	/*!***************************************************************!*\
	  !*** ./node_modules/core-js/internals/species-constructor.js ***!
	  \***************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var anObject = __webpack_require__(/*! ../internals/an-object */ "./node_modules/core-js/internals/an-object.js");
	var aConstructor = __webpack_require__(/*! ../internals/a-constructor */ "./node_modules/core-js/internals/a-constructor.js");
	var isNullOrUndefined = __webpack_require__(/*! ../internals/is-null-or-undefined */ "./node_modules/core-js/internals/is-null-or-undefined.js");
	var wellKnownSymbol = __webpack_require__(/*! ../internals/well-known-symbol */ "./node_modules/core-js/internals/well-known-symbol.js");

	var SPECIES = wellKnownSymbol('species');

	// `SpeciesConstructor` abstract operation
	// https://tc39.es/ecma262/#sec-speciesconstructor
	module.exports = function (O, defaultConstructor) {
	  var C = anObject(O).constructor;
	  var S;
	  return C === undefined || isNullOrUndefined(S = anObject(C)[SPECIES]) ? defaultConstructor : aConstructor(S);
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/string-html-forced.js":
	/*!**************************************************************!*\
	  !*** ./node_modules/core-js/internals/string-html-forced.js ***!
	  \**************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/core-js/internals/fails.js");

	// check the existence of a method, lowercase
	// of a tag and escaping quotes in arguments
	module.exports = function (METHOD_NAME) {
	  return fails(function () {
	    var test = ''[METHOD_NAME]('"');
	    return test !== test.toLowerCase() || test.split('"').length > 3;
	  });
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/string-multibyte.js":
	/*!************************************************************!*\
	  !*** ./node_modules/core-js/internals/string-multibyte.js ***!
	  \************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/core-js/internals/function-uncurry-this.js");
	var toIntegerOrInfinity = __webpack_require__(/*! ../internals/to-integer-or-infinity */ "./node_modules/core-js/internals/to-integer-or-infinity.js");
	var toString = __webpack_require__(/*! ../internals/to-string */ "./node_modules/core-js/internals/to-string.js");
	var requireObjectCoercible = __webpack_require__(/*! ../internals/require-object-coercible */ "./node_modules/core-js/internals/require-object-coercible.js");

	var charAt = uncurryThis(''.charAt);
	var charCodeAt = uncurryThis(''.charCodeAt);
	var stringSlice = uncurryThis(''.slice);

	var createMethod = function (CONVERT_TO_STRING) {
	  return function ($this, pos) {
	    var S = toString(requireObjectCoercible($this));
	    var position = toIntegerOrInfinity(pos);
	    var size = S.length;
	    var first, second;
	    if (position < 0 || position >= size) return CONVERT_TO_STRING ? '' : undefined;
	    first = charCodeAt(S, position);
	    return first < 0xD800 || first > 0xDBFF || position + 1 === size
	      || (second = charCodeAt(S, position + 1)) < 0xDC00 || second > 0xDFFF
	        ? CONVERT_TO_STRING
	          ? charAt(S, position)
	          : first
	        : CONVERT_TO_STRING
	          ? stringSlice(S, position, position + 2)
	          : (first - 0xD800 << 10) + (second - 0xDC00) + 0x10000;
	  };
	};

	module.exports = {
	  // `String.prototype.codePointAt` method
	  // https://tc39.es/ecma262/#sec-string.prototype.codepointat
	  codeAt: createMethod(false),
	  // `String.prototype.at` method
	  // https://github.com/mathiasbynens/String.prototype.at
	  charAt: createMethod(true)
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/string-trim.js":
	/*!*******************************************************!*\
	  !*** ./node_modules/core-js/internals/string-trim.js ***!
	  \*******************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/core-js/internals/function-uncurry-this.js");
	var requireObjectCoercible = __webpack_require__(/*! ../internals/require-object-coercible */ "./node_modules/core-js/internals/require-object-coercible.js");
	var toString = __webpack_require__(/*! ../internals/to-string */ "./node_modules/core-js/internals/to-string.js");
	var whitespaces = __webpack_require__(/*! ../internals/whitespaces */ "./node_modules/core-js/internals/whitespaces.js");

	var replace = uncurryThis(''.replace);
	var ltrim = RegExp('^[' + whitespaces + ']+');
	var rtrim = RegExp('(^|[^' + whitespaces + '])[' + whitespaces + ']+$');

	// `String.prototype.{ trim, trimStart, trimEnd, trimLeft, trimRight }` methods implementation
	var createMethod = function (TYPE) {
	  return function ($this) {
	    var string = toString(requireObjectCoercible($this));
	    if (TYPE & 1) string = replace(string, ltrim, '');
	    if (TYPE & 2) string = replace(string, rtrim, '$1');
	    return string;
	  };
	};

	module.exports = {
	  // `String.prototype.{ trimLeft, trimStart }` methods
	  // https://tc39.es/ecma262/#sec-string.prototype.trimstart
	  start: createMethod(1),
	  // `String.prototype.{ trimRight, trimEnd }` methods
	  // https://tc39.es/ecma262/#sec-string.prototype.trimend
	  end: createMethod(2),
	  // `String.prototype.trim` method
	  // https://tc39.es/ecma262/#sec-string.prototype.trim
	  trim: createMethod(3)
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/symbol-constructor-detection.js":
	/*!************************************************************************!*\
	  !*** ./node_modules/core-js/internals/symbol-constructor-detection.js ***!
	  \************************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	/* eslint-disable es/no-symbol -- required for testing */
	var V8_VERSION = __webpack_require__(/*! ../internals/environment-v8-version */ "./node_modules/core-js/internals/environment-v8-version.js");
	var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/core-js/internals/fails.js");
	var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/core-js/internals/global-this.js");

	var $String = globalThis.String;

	// eslint-disable-next-line es/no-object-getownpropertysymbols -- required for testing
	module.exports = !!Object.getOwnPropertySymbols && !fails(function () {
	  var symbol = Symbol('symbol detection');
	  // Chrome 38 Symbol has incorrect toString conversion
	  // `get-own-property-symbols` polyfill symbols converted to object are not Symbol instances
	  // nb: Do not call `String` directly to avoid this being optimized out to `symbol+''` which will,
	  // of course, fail.
	  return !$String(symbol) || !(Object(symbol) instanceof Symbol) ||
	    // Chrome 38-40 symbols are not inherited from DOM collections prototypes to instances
	    !Symbol.sham && V8_VERSION && V8_VERSION < 41;
	});


	/***/ }),

	/***/ "./node_modules/core-js/internals/symbol-define-to-primitive.js":
	/*!**********************************************************************!*\
	  !*** ./node_modules/core-js/internals/symbol-define-to-primitive.js ***!
	  \**********************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var call = __webpack_require__(/*! ../internals/function-call */ "./node_modules/core-js/internals/function-call.js");
	var getBuiltIn = __webpack_require__(/*! ../internals/get-built-in */ "./node_modules/core-js/internals/get-built-in.js");
	var wellKnownSymbol = __webpack_require__(/*! ../internals/well-known-symbol */ "./node_modules/core-js/internals/well-known-symbol.js");
	var defineBuiltIn = __webpack_require__(/*! ../internals/define-built-in */ "./node_modules/core-js/internals/define-built-in.js");

	module.exports = function () {
	  var Symbol = getBuiltIn('Symbol');
	  var SymbolPrototype = Symbol && Symbol.prototype;
	  var valueOf = SymbolPrototype && SymbolPrototype.valueOf;
	  var TO_PRIMITIVE = wellKnownSymbol('toPrimitive');

	  if (SymbolPrototype && !SymbolPrototype[TO_PRIMITIVE]) {
	    // `Symbol.prototype[@@toPrimitive]` method
	    // https://tc39.es/ecma262/#sec-symbol.prototype-@@toprimitive
	    // eslint-disable-next-line no-unused-vars -- required for .length
	    defineBuiltIn(SymbolPrototype, TO_PRIMITIVE, function (hint) {
	      return call(valueOf, this);
	    }, { arity: 1 });
	  }
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/symbol-registry-detection.js":
	/*!*********************************************************************!*\
	  !*** ./node_modules/core-js/internals/symbol-registry-detection.js ***!
	  \*********************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var NATIVE_SYMBOL = __webpack_require__(/*! ../internals/symbol-constructor-detection */ "./node_modules/core-js/internals/symbol-constructor-detection.js");

	/* eslint-disable es/no-symbol -- safe */
	module.exports = NATIVE_SYMBOL && !!Symbol['for'] && !!Symbol.keyFor;


	/***/ }),

	/***/ "./node_modules/core-js/internals/task.js":
	/*!************************************************!*\
	  !*** ./node_modules/core-js/internals/task.js ***!
	  \************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/core-js/internals/global-this.js");
	var apply = __webpack_require__(/*! ../internals/function-apply */ "./node_modules/core-js/internals/function-apply.js");
	var bind = __webpack_require__(/*! ../internals/function-bind-context */ "./node_modules/core-js/internals/function-bind-context.js");
	var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/core-js/internals/is-callable.js");
	var hasOwn = __webpack_require__(/*! ../internals/has-own-property */ "./node_modules/core-js/internals/has-own-property.js");
	var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/core-js/internals/fails.js");
	var html = __webpack_require__(/*! ../internals/html */ "./node_modules/core-js/internals/html.js");
	var arraySlice = __webpack_require__(/*! ../internals/array-slice */ "./node_modules/core-js/internals/array-slice.js");
	var createElement = __webpack_require__(/*! ../internals/document-create-element */ "./node_modules/core-js/internals/document-create-element.js");
	var validateArgumentsLength = __webpack_require__(/*! ../internals/validate-arguments-length */ "./node_modules/core-js/internals/validate-arguments-length.js");
	var IS_IOS = __webpack_require__(/*! ../internals/environment-is-ios */ "./node_modules/core-js/internals/environment-is-ios.js");
	var IS_NODE = __webpack_require__(/*! ../internals/environment-is-node */ "./node_modules/core-js/internals/environment-is-node.js");

	var set = globalThis.setImmediate;
	var clear = globalThis.clearImmediate;
	var process = globalThis.process;
	var Dispatch = globalThis.Dispatch;
	var Function = globalThis.Function;
	var MessageChannel = globalThis.MessageChannel;
	var String = globalThis.String;
	var counter = 0;
	var queue = {};
	var ONREADYSTATECHANGE = 'onreadystatechange';
	var $location, defer, channel, port;

	fails(function () {
	  // Deno throws a ReferenceError on `location` access without `--location` flag
	  $location = globalThis.location;
	});

	var run = function (id) {
	  if (hasOwn(queue, id)) {
	    var fn = queue[id];
	    delete queue[id];
	    fn();
	  }
	};

	var runner = function (id) {
	  return function () {
	    run(id);
	  };
	};

	var eventListener = function (event) {
	  run(event.data);
	};

	var globalPostMessageDefer = function (id) {
	  // old engines have not location.origin
	  globalThis.postMessage(String(id), $location.protocol + '//' + $location.host);
	};

	// Node.js 0.9+ & IE10+ has setImmediate, otherwise:
	if (!set || !clear) {
	  set = function setImmediate(handler) {
	    validateArgumentsLength(arguments.length, 1);
	    var fn = isCallable(handler) ? handler : Function(handler);
	    var args = arraySlice(arguments, 1);
	    queue[++counter] = function () {
	      apply(fn, undefined, args);
	    };
	    defer(counter);
	    return counter;
	  };
	  clear = function clearImmediate(id) {
	    delete queue[id];
	  };
	  // Node.js 0.8-
	  if (IS_NODE) {
	    defer = function (id) {
	      process.nextTick(runner(id));
	    };
	  // Sphere (JS game engine) Dispatch API
	  } else if (Dispatch && Dispatch.now) {
	    defer = function (id) {
	      Dispatch.now(runner(id));
	    };
	  // Browsers with MessageChannel, includes WebWorkers
	  // except iOS - https://github.com/zloirock/core-js/issues/624
	  } else if (MessageChannel && !IS_IOS) {
	    channel = new MessageChannel();
	    port = channel.port2;
	    channel.port1.onmessage = eventListener;
	    defer = bind(port.postMessage, port);
	  // Browsers with postMessage, skip WebWorkers
	  // IE8 has postMessage, but it's sync & typeof its postMessage is 'object'
	  } else if (
	    globalThis.addEventListener &&
	    isCallable(globalThis.postMessage) &&
	    !globalThis.importScripts &&
	    $location && $location.protocol !== 'file:' &&
	    !fails(globalPostMessageDefer)
	  ) {
	    defer = globalPostMessageDefer;
	    globalThis.addEventListener('message', eventListener, false);
	  // IE8-
	  } else if (ONREADYSTATECHANGE in createElement('script')) {
	    defer = function (id) {
	      html.appendChild(createElement('script'))[ONREADYSTATECHANGE] = function () {
	        html.removeChild(this);
	        run(id);
	      };
	    };
	  // Rest old browsers
	  } else {
	    defer = function (id) {
	      setTimeout(runner(id), 0);
	    };
	  }
	}

	module.exports = {
	  set: set,
	  clear: clear
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/this-number-value.js":
	/*!*************************************************************!*\
	  !*** ./node_modules/core-js/internals/this-number-value.js ***!
	  \*************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/core-js/internals/function-uncurry-this.js");

	// `thisNumberValue` abstract operation
	// https://tc39.es/ecma262/#sec-thisnumbervalue
	module.exports = uncurryThis(1.1.valueOf);


	/***/ }),

	/***/ "./node_modules/core-js/internals/to-absolute-index.js":
	/*!*************************************************************!*\
	  !*** ./node_modules/core-js/internals/to-absolute-index.js ***!
	  \*************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var toIntegerOrInfinity = __webpack_require__(/*! ../internals/to-integer-or-infinity */ "./node_modules/core-js/internals/to-integer-or-infinity.js");

	var max = Math.max;
	var min = Math.min;

	// Helper for a popular repeating case of the spec:
	// Let integer be ? ToInteger(index).
	// If integer < 0, let result be max((length + integer), 0); else let result be min(integer, length).
	module.exports = function (index, length) {
	  var integer = toIntegerOrInfinity(index);
	  return integer < 0 ? max(integer + length, 0) : min(integer, length);
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/to-indexed-object.js":
	/*!*************************************************************!*\
	  !*** ./node_modules/core-js/internals/to-indexed-object.js ***!
	  \*************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	// toObject with fallback for non-array-like ES3 strings
	var IndexedObject = __webpack_require__(/*! ../internals/indexed-object */ "./node_modules/core-js/internals/indexed-object.js");
	var requireObjectCoercible = __webpack_require__(/*! ../internals/require-object-coercible */ "./node_modules/core-js/internals/require-object-coercible.js");

	module.exports = function (it) {
	  return IndexedObject(requireObjectCoercible(it));
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/to-integer-or-infinity.js":
	/*!******************************************************************!*\
	  !*** ./node_modules/core-js/internals/to-integer-or-infinity.js ***!
	  \******************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var trunc = __webpack_require__(/*! ../internals/math-trunc */ "./node_modules/core-js/internals/math-trunc.js");

	// `ToIntegerOrInfinity` abstract operation
	// https://tc39.es/ecma262/#sec-tointegerorinfinity
	module.exports = function (argument) {
	  var number = +argument;
	  // eslint-disable-next-line no-self-compare -- NaN check
	  return number !== number || number === 0 ? 0 : trunc(number);
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/to-length.js":
	/*!*****************************************************!*\
	  !*** ./node_modules/core-js/internals/to-length.js ***!
	  \*****************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var toIntegerOrInfinity = __webpack_require__(/*! ../internals/to-integer-or-infinity */ "./node_modules/core-js/internals/to-integer-or-infinity.js");

	var min = Math.min;

	// `ToLength` abstract operation
	// https://tc39.es/ecma262/#sec-tolength
	module.exports = function (argument) {
	  var len = toIntegerOrInfinity(argument);
	  return len > 0 ? min(len, 0x1FFFFFFFFFFFFF) : 0; // 2 ** 53 - 1 == 9007199254740991
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/to-object.js":
	/*!*****************************************************!*\
	  !*** ./node_modules/core-js/internals/to-object.js ***!
	  \*****************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var requireObjectCoercible = __webpack_require__(/*! ../internals/require-object-coercible */ "./node_modules/core-js/internals/require-object-coercible.js");

	var $Object = Object;

	// `ToObject` abstract operation
	// https://tc39.es/ecma262/#sec-toobject
	module.exports = function (argument) {
	  return $Object(requireObjectCoercible(argument));
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/to-primitive.js":
	/*!********************************************************!*\
	  !*** ./node_modules/core-js/internals/to-primitive.js ***!
	  \********************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var call = __webpack_require__(/*! ../internals/function-call */ "./node_modules/core-js/internals/function-call.js");
	var isObject = __webpack_require__(/*! ../internals/is-object */ "./node_modules/core-js/internals/is-object.js");
	var isSymbol = __webpack_require__(/*! ../internals/is-symbol */ "./node_modules/core-js/internals/is-symbol.js");
	var getMethod = __webpack_require__(/*! ../internals/get-method */ "./node_modules/core-js/internals/get-method.js");
	var ordinaryToPrimitive = __webpack_require__(/*! ../internals/ordinary-to-primitive */ "./node_modules/core-js/internals/ordinary-to-primitive.js");
	var wellKnownSymbol = __webpack_require__(/*! ../internals/well-known-symbol */ "./node_modules/core-js/internals/well-known-symbol.js");

	var $TypeError = TypeError;
	var TO_PRIMITIVE = wellKnownSymbol('toPrimitive');

	// `ToPrimitive` abstract operation
	// https://tc39.es/ecma262/#sec-toprimitive
	module.exports = function (input, pref) {
	  if (!isObject(input) || isSymbol(input)) return input;
	  var exoticToPrim = getMethod(input, TO_PRIMITIVE);
	  var result;
	  if (exoticToPrim) {
	    if (pref === undefined) pref = 'default';
	    result = call(exoticToPrim, input, pref);
	    if (!isObject(result) || isSymbol(result)) return result;
	    throw new $TypeError("Can't convert object to primitive value");
	  }
	  if (pref === undefined) pref = 'number';
	  return ordinaryToPrimitive(input, pref);
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/to-property-key.js":
	/*!***********************************************************!*\
	  !*** ./node_modules/core-js/internals/to-property-key.js ***!
	  \***********************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var toPrimitive = __webpack_require__(/*! ../internals/to-primitive */ "./node_modules/core-js/internals/to-primitive.js");
	var isSymbol = __webpack_require__(/*! ../internals/is-symbol */ "./node_modules/core-js/internals/is-symbol.js");

	// `ToPropertyKey` abstract operation
	// https://tc39.es/ecma262/#sec-topropertykey
	module.exports = function (argument) {
	  var key = toPrimitive(argument, 'string');
	  return isSymbol(key) ? key : key + '';
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/to-set-like.js":
	/*!*******************************************************!*\
	  !*** ./node_modules/core-js/internals/to-set-like.js ***!
	  \*******************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var getBuiltIn = __webpack_require__(/*! ../internals/get-built-in */ "./node_modules/core-js/internals/get-built-in.js");
	var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/core-js/internals/is-callable.js");
	var isIterable = __webpack_require__(/*! ../internals/is-iterable */ "./node_modules/core-js/internals/is-iterable.js");
	var isObject = __webpack_require__(/*! ../internals/is-object */ "./node_modules/core-js/internals/is-object.js");

	var Set = getBuiltIn('Set');

	var isSetLike = function (it) {
	  return isObject(it)
	    && typeof it.size == 'number'
	    && isCallable(it.has)
	    && isCallable(it.keys);
	};

	// fallback old -> new set methods proposal arguments
	module.exports = function (it) {
	  if (isSetLike(it)) return it;
	  return isIterable(it) ? new Set(it) : it;
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/to-string-tag-support.js":
	/*!*****************************************************************!*\
	  !*** ./node_modules/core-js/internals/to-string-tag-support.js ***!
	  \*****************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var wellKnownSymbol = __webpack_require__(/*! ../internals/well-known-symbol */ "./node_modules/core-js/internals/well-known-symbol.js");

	var TO_STRING_TAG = wellKnownSymbol('toStringTag');
	var test = {};

	test[TO_STRING_TAG] = 'z';

	module.exports = String(test) === '[object z]';


	/***/ }),

	/***/ "./node_modules/core-js/internals/to-string.js":
	/*!*****************************************************!*\
	  !*** ./node_modules/core-js/internals/to-string.js ***!
	  \*****************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var classof = __webpack_require__(/*! ../internals/classof */ "./node_modules/core-js/internals/classof.js");

	var $String = String;

	module.exports = function (argument) {
	  if (classof(argument) === 'Symbol') throw new TypeError('Cannot convert a Symbol value to a string');
	  return $String(argument);
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/try-to-string.js":
	/*!*********************************************************!*\
	  !*** ./node_modules/core-js/internals/try-to-string.js ***!
	  \*********************************************************/
	/***/ (function(module) {


	var $String = String;

	module.exports = function (argument) {
	  try {
	    return $String(argument);
	  } catch (error) {
	    return 'Object';
	  }
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/uid.js":
	/*!***********************************************!*\
	  !*** ./node_modules/core-js/internals/uid.js ***!
	  \***********************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/core-js/internals/function-uncurry-this.js");

	var id = 0;
	var postfix = Math.random();
	var toString = uncurryThis(1.1.toString);

	module.exports = function (key) {
	  return 'Symbol(' + (key === undefined ? '' : key) + ')_' + toString(++id + postfix, 36);
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/use-symbol-as-uid.js":
	/*!*************************************************************!*\
	  !*** ./node_modules/core-js/internals/use-symbol-as-uid.js ***!
	  \*************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	/* eslint-disable es/no-symbol -- required for testing */
	var NATIVE_SYMBOL = __webpack_require__(/*! ../internals/symbol-constructor-detection */ "./node_modules/core-js/internals/symbol-constructor-detection.js");

	module.exports = NATIVE_SYMBOL &&
	  !Symbol.sham &&
	  typeof Symbol.iterator == 'symbol';


	/***/ }),

	/***/ "./node_modules/core-js/internals/v8-prototype-define-bug.js":
	/*!*******************************************************************!*\
	  !*** ./node_modules/core-js/internals/v8-prototype-define-bug.js ***!
	  \*******************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var DESCRIPTORS = __webpack_require__(/*! ../internals/descriptors */ "./node_modules/core-js/internals/descriptors.js");
	var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/core-js/internals/fails.js");

	// V8 ~ Chrome 36-
	// https://bugs.chromium.org/p/v8/issues/detail?id=3334
	module.exports = DESCRIPTORS && fails(function () {
	  // eslint-disable-next-line es/no-object-defineproperty -- required for testing
	  return Object.defineProperty(function () { /* empty */ }, 'prototype', {
	    value: 42,
	    writable: false
	  }).prototype !== 42;
	});


	/***/ }),

	/***/ "./node_modules/core-js/internals/validate-arguments-length.js":
	/*!*********************************************************************!*\
	  !*** ./node_modules/core-js/internals/validate-arguments-length.js ***!
	  \*********************************************************************/
	/***/ (function(module) {


	var $TypeError = TypeError;

	module.exports = function (passed, required) {
	  if (passed < required) throw new $TypeError('Not enough arguments');
	  return passed;
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/weak-map-basic-detection.js":
	/*!********************************************************************!*\
	  !*** ./node_modules/core-js/internals/weak-map-basic-detection.js ***!
	  \********************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/core-js/internals/global-this.js");
	var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/core-js/internals/is-callable.js");

	var WeakMap = globalThis.WeakMap;

	module.exports = isCallable(WeakMap) && /native code/.test(String(WeakMap));


	/***/ }),

	/***/ "./node_modules/core-js/internals/well-known-symbol-define.js":
	/*!********************************************************************!*\
	  !*** ./node_modules/core-js/internals/well-known-symbol-define.js ***!
	  \********************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var path = __webpack_require__(/*! ../internals/path */ "./node_modules/core-js/internals/path.js");
	var hasOwn = __webpack_require__(/*! ../internals/has-own-property */ "./node_modules/core-js/internals/has-own-property.js");
	var wrappedWellKnownSymbolModule = __webpack_require__(/*! ../internals/well-known-symbol-wrapped */ "./node_modules/core-js/internals/well-known-symbol-wrapped.js");
	var defineProperty = (__webpack_require__(/*! ../internals/object-define-property */ "./node_modules/core-js/internals/object-define-property.js").f);

	module.exports = function (NAME) {
	  var Symbol = path.Symbol || (path.Symbol = {});
	  if (!hasOwn(Symbol, NAME)) defineProperty(Symbol, NAME, {
	    value: wrappedWellKnownSymbolModule.f(NAME)
	  });
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/well-known-symbol-wrapped.js":
	/*!*********************************************************************!*\
	  !*** ./node_modules/core-js/internals/well-known-symbol-wrapped.js ***!
	  \*********************************************************************/
	/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


	var wellKnownSymbol = __webpack_require__(/*! ../internals/well-known-symbol */ "./node_modules/core-js/internals/well-known-symbol.js");

	exports.f = wellKnownSymbol;


	/***/ }),

	/***/ "./node_modules/core-js/internals/well-known-symbol.js":
	/*!*************************************************************!*\
	  !*** ./node_modules/core-js/internals/well-known-symbol.js ***!
	  \*************************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/core-js/internals/global-this.js");
	var shared = __webpack_require__(/*! ../internals/shared */ "./node_modules/core-js/internals/shared.js");
	var hasOwn = __webpack_require__(/*! ../internals/has-own-property */ "./node_modules/core-js/internals/has-own-property.js");
	var uid = __webpack_require__(/*! ../internals/uid */ "./node_modules/core-js/internals/uid.js");
	var NATIVE_SYMBOL = __webpack_require__(/*! ../internals/symbol-constructor-detection */ "./node_modules/core-js/internals/symbol-constructor-detection.js");
	var USE_SYMBOL_AS_UID = __webpack_require__(/*! ../internals/use-symbol-as-uid */ "./node_modules/core-js/internals/use-symbol-as-uid.js");

	var Symbol = globalThis.Symbol;
	var WellKnownSymbolsStore = shared('wks');
	var createWellKnownSymbol = USE_SYMBOL_AS_UID ? Symbol['for'] || Symbol : Symbol && Symbol.withoutSetter || uid;

	module.exports = function (name) {
	  if (!hasOwn(WellKnownSymbolsStore, name)) {
	    WellKnownSymbolsStore[name] = NATIVE_SYMBOL && hasOwn(Symbol, name)
	      ? Symbol[name]
	      : createWellKnownSymbol('Symbol.' + name);
	  } return WellKnownSymbolsStore[name];
	};


	/***/ }),

	/***/ "./node_modules/core-js/internals/whitespaces.js":
	/*!*******************************************************!*\
	  !*** ./node_modules/core-js/internals/whitespaces.js ***!
	  \*******************************************************/
	/***/ (function(module) {


	// a string of all valid unicode whitespaces
	module.exports = '\u0009\u000A\u000B\u000C\u000D\u0020\u00A0\u1680\u2000\u2001\u2002' +
	  '\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200A\u202F\u205F\u3000\u2028\u2029\uFEFF';


	/***/ }),

	/***/ "./node_modules/core-js/modules/es.array.concat.js":
	/*!*********************************************************!*\
	  !*** ./node_modules/core-js/modules/es.array.concat.js ***!
	  \*********************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
	var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/core-js/internals/fails.js");
	var isArray = __webpack_require__(/*! ../internals/is-array */ "./node_modules/core-js/internals/is-array.js");
	var isObject = __webpack_require__(/*! ../internals/is-object */ "./node_modules/core-js/internals/is-object.js");
	var toObject = __webpack_require__(/*! ../internals/to-object */ "./node_modules/core-js/internals/to-object.js");
	var lengthOfArrayLike = __webpack_require__(/*! ../internals/length-of-array-like */ "./node_modules/core-js/internals/length-of-array-like.js");
	var doesNotExceedSafeInteger = __webpack_require__(/*! ../internals/does-not-exceed-safe-integer */ "./node_modules/core-js/internals/does-not-exceed-safe-integer.js");
	var createProperty = __webpack_require__(/*! ../internals/create-property */ "./node_modules/core-js/internals/create-property.js");
	var arraySpeciesCreate = __webpack_require__(/*! ../internals/array-species-create */ "./node_modules/core-js/internals/array-species-create.js");
	var arrayMethodHasSpeciesSupport = __webpack_require__(/*! ../internals/array-method-has-species-support */ "./node_modules/core-js/internals/array-method-has-species-support.js");
	var wellKnownSymbol = __webpack_require__(/*! ../internals/well-known-symbol */ "./node_modules/core-js/internals/well-known-symbol.js");
	var V8_VERSION = __webpack_require__(/*! ../internals/environment-v8-version */ "./node_modules/core-js/internals/environment-v8-version.js");

	var IS_CONCAT_SPREADABLE = wellKnownSymbol('isConcatSpreadable');

	// We can't use this feature detection in V8 since it causes
	// deoptimization and serious performance degradation
	// https://github.com/zloirock/core-js/issues/679
	var IS_CONCAT_SPREADABLE_SUPPORT = V8_VERSION >= 51 || !fails(function () {
	  var array = [];
	  array[IS_CONCAT_SPREADABLE] = false;
	  return array.concat()[0] !== array;
	});

	var isConcatSpreadable = function (O) {
	  if (!isObject(O)) return false;
	  var spreadable = O[IS_CONCAT_SPREADABLE];
	  return spreadable !== undefined ? !!spreadable : isArray(O);
	};

	var FORCED = !IS_CONCAT_SPREADABLE_SUPPORT || !arrayMethodHasSpeciesSupport('concat');

	// `Array.prototype.concat` method
	// https://tc39.es/ecma262/#sec-array.prototype.concat
	// with adding support of @@isConcatSpreadable and @@species
	$({ target: 'Array', proto: true, arity: 1, forced: FORCED }, {
	  // eslint-disable-next-line no-unused-vars -- required for `.length`
	  concat: function concat(arg) {
	    var O = toObject(this);
	    var A = arraySpeciesCreate(O, 0);
	    var n = 0;
	    var i, k, length, len, E;
	    for (i = -1, length = arguments.length; i < length; i++) {
	      E = i === -1 ? O : arguments[i];
	      if (isConcatSpreadable(E)) {
	        len = lengthOfArrayLike(E);
	        doesNotExceedSafeInteger(n + len);
	        for (k = 0; k < len; k++, n++) if (k in E) createProperty(A, n, E[k]);
	      } else {
	        doesNotExceedSafeInteger(n + 1);
	        createProperty(A, n++, E);
	      }
	    }
	    A.length = n;
	    return A;
	  }
	});


	/***/ }),

	/***/ "./node_modules/core-js/modules/es.array.from.js":
	/*!*******************************************************!*\
	  !*** ./node_modules/core-js/modules/es.array.from.js ***!
	  \*******************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
	var from = __webpack_require__(/*! ../internals/array-from */ "./node_modules/core-js/internals/array-from.js");
	var checkCorrectnessOfIteration = __webpack_require__(/*! ../internals/check-correctness-of-iteration */ "./node_modules/core-js/internals/check-correctness-of-iteration.js");

	var INCORRECT_ITERATION = !checkCorrectnessOfIteration(function (iterable) {
	  // eslint-disable-next-line es/no-array-from -- required for testing
	  Array.from(iterable);
	});

	// `Array.from` method
	// https://tc39.es/ecma262/#sec-array.from
	$({ target: 'Array', stat: true, forced: INCORRECT_ITERATION }, {
	  from: from
	});


	/***/ }),

	/***/ "./node_modules/core-js/modules/es.array.iterator.js":
	/*!***********************************************************!*\
	  !*** ./node_modules/core-js/modules/es.array.iterator.js ***!
	  \***********************************************************/
	/***/ (function(module, __unused_webpack_exports, __webpack_require__) {


	var toIndexedObject = __webpack_require__(/*! ../internals/to-indexed-object */ "./node_modules/core-js/internals/to-indexed-object.js");
	var addToUnscopables = __webpack_require__(/*! ../internals/add-to-unscopables */ "./node_modules/core-js/internals/add-to-unscopables.js");
	var Iterators = __webpack_require__(/*! ../internals/iterators */ "./node_modules/core-js/internals/iterators.js");
	var InternalStateModule = __webpack_require__(/*! ../internals/internal-state */ "./node_modules/core-js/internals/internal-state.js");
	var defineProperty = (__webpack_require__(/*! ../internals/object-define-property */ "./node_modules/core-js/internals/object-define-property.js").f);
	var defineIterator = __webpack_require__(/*! ../internals/iterator-define */ "./node_modules/core-js/internals/iterator-define.js");
	var createIterResultObject = __webpack_require__(/*! ../internals/create-iter-result-object */ "./node_modules/core-js/internals/create-iter-result-object.js");
	var IS_PURE = __webpack_require__(/*! ../internals/is-pure */ "./node_modules/core-js/internals/is-pure.js");
	var DESCRIPTORS = __webpack_require__(/*! ../internals/descriptors */ "./node_modules/core-js/internals/descriptors.js");

	var ARRAY_ITERATOR = 'Array Iterator';
	var setInternalState = InternalStateModule.set;
	var getInternalState = InternalStateModule.getterFor(ARRAY_ITERATOR);

	// `Array.prototype.entries` method
	// https://tc39.es/ecma262/#sec-array.prototype.entries
	// `Array.prototype.keys` method
	// https://tc39.es/ecma262/#sec-array.prototype.keys
	// `Array.prototype.values` method
	// https://tc39.es/ecma262/#sec-array.prototype.values
	// `Array.prototype[@@iterator]` method
	// https://tc39.es/ecma262/#sec-array.prototype-@@iterator
	// `CreateArrayIterator` internal method
	// https://tc39.es/ecma262/#sec-createarrayiterator
	module.exports = defineIterator(Array, 'Array', function (iterated, kind) {
	  setInternalState(this, {
	    type: ARRAY_ITERATOR,
	    target: toIndexedObject(iterated), // target
	    index: 0,                          // next index
	    kind: kind                         // kind
	  });
	// `%ArrayIteratorPrototype%.next` method
	// https://tc39.es/ecma262/#sec-%arrayiteratorprototype%.next
	}, function () {
	  var state = getInternalState(this);
	  var target = state.target;
	  var index = state.index++;
	  if (!target || index >= target.length) {
	    state.target = null;
	    return createIterResultObject(undefined, true);
	  }
	  switch (state.kind) {
	    case 'keys': return createIterResultObject(index, false);
	    case 'values': return createIterResultObject(target[index], false);
	  } return createIterResultObject([index, target[index]], false);
	}, 'values');

	// argumentsList[@@iterator] is %ArrayProto_values%
	// https://tc39.es/ecma262/#sec-createunmappedargumentsobject
	// https://tc39.es/ecma262/#sec-createmappedargumentsobject
	var values = Iterators.Arguments = Iterators.Array;

	// https://tc39.es/ecma262/#sec-array.prototype-@@unscopables
	addToUnscopables('keys');
	addToUnscopables('values');
	addToUnscopables('entries');

	// V8 ~ Chrome 45- bug
	if (!IS_PURE && DESCRIPTORS && values.name !== 'values') try {
	  defineProperty(values, 'name', { value: 'values' });
	} catch (error) { /* empty */ }


	/***/ }),

	/***/ "./node_modules/core-js/modules/es.array.join.js":
	/*!*******************************************************!*\
	  !*** ./node_modules/core-js/modules/es.array.join.js ***!
	  \*******************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
	var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/core-js/internals/function-uncurry-this.js");
	var IndexedObject = __webpack_require__(/*! ../internals/indexed-object */ "./node_modules/core-js/internals/indexed-object.js");
	var toIndexedObject = __webpack_require__(/*! ../internals/to-indexed-object */ "./node_modules/core-js/internals/to-indexed-object.js");
	var arrayMethodIsStrict = __webpack_require__(/*! ../internals/array-method-is-strict */ "./node_modules/core-js/internals/array-method-is-strict.js");

	var nativeJoin = uncurryThis([].join);

	var ES3_STRINGS = IndexedObject !== Object;
	var FORCED = ES3_STRINGS || !arrayMethodIsStrict('join', ',');

	// `Array.prototype.join` method
	// https://tc39.es/ecma262/#sec-array.prototype.join
	$({ target: 'Array', proto: true, forced: FORCED }, {
	  join: function join(separator) {
	    return nativeJoin(toIndexedObject(this), separator === undefined ? ',' : separator);
	  }
	});


	/***/ }),

	/***/ "./node_modules/core-js/modules/es.array.map.js":
	/*!******************************************************!*\
	  !*** ./node_modules/core-js/modules/es.array.map.js ***!
	  \******************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
	var $map = (__webpack_require__(/*! ../internals/array-iteration */ "./node_modules/core-js/internals/array-iteration.js").map);
	var arrayMethodHasSpeciesSupport = __webpack_require__(/*! ../internals/array-method-has-species-support */ "./node_modules/core-js/internals/array-method-has-species-support.js");

	var HAS_SPECIES_SUPPORT = arrayMethodHasSpeciesSupport('map');

	// `Array.prototype.map` method
	// https://tc39.es/ecma262/#sec-array.prototype.map
	// with adding support of @@species
	$({ target: 'Array', proto: true, forced: !HAS_SPECIES_SUPPORT }, {
	  map: function map(callbackfn /* , thisArg */) {
	    return $map(this, callbackfn, arguments.length > 1 ? arguments[1] : undefined);
	  }
	});


	/***/ }),

	/***/ "./node_modules/core-js/modules/es.array.slice.js":
	/*!********************************************************!*\
	  !*** ./node_modules/core-js/modules/es.array.slice.js ***!
	  \********************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
	var isArray = __webpack_require__(/*! ../internals/is-array */ "./node_modules/core-js/internals/is-array.js");
	var isConstructor = __webpack_require__(/*! ../internals/is-constructor */ "./node_modules/core-js/internals/is-constructor.js");
	var isObject = __webpack_require__(/*! ../internals/is-object */ "./node_modules/core-js/internals/is-object.js");
	var toAbsoluteIndex = __webpack_require__(/*! ../internals/to-absolute-index */ "./node_modules/core-js/internals/to-absolute-index.js");
	var lengthOfArrayLike = __webpack_require__(/*! ../internals/length-of-array-like */ "./node_modules/core-js/internals/length-of-array-like.js");
	var toIndexedObject = __webpack_require__(/*! ../internals/to-indexed-object */ "./node_modules/core-js/internals/to-indexed-object.js");
	var createProperty = __webpack_require__(/*! ../internals/create-property */ "./node_modules/core-js/internals/create-property.js");
	var wellKnownSymbol = __webpack_require__(/*! ../internals/well-known-symbol */ "./node_modules/core-js/internals/well-known-symbol.js");
	var arrayMethodHasSpeciesSupport = __webpack_require__(/*! ../internals/array-method-has-species-support */ "./node_modules/core-js/internals/array-method-has-species-support.js");
	var nativeSlice = __webpack_require__(/*! ../internals/array-slice */ "./node_modules/core-js/internals/array-slice.js");

	var HAS_SPECIES_SUPPORT = arrayMethodHasSpeciesSupport('slice');

	var SPECIES = wellKnownSymbol('species');
	var $Array = Array;
	var max = Math.max;

	// `Array.prototype.slice` method
	// https://tc39.es/ecma262/#sec-array.prototype.slice
	// fallback for not array-like ES3 strings and DOM objects
	$({ target: 'Array', proto: true, forced: !HAS_SPECIES_SUPPORT }, {
	  slice: function slice(start, end) {
	    var O = toIndexedObject(this);
	    var length = lengthOfArrayLike(O);
	    var k = toAbsoluteIndex(start, length);
	    var fin = toAbsoluteIndex(end === undefined ? length : end, length);
	    // inline `ArraySpeciesCreate` for usage native `Array#slice` where it's possible
	    var Constructor, result, n;
	    if (isArray(O)) {
	      Constructor = O.constructor;
	      // cross-realm fallback
	      if (isConstructor(Constructor) && (Constructor === $Array || isArray(Constructor.prototype))) {
	        Constructor = undefined;
	      } else if (isObject(Constructor)) {
	        Constructor = Constructor[SPECIES];
	        if (Constructor === null) Constructor = undefined;
	      }
	      if (Constructor === $Array || Constructor === undefined) {
	        return nativeSlice(O, k, fin);
	      }
	    }
	    result = new (Constructor === undefined ? $Array : Constructor)(max(fin - k, 0));
	    for (n = 0; k < fin; k++, n++) if (k in O) createProperty(result, n, O[k]);
	    result.length = n;
	    return result;
	  }
	});


	/***/ }),

	/***/ "./node_modules/core-js/modules/es.function.name.js":
	/*!**********************************************************!*\
	  !*** ./node_modules/core-js/modules/es.function.name.js ***!
	  \**********************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	var DESCRIPTORS = __webpack_require__(/*! ../internals/descriptors */ "./node_modules/core-js/internals/descriptors.js");
	var FUNCTION_NAME_EXISTS = (__webpack_require__(/*! ../internals/function-name */ "./node_modules/core-js/internals/function-name.js").EXISTS);
	var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/core-js/internals/function-uncurry-this.js");
	var defineBuiltInAccessor = __webpack_require__(/*! ../internals/define-built-in-accessor */ "./node_modules/core-js/internals/define-built-in-accessor.js");

	var FunctionPrototype = Function.prototype;
	var functionToString = uncurryThis(FunctionPrototype.toString);
	var nameRE = /function\b(?:\s|\/\*[\S\s]*?\*\/|\/\/[^\n\r]*[\n\r]+)*([^\s(/]*)/;
	var regExpExec = uncurryThis(nameRE.exec);
	var NAME = 'name';

	// Function instances `.name` property
	// https://tc39.es/ecma262/#sec-function-instances-name
	if (DESCRIPTORS && !FUNCTION_NAME_EXISTS) {
	  defineBuiltInAccessor(FunctionPrototype, NAME, {
	    configurable: true,
	    get: function () {
	      try {
	        return regExpExec(nameRE, functionToString(this))[1];
	      } catch (error) {
	        return '';
	      }
	    }
	  });
	}


	/***/ }),

	/***/ "./node_modules/core-js/modules/es.iterator.constructor.js":
	/*!*****************************************************************!*\
	  !*** ./node_modules/core-js/modules/es.iterator.constructor.js ***!
	  \*****************************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
	var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/core-js/internals/global-this.js");
	var anInstance = __webpack_require__(/*! ../internals/an-instance */ "./node_modules/core-js/internals/an-instance.js");
	var anObject = __webpack_require__(/*! ../internals/an-object */ "./node_modules/core-js/internals/an-object.js");
	var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/core-js/internals/is-callable.js");
	var getPrototypeOf = __webpack_require__(/*! ../internals/object-get-prototype-of */ "./node_modules/core-js/internals/object-get-prototype-of.js");
	var defineBuiltInAccessor = __webpack_require__(/*! ../internals/define-built-in-accessor */ "./node_modules/core-js/internals/define-built-in-accessor.js");
	var createProperty = __webpack_require__(/*! ../internals/create-property */ "./node_modules/core-js/internals/create-property.js");
	var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/core-js/internals/fails.js");
	var hasOwn = __webpack_require__(/*! ../internals/has-own-property */ "./node_modules/core-js/internals/has-own-property.js");
	var wellKnownSymbol = __webpack_require__(/*! ../internals/well-known-symbol */ "./node_modules/core-js/internals/well-known-symbol.js");
	var IteratorPrototype = (__webpack_require__(/*! ../internals/iterators-core */ "./node_modules/core-js/internals/iterators-core.js").IteratorPrototype);
	var DESCRIPTORS = __webpack_require__(/*! ../internals/descriptors */ "./node_modules/core-js/internals/descriptors.js");
	var IS_PURE = __webpack_require__(/*! ../internals/is-pure */ "./node_modules/core-js/internals/is-pure.js");

	var CONSTRUCTOR = 'constructor';
	var ITERATOR = 'Iterator';
	var TO_STRING_TAG = wellKnownSymbol('toStringTag');

	var $TypeError = TypeError;
	var NativeIterator = globalThis[ITERATOR];

	// FF56- have non-standard global helper `Iterator`
	var FORCED = IS_PURE
	  || !isCallable(NativeIterator)
	  || NativeIterator.prototype !== IteratorPrototype
	  // FF44- non-standard `Iterator` passes previous tests
	  || !fails(function () { NativeIterator({}); });

	var IteratorConstructor = function Iterator() {
	  anInstance(this, IteratorPrototype);
	  if (getPrototypeOf(this) === IteratorPrototype) throw new $TypeError('Abstract class Iterator not directly constructable');
	};

	var defineIteratorPrototypeAccessor = function (key, value) {
	  if (DESCRIPTORS) {
	    defineBuiltInAccessor(IteratorPrototype, key, {
	      configurable: true,
	      get: function () {
	        return value;
	      },
	      set: function (replacement) {
	        anObject(this);
	        if (this === IteratorPrototype) throw new $TypeError("You can't redefine this property");
	        if (hasOwn(this, key)) this[key] = replacement;
	        else createProperty(this, key, replacement);
	      }
	    });
	  } else IteratorPrototype[key] = value;
	};

	if (!hasOwn(IteratorPrototype, TO_STRING_TAG)) defineIteratorPrototypeAccessor(TO_STRING_TAG, ITERATOR);

	if (FORCED || !hasOwn(IteratorPrototype, CONSTRUCTOR) || IteratorPrototype[CONSTRUCTOR] === Object) {
	  defineIteratorPrototypeAccessor(CONSTRUCTOR, IteratorConstructor);
	}

	IteratorConstructor.prototype = IteratorPrototype;

	// `Iterator` constructor
	// https://tc39.es/ecma262/#sec-iterator
	$({ global: true, constructor: true, forced: FORCED }, {
	  Iterator: IteratorConstructor
	});


	/***/ }),

	/***/ "./node_modules/core-js/modules/es.iterator.for-each.js":
	/*!**************************************************************!*\
	  !*** ./node_modules/core-js/modules/es.iterator.for-each.js ***!
	  \**************************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
	var call = __webpack_require__(/*! ../internals/function-call */ "./node_modules/core-js/internals/function-call.js");
	var iterate = __webpack_require__(/*! ../internals/iterate */ "./node_modules/core-js/internals/iterate.js");
	var aCallable = __webpack_require__(/*! ../internals/a-callable */ "./node_modules/core-js/internals/a-callable.js");
	var anObject = __webpack_require__(/*! ../internals/an-object */ "./node_modules/core-js/internals/an-object.js");
	var getIteratorDirect = __webpack_require__(/*! ../internals/get-iterator-direct */ "./node_modules/core-js/internals/get-iterator-direct.js");
	var iteratorClose = __webpack_require__(/*! ../internals/iterator-close */ "./node_modules/core-js/internals/iterator-close.js");
	var iteratorHelperWithoutClosingOnEarlyError = __webpack_require__(/*! ../internals/iterator-helper-without-closing-on-early-error */ "./node_modules/core-js/internals/iterator-helper-without-closing-on-early-error.js");

	var forEachWithoutClosingOnEarlyError = iteratorHelperWithoutClosingOnEarlyError('forEach', TypeError);

	// `Iterator.prototype.forEach` method
	// https://tc39.es/ecma262/#sec-iterator.prototype.foreach
	$({ target: 'Iterator', proto: true, real: true, forced: forEachWithoutClosingOnEarlyError }, {
	  forEach: function forEach(fn) {
	    anObject(this);
	    try {
	      aCallable(fn);
	    } catch (error) {
	      iteratorClose(this, 'throw', error);
	    }

	    if (forEachWithoutClosingOnEarlyError) return call(forEachWithoutClosingOnEarlyError, this, fn);

	    var record = getIteratorDirect(this);
	    var counter = 0;
	    iterate(record, function (value) {
	      fn(value, counter++);
	    }, { IS_RECORD: true });
	  }
	});


	/***/ }),

	/***/ "./node_modules/core-js/modules/es.iterator.map.js":
	/*!*********************************************************!*\
	  !*** ./node_modules/core-js/modules/es.iterator.map.js ***!
	  \*********************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
	var call = __webpack_require__(/*! ../internals/function-call */ "./node_modules/core-js/internals/function-call.js");
	var aCallable = __webpack_require__(/*! ../internals/a-callable */ "./node_modules/core-js/internals/a-callable.js");
	var anObject = __webpack_require__(/*! ../internals/an-object */ "./node_modules/core-js/internals/an-object.js");
	var getIteratorDirect = __webpack_require__(/*! ../internals/get-iterator-direct */ "./node_modules/core-js/internals/get-iterator-direct.js");
	var createIteratorProxy = __webpack_require__(/*! ../internals/iterator-create-proxy */ "./node_modules/core-js/internals/iterator-create-proxy.js");
	var callWithSafeIterationClosing = __webpack_require__(/*! ../internals/call-with-safe-iteration-closing */ "./node_modules/core-js/internals/call-with-safe-iteration-closing.js");
	var iteratorClose = __webpack_require__(/*! ../internals/iterator-close */ "./node_modules/core-js/internals/iterator-close.js");
	var iteratorHelperThrowsOnInvalidIterator = __webpack_require__(/*! ../internals/iterator-helper-throws-on-invalid-iterator */ "./node_modules/core-js/internals/iterator-helper-throws-on-invalid-iterator.js");
	var iteratorHelperWithoutClosingOnEarlyError = __webpack_require__(/*! ../internals/iterator-helper-without-closing-on-early-error */ "./node_modules/core-js/internals/iterator-helper-without-closing-on-early-error.js");
	var IS_PURE = __webpack_require__(/*! ../internals/is-pure */ "./node_modules/core-js/internals/is-pure.js");

	var MAP_WITHOUT_THROWING_ON_INVALID_ITERATOR = !IS_PURE && !iteratorHelperThrowsOnInvalidIterator('map', function () { /* empty */ });
	var mapWithoutClosingOnEarlyError = !IS_PURE && !MAP_WITHOUT_THROWING_ON_INVALID_ITERATOR
	  && iteratorHelperWithoutClosingOnEarlyError('map', TypeError);

	var FORCED = IS_PURE || MAP_WITHOUT_THROWING_ON_INVALID_ITERATOR || mapWithoutClosingOnEarlyError;

	var IteratorProxy = createIteratorProxy(function () {
	  var iterator = this.iterator;
	  var result = anObject(call(this.next, iterator));
	  var done = this.done = !!result.done;
	  if (!done) return callWithSafeIterationClosing(iterator, this.mapper, [result.value, this.counter++], true);
	});

	// `Iterator.prototype.map` method
	// https://tc39.es/ecma262/#sec-iterator.prototype.map
	$({ target: 'Iterator', proto: true, real: true, forced: FORCED }, {
	  map: function map(mapper) {
	    anObject(this);
	    try {
	      aCallable(mapper);
	    } catch (error) {
	      iteratorClose(this, 'throw', error);
	    }

	    if (mapWithoutClosingOnEarlyError) return call(mapWithoutClosingOnEarlyError, this, mapper);

	    return new IteratorProxy(getIteratorDirect(this), {
	      mapper: mapper
	    });
	  }
	});


	/***/ }),

	/***/ "./node_modules/core-js/modules/es.json.stringify.js":
	/*!***********************************************************!*\
	  !*** ./node_modules/core-js/modules/es.json.stringify.js ***!
	  \***********************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
	var getBuiltIn = __webpack_require__(/*! ../internals/get-built-in */ "./node_modules/core-js/internals/get-built-in.js");
	var apply = __webpack_require__(/*! ../internals/function-apply */ "./node_modules/core-js/internals/function-apply.js");
	var call = __webpack_require__(/*! ../internals/function-call */ "./node_modules/core-js/internals/function-call.js");
	var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/core-js/internals/function-uncurry-this.js");
	var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/core-js/internals/fails.js");
	var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/core-js/internals/is-callable.js");
	var isSymbol = __webpack_require__(/*! ../internals/is-symbol */ "./node_modules/core-js/internals/is-symbol.js");
	var arraySlice = __webpack_require__(/*! ../internals/array-slice */ "./node_modules/core-js/internals/array-slice.js");
	var getReplacerFunction = __webpack_require__(/*! ../internals/get-json-replacer-function */ "./node_modules/core-js/internals/get-json-replacer-function.js");
	var NATIVE_SYMBOL = __webpack_require__(/*! ../internals/symbol-constructor-detection */ "./node_modules/core-js/internals/symbol-constructor-detection.js");

	var $String = String;
	var $stringify = getBuiltIn('JSON', 'stringify');
	var exec = uncurryThis(/./.exec);
	var charAt = uncurryThis(''.charAt);
	var charCodeAt = uncurryThis(''.charCodeAt);
	var replace = uncurryThis(''.replace);
	var numberToString = uncurryThis(1.1.toString);

	var tester = /[\uD800-\uDFFF]/g;
	var low = /^[\uD800-\uDBFF]$/;
	var hi = /^[\uDC00-\uDFFF]$/;

	var WRONG_SYMBOLS_CONVERSION = !NATIVE_SYMBOL || fails(function () {
	  var symbol = getBuiltIn('Symbol')('stringify detection');
	  // MS Edge converts symbol values to JSON as {}
	  return $stringify([symbol]) !== '[null]'
	    // WebKit converts symbol values to JSON as null
	    || $stringify({ a: symbol }) !== '{}'
	    // V8 throws on boxed symbols
	    || $stringify(Object(symbol)) !== '{}';
	});

	// https://github.com/tc39/proposal-well-formed-stringify
	var ILL_FORMED_UNICODE = fails(function () {
	  return $stringify('\uDF06\uD834') !== '"\\udf06\\ud834"'
	    || $stringify('\uDEAD') !== '"\\udead"';
	});

	var stringifyWithSymbolsFix = function (it, replacer) {
	  var args = arraySlice(arguments);
	  var $replacer = getReplacerFunction(replacer);
	  if (!isCallable($replacer) && (it === undefined || isSymbol(it))) return; // IE8 returns string on undefined
	  args[1] = function (key, value) {
	    // some old implementations (like WebKit) could pass numbers as keys
	    if (isCallable($replacer)) value = call($replacer, this, $String(key), value);
	    if (!isSymbol(value)) return value;
	  };
	  return apply($stringify, null, args);
	};

	var fixIllFormed = function (match, offset, string) {
	  var prev = charAt(string, offset - 1);
	  var next = charAt(string, offset + 1);
	  if ((exec(low, match) && !exec(hi, next)) || (exec(hi, match) && !exec(low, prev))) {
	    return '\\u' + numberToString(charCodeAt(match, 0), 16);
	  } return match;
	};

	if ($stringify) {
	  // `JSON.stringify` method
	  // https://tc39.es/ecma262/#sec-json.stringify
	  $({ target: 'JSON', stat: true, arity: 3, forced: WRONG_SYMBOLS_CONVERSION || ILL_FORMED_UNICODE }, {
	    // eslint-disable-next-line no-unused-vars -- required for `.length`
	    stringify: function stringify(it, replacer, space) {
	      var args = arraySlice(arguments);
	      var result = apply(WRONG_SYMBOLS_CONVERSION ? stringifyWithSymbolsFix : $stringify, null, args);
	      return ILL_FORMED_UNICODE && typeof result == 'string' ? replace(result, tester, fixIllFormed) : result;
	    }
	  });
	}


	/***/ }),

	/***/ "./node_modules/core-js/modules/es.number.constructor.js":
	/*!***************************************************************!*\
	  !*** ./node_modules/core-js/modules/es.number.constructor.js ***!
	  \***************************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
	var IS_PURE = __webpack_require__(/*! ../internals/is-pure */ "./node_modules/core-js/internals/is-pure.js");
	var DESCRIPTORS = __webpack_require__(/*! ../internals/descriptors */ "./node_modules/core-js/internals/descriptors.js");
	var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/core-js/internals/global-this.js");
	var path = __webpack_require__(/*! ../internals/path */ "./node_modules/core-js/internals/path.js");
	var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/core-js/internals/function-uncurry-this.js");
	var isForced = __webpack_require__(/*! ../internals/is-forced */ "./node_modules/core-js/internals/is-forced.js");
	var hasOwn = __webpack_require__(/*! ../internals/has-own-property */ "./node_modules/core-js/internals/has-own-property.js");
	var inheritIfRequired = __webpack_require__(/*! ../internals/inherit-if-required */ "./node_modules/core-js/internals/inherit-if-required.js");
	var isPrototypeOf = __webpack_require__(/*! ../internals/object-is-prototype-of */ "./node_modules/core-js/internals/object-is-prototype-of.js");
	var isSymbol = __webpack_require__(/*! ../internals/is-symbol */ "./node_modules/core-js/internals/is-symbol.js");
	var toPrimitive = __webpack_require__(/*! ../internals/to-primitive */ "./node_modules/core-js/internals/to-primitive.js");
	var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/core-js/internals/fails.js");
	var getOwnPropertyNames = (__webpack_require__(/*! ../internals/object-get-own-property-names */ "./node_modules/core-js/internals/object-get-own-property-names.js").f);
	var getOwnPropertyDescriptor = (__webpack_require__(/*! ../internals/object-get-own-property-descriptor */ "./node_modules/core-js/internals/object-get-own-property-descriptor.js").f);
	var defineProperty = (__webpack_require__(/*! ../internals/object-define-property */ "./node_modules/core-js/internals/object-define-property.js").f);
	var thisNumberValue = __webpack_require__(/*! ../internals/this-number-value */ "./node_modules/core-js/internals/this-number-value.js");
	var trim = (__webpack_require__(/*! ../internals/string-trim */ "./node_modules/core-js/internals/string-trim.js").trim);

	var NUMBER = 'Number';
	var NativeNumber = globalThis[NUMBER];
	var PureNumberNamespace = path[NUMBER];
	var NumberPrototype = NativeNumber.prototype;
	var TypeError = globalThis.TypeError;
	var stringSlice = uncurryThis(''.slice);
	var charCodeAt = uncurryThis(''.charCodeAt);

	// `ToNumeric` abstract operation
	// https://tc39.es/ecma262/#sec-tonumeric
	var toNumeric = function (value) {
	  var primValue = toPrimitive(value, 'number');
	  return typeof primValue == 'bigint' ? primValue : toNumber(primValue);
	};

	// `ToNumber` abstract operation
	// https://tc39.es/ecma262/#sec-tonumber
	var toNumber = function (argument) {
	  var it = toPrimitive(argument, 'number');
	  var first, third, radix, maxCode, digits, length, index, code;
	  if (isSymbol(it)) throw new TypeError('Cannot convert a Symbol value to a number');
	  if (typeof it == 'string' && it.length > 2) {
	    it = trim(it);
	    first = charCodeAt(it, 0);
	    if (first === 43 || first === 45) {
	      third = charCodeAt(it, 2);
	      if (third === 88 || third === 120) return NaN; // Number('+0x1') should be NaN, old V8 fix
	    } else if (first === 48) {
	      switch (charCodeAt(it, 1)) {
	        // fast equal of /^0b[01]+$/i
	        case 66:
	        case 98:
	          radix = 2;
	          maxCode = 49;
	          break;
	        // fast equal of /^0o[0-7]+$/i
	        case 79:
	        case 111:
	          radix = 8;
	          maxCode = 55;
	          break;
	        default:
	          return +it;
	      }
	      digits = stringSlice(it, 2);
	      length = digits.length;
	      for (index = 0; index < length; index++) {
	        code = charCodeAt(digits, index);
	        // parseInt parses a string to a first unavailable symbol
	        // but ToNumber should return NaN if a string contains unavailable symbols
	        if (code < 48 || code > maxCode) return NaN;
	      } return parseInt(digits, radix);
	    }
	  } return +it;
	};

	var FORCED = isForced(NUMBER, !NativeNumber(' 0o1') || !NativeNumber('0b1') || NativeNumber('+0x1'));

	var calledWithNew = function (dummy) {
	  // includes check on 1..constructor(foo) case
	  return isPrototypeOf(NumberPrototype, dummy) && fails(function () { thisNumberValue(dummy); });
	};

	// `Number` constructor
	// https://tc39.es/ecma262/#sec-number-constructor
	var NumberWrapper = function Number(value) {
	  var n = arguments.length < 1 ? 0 : NativeNumber(toNumeric(value));
	  return calledWithNew(this) ? inheritIfRequired(Object(n), this, NumberWrapper) : n;
	};

	NumberWrapper.prototype = NumberPrototype;
	if (FORCED && !IS_PURE) NumberPrototype.constructor = NumberWrapper;

	$({ global: true, constructor: true, wrap: true, forced: FORCED }, {
	  Number: NumberWrapper
	});

	// Use `internal/copy-constructor-properties` helper in `core-js@4`
	var copyConstructorProperties = function (target, source) {
	  for (var keys = DESCRIPTORS ? getOwnPropertyNames(source) : (
	    // ES3:
	    'MAX_VALUE,MIN_VALUE,NaN,NEGATIVE_INFINITY,POSITIVE_INFINITY,' +
	    // ES2015 (in case, if modules with ES2015 Number statics required before):
	    'EPSILON,MAX_SAFE_INTEGER,MIN_SAFE_INTEGER,isFinite,isInteger,isNaN,isSafeInteger,parseFloat,parseInt,' +
	    // ESNext
	    'fromString,range'
	  ).split(','), j = 0, key; keys.length > j; j++) {
	    if (hasOwn(source, key = keys[j]) && !hasOwn(target, key)) {
	      defineProperty(target, key, getOwnPropertyDescriptor(source, key));
	    }
	  }
	};

	if (IS_PURE && PureNumberNamespace) copyConstructorProperties(path[NUMBER], PureNumberNamespace);
	if (FORCED || IS_PURE) copyConstructorProperties(path[NUMBER], NativeNumber);


	/***/ }),

	/***/ "./node_modules/core-js/modules/es.object.assign.js":
	/*!**********************************************************!*\
	  !*** ./node_modules/core-js/modules/es.object.assign.js ***!
	  \**********************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
	var assign = __webpack_require__(/*! ../internals/object-assign */ "./node_modules/core-js/internals/object-assign.js");

	// `Object.assign` method
	// https://tc39.es/ecma262/#sec-object.assign
	// eslint-disable-next-line es/no-object-assign -- required for testing
	$({ target: 'Object', stat: true, arity: 2, forced: Object.assign !== assign }, {
	  assign: assign
	});


	/***/ }),

	/***/ "./node_modules/core-js/modules/es.object.get-own-property-symbols.js":
	/*!****************************************************************************!*\
	  !*** ./node_modules/core-js/modules/es.object.get-own-property-symbols.js ***!
	  \****************************************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
	var NATIVE_SYMBOL = __webpack_require__(/*! ../internals/symbol-constructor-detection */ "./node_modules/core-js/internals/symbol-constructor-detection.js");
	var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/core-js/internals/fails.js");
	var getOwnPropertySymbolsModule = __webpack_require__(/*! ../internals/object-get-own-property-symbols */ "./node_modules/core-js/internals/object-get-own-property-symbols.js");
	var toObject = __webpack_require__(/*! ../internals/to-object */ "./node_modules/core-js/internals/to-object.js");

	// V8 ~ Chrome 38 and 39 `Object.getOwnPropertySymbols` fails on primitives
	// https://bugs.chromium.org/p/v8/issues/detail?id=3443
	var FORCED = !NATIVE_SYMBOL || fails(function () { getOwnPropertySymbolsModule.f(1); });

	// `Object.getOwnPropertySymbols` method
	// https://tc39.es/ecma262/#sec-object.getownpropertysymbols
	$({ target: 'Object', stat: true, forced: FORCED }, {
	  getOwnPropertySymbols: function getOwnPropertySymbols(it) {
	    var $getOwnPropertySymbols = getOwnPropertySymbolsModule.f;
	    return $getOwnPropertySymbols ? $getOwnPropertySymbols(toObject(it)) : [];
	  }
	});


	/***/ }),

	/***/ "./node_modules/core-js/modules/es.object.keys.js":
	/*!********************************************************!*\
	  !*** ./node_modules/core-js/modules/es.object.keys.js ***!
	  \********************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
	var toObject = __webpack_require__(/*! ../internals/to-object */ "./node_modules/core-js/internals/to-object.js");
	var nativeKeys = __webpack_require__(/*! ../internals/object-keys */ "./node_modules/core-js/internals/object-keys.js");
	var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/core-js/internals/fails.js");

	var FAILS_ON_PRIMITIVES = fails(function () { nativeKeys(1); });

	// `Object.keys` method
	// https://tc39.es/ecma262/#sec-object.keys
	$({ target: 'Object', stat: true, forced: FAILS_ON_PRIMITIVES }, {
	  keys: function keys(it) {
	    return nativeKeys(toObject(it));
	  }
	});


	/***/ }),

	/***/ "./node_modules/core-js/modules/es.object.to-string.js":
	/*!*************************************************************!*\
	  !*** ./node_modules/core-js/modules/es.object.to-string.js ***!
	  \*************************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	var TO_STRING_TAG_SUPPORT = __webpack_require__(/*! ../internals/to-string-tag-support */ "./node_modules/core-js/internals/to-string-tag-support.js");
	var defineBuiltIn = __webpack_require__(/*! ../internals/define-built-in */ "./node_modules/core-js/internals/define-built-in.js");
	var toString = __webpack_require__(/*! ../internals/object-to-string */ "./node_modules/core-js/internals/object-to-string.js");

	// `Object.prototype.toString` method
	// https://tc39.es/ecma262/#sec-object.prototype.tostring
	if (!TO_STRING_TAG_SUPPORT) {
	  defineBuiltIn(Object.prototype, 'toString', toString, { unsafe: true });
	}


	/***/ }),

	/***/ "./node_modules/core-js/modules/es.promise.all.js":
	/*!********************************************************!*\
	  !*** ./node_modules/core-js/modules/es.promise.all.js ***!
	  \********************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
	var call = __webpack_require__(/*! ../internals/function-call */ "./node_modules/core-js/internals/function-call.js");
	var aCallable = __webpack_require__(/*! ../internals/a-callable */ "./node_modules/core-js/internals/a-callable.js");
	var newPromiseCapabilityModule = __webpack_require__(/*! ../internals/new-promise-capability */ "./node_modules/core-js/internals/new-promise-capability.js");
	var perform = __webpack_require__(/*! ../internals/perform */ "./node_modules/core-js/internals/perform.js");
	var iterate = __webpack_require__(/*! ../internals/iterate */ "./node_modules/core-js/internals/iterate.js");
	var PROMISE_STATICS_INCORRECT_ITERATION = __webpack_require__(/*! ../internals/promise-statics-incorrect-iteration */ "./node_modules/core-js/internals/promise-statics-incorrect-iteration.js");

	// `Promise.all` method
	// https://tc39.es/ecma262/#sec-promise.all
	$({ target: 'Promise', stat: true, forced: PROMISE_STATICS_INCORRECT_ITERATION }, {
	  all: function all(iterable) {
	    var C = this;
	    var capability = newPromiseCapabilityModule.f(C);
	    var resolve = capability.resolve;
	    var reject = capability.reject;
	    var result = perform(function () {
	      var $promiseResolve = aCallable(C.resolve);
	      var values = [];
	      var counter = 0;
	      var remaining = 1;
	      iterate(iterable, function (promise) {
	        var index = counter++;
	        var alreadyCalled = false;
	        remaining++;
	        call($promiseResolve, C, promise).then(function (value) {
	          if (alreadyCalled) return;
	          alreadyCalled = true;
	          values[index] = value;
	          --remaining || resolve(values);
	        }, reject);
	      });
	      --remaining || resolve(values);
	    });
	    if (result.error) reject(result.value);
	    return capability.promise;
	  }
	});


	/***/ }),

	/***/ "./node_modules/core-js/modules/es.promise.catch.js":
	/*!**********************************************************!*\
	  !*** ./node_modules/core-js/modules/es.promise.catch.js ***!
	  \**********************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
	var IS_PURE = __webpack_require__(/*! ../internals/is-pure */ "./node_modules/core-js/internals/is-pure.js");
	var FORCED_PROMISE_CONSTRUCTOR = (__webpack_require__(/*! ../internals/promise-constructor-detection */ "./node_modules/core-js/internals/promise-constructor-detection.js").CONSTRUCTOR);
	var NativePromiseConstructor = __webpack_require__(/*! ../internals/promise-native-constructor */ "./node_modules/core-js/internals/promise-native-constructor.js");
	var getBuiltIn = __webpack_require__(/*! ../internals/get-built-in */ "./node_modules/core-js/internals/get-built-in.js");
	var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/core-js/internals/is-callable.js");
	var defineBuiltIn = __webpack_require__(/*! ../internals/define-built-in */ "./node_modules/core-js/internals/define-built-in.js");

	var NativePromisePrototype = NativePromiseConstructor && NativePromiseConstructor.prototype;

	// `Promise.prototype.catch` method
	// https://tc39.es/ecma262/#sec-promise.prototype.catch
	$({ target: 'Promise', proto: true, forced: FORCED_PROMISE_CONSTRUCTOR, real: true }, {
	  'catch': function (onRejected) {
	    return this.then(undefined, onRejected);
	  }
	});

	// makes sure that native promise-based APIs `Promise#catch` properly works with patched `Promise#then`
	if (!IS_PURE && isCallable(NativePromiseConstructor)) {
	  var method = getBuiltIn('Promise').prototype['catch'];
	  if (NativePromisePrototype['catch'] !== method) {
	    defineBuiltIn(NativePromisePrototype, 'catch', method, { unsafe: true });
	  }
	}


	/***/ }),

	/***/ "./node_modules/core-js/modules/es.promise.constructor.js":
	/*!****************************************************************!*\
	  !*** ./node_modules/core-js/modules/es.promise.constructor.js ***!
	  \****************************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
	var IS_PURE = __webpack_require__(/*! ../internals/is-pure */ "./node_modules/core-js/internals/is-pure.js");
	var IS_NODE = __webpack_require__(/*! ../internals/environment-is-node */ "./node_modules/core-js/internals/environment-is-node.js");
	var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/core-js/internals/global-this.js");
	var path = __webpack_require__(/*! ../internals/path */ "./node_modules/core-js/internals/path.js");
	var call = __webpack_require__(/*! ../internals/function-call */ "./node_modules/core-js/internals/function-call.js");
	var defineBuiltIn = __webpack_require__(/*! ../internals/define-built-in */ "./node_modules/core-js/internals/define-built-in.js");
	var setPrototypeOf = __webpack_require__(/*! ../internals/object-set-prototype-of */ "./node_modules/core-js/internals/object-set-prototype-of.js");
	var setToStringTag = __webpack_require__(/*! ../internals/set-to-string-tag */ "./node_modules/core-js/internals/set-to-string-tag.js");
	var setSpecies = __webpack_require__(/*! ../internals/set-species */ "./node_modules/core-js/internals/set-species.js");
	var aCallable = __webpack_require__(/*! ../internals/a-callable */ "./node_modules/core-js/internals/a-callable.js");
	var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/core-js/internals/is-callable.js");
	var isObject = __webpack_require__(/*! ../internals/is-object */ "./node_modules/core-js/internals/is-object.js");
	var anInstance = __webpack_require__(/*! ../internals/an-instance */ "./node_modules/core-js/internals/an-instance.js");
	var speciesConstructor = __webpack_require__(/*! ../internals/species-constructor */ "./node_modules/core-js/internals/species-constructor.js");
	var task = (__webpack_require__(/*! ../internals/task */ "./node_modules/core-js/internals/task.js").set);
	var microtask = __webpack_require__(/*! ../internals/microtask */ "./node_modules/core-js/internals/microtask.js");
	var hostReportErrors = __webpack_require__(/*! ../internals/host-report-errors */ "./node_modules/core-js/internals/host-report-errors.js");
	var perform = __webpack_require__(/*! ../internals/perform */ "./node_modules/core-js/internals/perform.js");
	var Queue = __webpack_require__(/*! ../internals/queue */ "./node_modules/core-js/internals/queue.js");
	var InternalStateModule = __webpack_require__(/*! ../internals/internal-state */ "./node_modules/core-js/internals/internal-state.js");
	var NativePromiseConstructor = __webpack_require__(/*! ../internals/promise-native-constructor */ "./node_modules/core-js/internals/promise-native-constructor.js");
	var PromiseConstructorDetection = __webpack_require__(/*! ../internals/promise-constructor-detection */ "./node_modules/core-js/internals/promise-constructor-detection.js");
	var newPromiseCapabilityModule = __webpack_require__(/*! ../internals/new-promise-capability */ "./node_modules/core-js/internals/new-promise-capability.js");

	var PROMISE = 'Promise';
	var FORCED_PROMISE_CONSTRUCTOR = PromiseConstructorDetection.CONSTRUCTOR;
	var NATIVE_PROMISE_REJECTION_EVENT = PromiseConstructorDetection.REJECTION_EVENT;
	var NATIVE_PROMISE_SUBCLASSING = PromiseConstructorDetection.SUBCLASSING;
	var getInternalPromiseState = InternalStateModule.getterFor(PROMISE);
	var setInternalState = InternalStateModule.set;
	var NativePromisePrototype = NativePromiseConstructor && NativePromiseConstructor.prototype;
	var PromiseConstructor = NativePromiseConstructor;
	var PromisePrototype = NativePromisePrototype;
	var TypeError = globalThis.TypeError;
	var document = globalThis.document;
	var process = globalThis.process;
	var newPromiseCapability = newPromiseCapabilityModule.f;
	var newGenericPromiseCapability = newPromiseCapability;

	var DISPATCH_EVENT = !!(document && document.createEvent && globalThis.dispatchEvent);
	var UNHANDLED_REJECTION = 'unhandledrejection';
	var REJECTION_HANDLED = 'rejectionhandled';
	var PENDING = 0;
	var FULFILLED = 1;
	var REJECTED = 2;
	var HANDLED = 1;
	var UNHANDLED = 2;

	var Internal, OwnPromiseCapability, PromiseWrapper, nativeThen;

	// helpers
	var isThenable = function (it) {
	  var then;
	  return isObject(it) && isCallable(then = it.then) ? then : false;
	};

	var callReaction = function (reaction, state) {
	  var value = state.value;
	  var ok = state.state === FULFILLED;
	  var handler = ok ? reaction.ok : reaction.fail;
	  var resolve = reaction.resolve;
	  var reject = reaction.reject;
	  var domain = reaction.domain;
	  var result, then, exited;
	  try {
	    if (handler) {
	      if (!ok) {
	        if (state.rejection === UNHANDLED) onHandleUnhandled(state);
	        state.rejection = HANDLED;
	      }
	      if (handler === true) result = value;
	      else {
	        if (domain) domain.enter();
	        result = handler(value); // can throw
	        if (domain) {
	          domain.exit();
	          exited = true;
	        }
	      }
	      if (result === reaction.promise) {
	        reject(new TypeError('Promise-chain cycle'));
	      } else if (then = isThenable(result)) {
	        call(then, result, resolve, reject);
	      } else resolve(result);
	    } else reject(value);
	  } catch (error) {
	    if (domain && !exited) domain.exit();
	    reject(error);
	  }
	};

	var notify = function (state, isReject) {
	  if (state.notified) return;
	  state.notified = true;
	  microtask(function () {
	    var reactions = state.reactions;
	    var reaction;
	    while (reaction = reactions.get()) {
	      callReaction(reaction, state);
	    }
	    state.notified = false;
	    if (isReject && !state.rejection) onUnhandled(state);
	  });
	};

	var dispatchEvent = function (name, promise, reason) {
	  var event, handler;
	  if (DISPATCH_EVENT) {
	    event = document.createEvent('Event');
	    event.promise = promise;
	    event.reason = reason;
	    event.initEvent(name, false, true);
	    globalThis.dispatchEvent(event);
	  } else event = { promise: promise, reason: reason };
	  if (!NATIVE_PROMISE_REJECTION_EVENT && (handler = globalThis['on' + name])) handler(event);
	  else if (name === UNHANDLED_REJECTION) hostReportErrors('Unhandled promise rejection', reason);
	};

	var onUnhandled = function (state) {
	  call(task, globalThis, function () {
	    var promise = state.facade;
	    var value = state.value;
	    var IS_UNHANDLED = isUnhandled(state);
	    var result;
	    if (IS_UNHANDLED) {
	      result = perform(function () {
	        if (IS_NODE) {
	          process.emit('unhandledRejection', value, promise);
	        } else dispatchEvent(UNHANDLED_REJECTION, promise, value);
	      });
	      // Browsers should not trigger `rejectionHandled` event if it was handled here, NodeJS - should
	      state.rejection = IS_NODE || isUnhandled(state) ? UNHANDLED : HANDLED;
	      if (result.error) throw result.value;
	    }
	  });
	};

	var isUnhandled = function (state) {
	  return state.rejection !== HANDLED && !state.parent;
	};

	var onHandleUnhandled = function (state) {
	  call(task, globalThis, function () {
	    var promise = state.facade;
	    if (IS_NODE) {
	      process.emit('rejectionHandled', promise);
	    } else dispatchEvent(REJECTION_HANDLED, promise, state.value);
	  });
	};

	var bind = function (fn, state, unwrap) {
	  return function (value) {
	    fn(state, value, unwrap);
	  };
	};

	var internalReject = function (state, value, unwrap) {
	  if (state.done) return;
	  state.done = true;
	  if (unwrap) state = unwrap;
	  state.value = value;
	  state.state = REJECTED;
	  notify(state, true);
	};

	var internalResolve = function (state, value, unwrap) {
	  if (state.done) return;
	  state.done = true;
	  if (unwrap) state = unwrap;
	  try {
	    if (state.facade === value) throw new TypeError("Promise can't be resolved itself");
	    var then = isThenable(value);
	    if (then) {
	      microtask(function () {
	        var wrapper = { done: false };
	        try {
	          call(then, value,
	            bind(internalResolve, wrapper, state),
	            bind(internalReject, wrapper, state)
	          );
	        } catch (error) {
	          internalReject(wrapper, error, state);
	        }
	      });
	    } else {
	      state.value = value;
	      state.state = FULFILLED;
	      notify(state, false);
	    }
	  } catch (error) {
	    internalReject({ done: false }, error, state);
	  }
	};

	// constructor polyfill
	if (FORCED_PROMISE_CONSTRUCTOR) {
	  // 25.4.3.1 Promise(executor)
	  PromiseConstructor = function Promise(executor) {
	    anInstance(this, PromisePrototype);
	    aCallable(executor);
	    call(Internal, this);
	    var state = getInternalPromiseState(this);
	    try {
	      executor(bind(internalResolve, state), bind(internalReject, state));
	    } catch (error) {
	      internalReject(state, error);
	    }
	  };

	  PromisePrototype = PromiseConstructor.prototype;

	  // eslint-disable-next-line no-unused-vars -- required for `.length`
	  Internal = function Promise(executor) {
	    setInternalState(this, {
	      type: PROMISE,
	      done: false,
	      notified: false,
	      parent: false,
	      reactions: new Queue(),
	      rejection: false,
	      state: PENDING,
	      value: null
	    });
	  };

	  // `Promise.prototype.then` method
	  // https://tc39.es/ecma262/#sec-promise.prototype.then
	  Internal.prototype = defineBuiltIn(PromisePrototype, 'then', function then(onFulfilled, onRejected) {
	    var state = getInternalPromiseState(this);
	    var reaction = newPromiseCapability(speciesConstructor(this, PromiseConstructor));
	    state.parent = true;
	    reaction.ok = isCallable(onFulfilled) ? onFulfilled : true;
	    reaction.fail = isCallable(onRejected) && onRejected;
	    reaction.domain = IS_NODE ? process.domain : undefined;
	    if (state.state === PENDING) state.reactions.add(reaction);
	    else microtask(function () {
	      callReaction(reaction, state);
	    });
	    return reaction.promise;
	  });

	  OwnPromiseCapability = function () {
	    var promise = new Internal();
	    var state = getInternalPromiseState(promise);
	    this.promise = promise;
	    this.resolve = bind(internalResolve, state);
	    this.reject = bind(internalReject, state);
	  };

	  newPromiseCapabilityModule.f = newPromiseCapability = function (C) {
	    return C === PromiseConstructor || C === PromiseWrapper
	      ? new OwnPromiseCapability(C)
	      : newGenericPromiseCapability(C);
	  };

	  if (!IS_PURE && isCallable(NativePromiseConstructor) && NativePromisePrototype !== Object.prototype) {
	    nativeThen = NativePromisePrototype.then;

	    if (!NATIVE_PROMISE_SUBCLASSING) {
	      // make `Promise#then` return a polyfilled `Promise` for native promise-based APIs
	      defineBuiltIn(NativePromisePrototype, 'then', function then(onFulfilled, onRejected) {
	        var that = this;
	        return new PromiseConstructor(function (resolve, reject) {
	          call(nativeThen, that, resolve, reject);
	        }).then(onFulfilled, onRejected);
	      // https://github.com/zloirock/core-js/issues/640
	      }, { unsafe: true });
	    }

	    // make `.constructor === Promise` work for native promise-based APIs
	    try {
	      delete NativePromisePrototype.constructor;
	    } catch (error) { /* empty */ }

	    // make `instanceof Promise` work for native promise-based APIs
	    if (setPrototypeOf) {
	      setPrototypeOf(NativePromisePrototype, PromisePrototype);
	    }
	  }
	}

	// `Promise` constructor
	// https://tc39.es/ecma262/#sec-promise-executor
	$({ global: true, constructor: true, wrap: true, forced: FORCED_PROMISE_CONSTRUCTOR }, {
	  Promise: PromiseConstructor
	});

	PromiseWrapper = path.Promise;

	setToStringTag(PromiseConstructor, PROMISE, false, true);
	setSpecies(PROMISE);


	/***/ }),

	/***/ "./node_modules/core-js/modules/es.promise.js":
	/*!****************************************************!*\
	  !*** ./node_modules/core-js/modules/es.promise.js ***!
	  \****************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	// TODO: Remove this module from `core-js@4` since it's split to modules listed below
	__webpack_require__(/*! ../modules/es.promise.constructor */ "./node_modules/core-js/modules/es.promise.constructor.js");
	__webpack_require__(/*! ../modules/es.promise.all */ "./node_modules/core-js/modules/es.promise.all.js");
	__webpack_require__(/*! ../modules/es.promise.catch */ "./node_modules/core-js/modules/es.promise.catch.js");
	__webpack_require__(/*! ../modules/es.promise.race */ "./node_modules/core-js/modules/es.promise.race.js");
	__webpack_require__(/*! ../modules/es.promise.reject */ "./node_modules/core-js/modules/es.promise.reject.js");
	__webpack_require__(/*! ../modules/es.promise.resolve */ "./node_modules/core-js/modules/es.promise.resolve.js");


	/***/ }),

	/***/ "./node_modules/core-js/modules/es.promise.race.js":
	/*!*********************************************************!*\
	  !*** ./node_modules/core-js/modules/es.promise.race.js ***!
	  \*********************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
	var call = __webpack_require__(/*! ../internals/function-call */ "./node_modules/core-js/internals/function-call.js");
	var aCallable = __webpack_require__(/*! ../internals/a-callable */ "./node_modules/core-js/internals/a-callable.js");
	var newPromiseCapabilityModule = __webpack_require__(/*! ../internals/new-promise-capability */ "./node_modules/core-js/internals/new-promise-capability.js");
	var perform = __webpack_require__(/*! ../internals/perform */ "./node_modules/core-js/internals/perform.js");
	var iterate = __webpack_require__(/*! ../internals/iterate */ "./node_modules/core-js/internals/iterate.js");
	var PROMISE_STATICS_INCORRECT_ITERATION = __webpack_require__(/*! ../internals/promise-statics-incorrect-iteration */ "./node_modules/core-js/internals/promise-statics-incorrect-iteration.js");

	// `Promise.race` method
	// https://tc39.es/ecma262/#sec-promise.race
	$({ target: 'Promise', stat: true, forced: PROMISE_STATICS_INCORRECT_ITERATION }, {
	  race: function race(iterable) {
	    var C = this;
	    var capability = newPromiseCapabilityModule.f(C);
	    var reject = capability.reject;
	    var result = perform(function () {
	      var $promiseResolve = aCallable(C.resolve);
	      iterate(iterable, function (promise) {
	        call($promiseResolve, C, promise).then(capability.resolve, reject);
	      });
	    });
	    if (result.error) reject(result.value);
	    return capability.promise;
	  }
	});


	/***/ }),

	/***/ "./node_modules/core-js/modules/es.promise.reject.js":
	/*!***********************************************************!*\
	  !*** ./node_modules/core-js/modules/es.promise.reject.js ***!
	  \***********************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
	var newPromiseCapabilityModule = __webpack_require__(/*! ../internals/new-promise-capability */ "./node_modules/core-js/internals/new-promise-capability.js");
	var FORCED_PROMISE_CONSTRUCTOR = (__webpack_require__(/*! ../internals/promise-constructor-detection */ "./node_modules/core-js/internals/promise-constructor-detection.js").CONSTRUCTOR);

	// `Promise.reject` method
	// https://tc39.es/ecma262/#sec-promise.reject
	$({ target: 'Promise', stat: true, forced: FORCED_PROMISE_CONSTRUCTOR }, {
	  reject: function reject(r) {
	    var capability = newPromiseCapabilityModule.f(this);
	    var capabilityReject = capability.reject;
	    capabilityReject(r);
	    return capability.promise;
	  }
	});


	/***/ }),

	/***/ "./node_modules/core-js/modules/es.promise.resolve.js":
	/*!************************************************************!*\
	  !*** ./node_modules/core-js/modules/es.promise.resolve.js ***!
	  \************************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
	var getBuiltIn = __webpack_require__(/*! ../internals/get-built-in */ "./node_modules/core-js/internals/get-built-in.js");
	var IS_PURE = __webpack_require__(/*! ../internals/is-pure */ "./node_modules/core-js/internals/is-pure.js");
	var NativePromiseConstructor = __webpack_require__(/*! ../internals/promise-native-constructor */ "./node_modules/core-js/internals/promise-native-constructor.js");
	var FORCED_PROMISE_CONSTRUCTOR = (__webpack_require__(/*! ../internals/promise-constructor-detection */ "./node_modules/core-js/internals/promise-constructor-detection.js").CONSTRUCTOR);
	var promiseResolve = __webpack_require__(/*! ../internals/promise-resolve */ "./node_modules/core-js/internals/promise-resolve.js");

	var PromiseConstructorWrapper = getBuiltIn('Promise');
	var CHECK_WRAPPER = IS_PURE && !FORCED_PROMISE_CONSTRUCTOR;

	// `Promise.resolve` method
	// https://tc39.es/ecma262/#sec-promise.resolve
	$({ target: 'Promise', stat: true, forced: IS_PURE || FORCED_PROMISE_CONSTRUCTOR }, {
	  resolve: function resolve(x) {
	    return promiseResolve(CHECK_WRAPPER && this === PromiseConstructorWrapper ? NativePromiseConstructor : this, x);
	  }
	});


	/***/ }),

	/***/ "./node_modules/core-js/modules/es.regexp.exec.js":
	/*!********************************************************!*\
	  !*** ./node_modules/core-js/modules/es.regexp.exec.js ***!
	  \********************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
	var exec = __webpack_require__(/*! ../internals/regexp-exec */ "./node_modules/core-js/internals/regexp-exec.js");

	// `RegExp.prototype.exec` method
	// https://tc39.es/ecma262/#sec-regexp.prototype.exec
	$({ target: 'RegExp', proto: true, forced: /./.exec !== exec }, {
	  exec: exec
	});


	/***/ }),

	/***/ "./node_modules/core-js/modules/es.regexp.test.js":
	/*!********************************************************!*\
	  !*** ./node_modules/core-js/modules/es.regexp.test.js ***!
	  \********************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	// TODO: Remove from `core-js@4` since it's moved to entry points
	__webpack_require__(/*! ../modules/es.regexp.exec */ "./node_modules/core-js/modules/es.regexp.exec.js");
	var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
	var call = __webpack_require__(/*! ../internals/function-call */ "./node_modules/core-js/internals/function-call.js");
	var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/core-js/internals/is-callable.js");
	var anObject = __webpack_require__(/*! ../internals/an-object */ "./node_modules/core-js/internals/an-object.js");
	var toString = __webpack_require__(/*! ../internals/to-string */ "./node_modules/core-js/internals/to-string.js");

	var DELEGATES_TO_EXEC = function () {
	  var execCalled = false;
	  var re = /[ac]/;
	  re.exec = function () {
	    execCalled = true;
	    return /./.exec.apply(this, arguments);
	  };
	  return re.test('abc') === true && execCalled;
	}();

	var nativeTest = /./.test;

	// `RegExp.prototype.test` method
	// https://tc39.es/ecma262/#sec-regexp.prototype.test
	$({ target: 'RegExp', proto: true, forced: !DELEGATES_TO_EXEC }, {
	  test: function (S) {
	    var R = anObject(this);
	    var string = toString(S);
	    var exec = R.exec;
	    if (!isCallable(exec)) return call(nativeTest, R, string);
	    var result = call(exec, R, string);
	    if (result === null) return false;
	    anObject(result);
	    return true;
	  }
	});


	/***/ }),

	/***/ "./node_modules/core-js/modules/es.regexp.to-string.js":
	/*!*************************************************************!*\
	  !*** ./node_modules/core-js/modules/es.regexp.to-string.js ***!
	  \*************************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	var PROPER_FUNCTION_NAME = (__webpack_require__(/*! ../internals/function-name */ "./node_modules/core-js/internals/function-name.js").PROPER);
	var defineBuiltIn = __webpack_require__(/*! ../internals/define-built-in */ "./node_modules/core-js/internals/define-built-in.js");
	var anObject = __webpack_require__(/*! ../internals/an-object */ "./node_modules/core-js/internals/an-object.js");
	var $toString = __webpack_require__(/*! ../internals/to-string */ "./node_modules/core-js/internals/to-string.js");
	var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/core-js/internals/fails.js");
	var getRegExpFlags = __webpack_require__(/*! ../internals/regexp-get-flags */ "./node_modules/core-js/internals/regexp-get-flags.js");

	var TO_STRING = 'toString';
	var RegExpPrototype = RegExp.prototype;
	var nativeToString = RegExpPrototype[TO_STRING];

	var NOT_GENERIC = fails(function () { return nativeToString.call({ source: 'a', flags: 'b' }) !== '/a/b'; });
	// FF44- RegExp#toString has a wrong name
	var INCORRECT_NAME = PROPER_FUNCTION_NAME && nativeToString.name !== TO_STRING;

	// `RegExp.prototype.toString` method
	// https://tc39.es/ecma262/#sec-regexp.prototype.tostring
	if (NOT_GENERIC || INCORRECT_NAME) {
	  defineBuiltIn(RegExpPrototype, TO_STRING, function toString() {
	    var R = anObject(this);
	    var pattern = $toString(R.source);
	    var flags = $toString(getRegExpFlags(R));
	    return '/' + pattern + '/' + flags;
	  }, { unsafe: true });
	}


	/***/ }),

	/***/ "./node_modules/core-js/modules/es.set.constructor.js":
	/*!************************************************************!*\
	  !*** ./node_modules/core-js/modules/es.set.constructor.js ***!
	  \************************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	var collection = __webpack_require__(/*! ../internals/collection */ "./node_modules/core-js/internals/collection.js");
	var collectionStrong = __webpack_require__(/*! ../internals/collection-strong */ "./node_modules/core-js/internals/collection-strong.js");

	// `Set` constructor
	// https://tc39.es/ecma262/#sec-set-objects
	collection('Set', function (init) {
	  return function Set() { return init(this, arguments.length ? arguments[0] : undefined); };
	}, collectionStrong);


	/***/ }),

	/***/ "./node_modules/core-js/modules/es.set.js":
	/*!************************************************!*\
	  !*** ./node_modules/core-js/modules/es.set.js ***!
	  \************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	// TODO: Remove this module from `core-js@4` since it's replaced to module below
	__webpack_require__(/*! ../modules/es.set.constructor */ "./node_modules/core-js/modules/es.set.constructor.js");


	/***/ }),

	/***/ "./node_modules/core-js/modules/es.string.iterator.js":
	/*!************************************************************!*\
	  !*** ./node_modules/core-js/modules/es.string.iterator.js ***!
	  \************************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	var charAt = (__webpack_require__(/*! ../internals/string-multibyte */ "./node_modules/core-js/internals/string-multibyte.js").charAt);
	var toString = __webpack_require__(/*! ../internals/to-string */ "./node_modules/core-js/internals/to-string.js");
	var InternalStateModule = __webpack_require__(/*! ../internals/internal-state */ "./node_modules/core-js/internals/internal-state.js");
	var defineIterator = __webpack_require__(/*! ../internals/iterator-define */ "./node_modules/core-js/internals/iterator-define.js");
	var createIterResultObject = __webpack_require__(/*! ../internals/create-iter-result-object */ "./node_modules/core-js/internals/create-iter-result-object.js");

	var STRING_ITERATOR = 'String Iterator';
	var setInternalState = InternalStateModule.set;
	var getInternalState = InternalStateModule.getterFor(STRING_ITERATOR);

	// `String.prototype[@@iterator]` method
	// https://tc39.es/ecma262/#sec-string.prototype-@@iterator
	defineIterator(String, 'String', function (iterated) {
	  setInternalState(this, {
	    type: STRING_ITERATOR,
	    string: toString(iterated),
	    index: 0
	  });
	// `%StringIteratorPrototype%.next` method
	// https://tc39.es/ecma262/#sec-%stringiteratorprototype%.next
	}, function next() {
	  var state = getInternalState(this);
	  var string = state.string;
	  var index = state.index;
	  var point;
	  if (index >= string.length) return createIterResultObject(undefined, true);
	  point = charAt(string, index);
	  state.index += point.length;
	  return createIterResultObject(point, false);
	});


	/***/ }),

	/***/ "./node_modules/core-js/modules/es.string.link.js":
	/*!********************************************************!*\
	  !*** ./node_modules/core-js/modules/es.string.link.js ***!
	  \********************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
	var createHTML = __webpack_require__(/*! ../internals/create-html */ "./node_modules/core-js/internals/create-html.js");
	var forcedStringHTMLMethod = __webpack_require__(/*! ../internals/string-html-forced */ "./node_modules/core-js/internals/string-html-forced.js");

	// `String.prototype.link` method
	// https://tc39.es/ecma262/#sec-string.prototype.link
	$({ target: 'String', proto: true, forced: forcedStringHTMLMethod('link') }, {
	  link: function link(url) {
	    return createHTML(this, 'a', 'href', url);
	  }
	});


	/***/ }),

	/***/ "./node_modules/core-js/modules/es.symbol.constructor.js":
	/*!***************************************************************!*\
	  !*** ./node_modules/core-js/modules/es.symbol.constructor.js ***!
	  \***************************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
	var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/core-js/internals/global-this.js");
	var call = __webpack_require__(/*! ../internals/function-call */ "./node_modules/core-js/internals/function-call.js");
	var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/core-js/internals/function-uncurry-this.js");
	var IS_PURE = __webpack_require__(/*! ../internals/is-pure */ "./node_modules/core-js/internals/is-pure.js");
	var DESCRIPTORS = __webpack_require__(/*! ../internals/descriptors */ "./node_modules/core-js/internals/descriptors.js");
	var NATIVE_SYMBOL = __webpack_require__(/*! ../internals/symbol-constructor-detection */ "./node_modules/core-js/internals/symbol-constructor-detection.js");
	var fails = __webpack_require__(/*! ../internals/fails */ "./node_modules/core-js/internals/fails.js");
	var hasOwn = __webpack_require__(/*! ../internals/has-own-property */ "./node_modules/core-js/internals/has-own-property.js");
	var isPrototypeOf = __webpack_require__(/*! ../internals/object-is-prototype-of */ "./node_modules/core-js/internals/object-is-prototype-of.js");
	var anObject = __webpack_require__(/*! ../internals/an-object */ "./node_modules/core-js/internals/an-object.js");
	var toIndexedObject = __webpack_require__(/*! ../internals/to-indexed-object */ "./node_modules/core-js/internals/to-indexed-object.js");
	var toPropertyKey = __webpack_require__(/*! ../internals/to-property-key */ "./node_modules/core-js/internals/to-property-key.js");
	var $toString = __webpack_require__(/*! ../internals/to-string */ "./node_modules/core-js/internals/to-string.js");
	var createPropertyDescriptor = __webpack_require__(/*! ../internals/create-property-descriptor */ "./node_modules/core-js/internals/create-property-descriptor.js");
	var nativeObjectCreate = __webpack_require__(/*! ../internals/object-create */ "./node_modules/core-js/internals/object-create.js");
	var objectKeys = __webpack_require__(/*! ../internals/object-keys */ "./node_modules/core-js/internals/object-keys.js");
	var getOwnPropertyNamesModule = __webpack_require__(/*! ../internals/object-get-own-property-names */ "./node_modules/core-js/internals/object-get-own-property-names.js");
	var getOwnPropertyNamesExternal = __webpack_require__(/*! ../internals/object-get-own-property-names-external */ "./node_modules/core-js/internals/object-get-own-property-names-external.js");
	var getOwnPropertySymbolsModule = __webpack_require__(/*! ../internals/object-get-own-property-symbols */ "./node_modules/core-js/internals/object-get-own-property-symbols.js");
	var getOwnPropertyDescriptorModule = __webpack_require__(/*! ../internals/object-get-own-property-descriptor */ "./node_modules/core-js/internals/object-get-own-property-descriptor.js");
	var definePropertyModule = __webpack_require__(/*! ../internals/object-define-property */ "./node_modules/core-js/internals/object-define-property.js");
	var definePropertiesModule = __webpack_require__(/*! ../internals/object-define-properties */ "./node_modules/core-js/internals/object-define-properties.js");
	var propertyIsEnumerableModule = __webpack_require__(/*! ../internals/object-property-is-enumerable */ "./node_modules/core-js/internals/object-property-is-enumerable.js");
	var defineBuiltIn = __webpack_require__(/*! ../internals/define-built-in */ "./node_modules/core-js/internals/define-built-in.js");
	var defineBuiltInAccessor = __webpack_require__(/*! ../internals/define-built-in-accessor */ "./node_modules/core-js/internals/define-built-in-accessor.js");
	var shared = __webpack_require__(/*! ../internals/shared */ "./node_modules/core-js/internals/shared.js");
	var sharedKey = __webpack_require__(/*! ../internals/shared-key */ "./node_modules/core-js/internals/shared-key.js");
	var hiddenKeys = __webpack_require__(/*! ../internals/hidden-keys */ "./node_modules/core-js/internals/hidden-keys.js");
	var uid = __webpack_require__(/*! ../internals/uid */ "./node_modules/core-js/internals/uid.js");
	var wellKnownSymbol = __webpack_require__(/*! ../internals/well-known-symbol */ "./node_modules/core-js/internals/well-known-symbol.js");
	var wrappedWellKnownSymbolModule = __webpack_require__(/*! ../internals/well-known-symbol-wrapped */ "./node_modules/core-js/internals/well-known-symbol-wrapped.js");
	var defineWellKnownSymbol = __webpack_require__(/*! ../internals/well-known-symbol-define */ "./node_modules/core-js/internals/well-known-symbol-define.js");
	var defineSymbolToPrimitive = __webpack_require__(/*! ../internals/symbol-define-to-primitive */ "./node_modules/core-js/internals/symbol-define-to-primitive.js");
	var setToStringTag = __webpack_require__(/*! ../internals/set-to-string-tag */ "./node_modules/core-js/internals/set-to-string-tag.js");
	var InternalStateModule = __webpack_require__(/*! ../internals/internal-state */ "./node_modules/core-js/internals/internal-state.js");
	var $forEach = (__webpack_require__(/*! ../internals/array-iteration */ "./node_modules/core-js/internals/array-iteration.js").forEach);

	var HIDDEN = sharedKey('hidden');
	var SYMBOL = 'Symbol';
	var PROTOTYPE = 'prototype';

	var setInternalState = InternalStateModule.set;
	var getInternalState = InternalStateModule.getterFor(SYMBOL);

	var ObjectPrototype = Object[PROTOTYPE];
	var $Symbol = globalThis.Symbol;
	var SymbolPrototype = $Symbol && $Symbol[PROTOTYPE];
	var RangeError = globalThis.RangeError;
	var TypeError = globalThis.TypeError;
	var QObject = globalThis.QObject;
	var nativeGetOwnPropertyDescriptor = getOwnPropertyDescriptorModule.f;
	var nativeDefineProperty = definePropertyModule.f;
	var nativeGetOwnPropertyNames = getOwnPropertyNamesExternal.f;
	var nativePropertyIsEnumerable = propertyIsEnumerableModule.f;
	var push = uncurryThis([].push);

	var AllSymbols = shared('symbols');
	var ObjectPrototypeSymbols = shared('op-symbols');
	var WellKnownSymbolsStore = shared('wks');

	// Don't use setters in Qt Script, https://github.com/zloirock/core-js/issues/173
	var USE_SETTER = !QObject || !QObject[PROTOTYPE] || !QObject[PROTOTYPE].findChild;

	// fallback for old Android, https://code.google.com/p/v8/issues/detail?id=687
	var fallbackDefineProperty = function (O, P, Attributes) {
	  var ObjectPrototypeDescriptor = nativeGetOwnPropertyDescriptor(ObjectPrototype, P);
	  if (ObjectPrototypeDescriptor) delete ObjectPrototype[P];
	  nativeDefineProperty(O, P, Attributes);
	  if (ObjectPrototypeDescriptor && O !== ObjectPrototype) {
	    nativeDefineProperty(ObjectPrototype, P, ObjectPrototypeDescriptor);
	  }
	};

	var setSymbolDescriptor = DESCRIPTORS && fails(function () {
	  return nativeObjectCreate(nativeDefineProperty({}, 'a', {
	    get: function () { return nativeDefineProperty(this, 'a', { value: 7 }).a; }
	  })).a !== 7;
	}) ? fallbackDefineProperty : nativeDefineProperty;

	var wrap = function (tag, description) {
	  var symbol = AllSymbols[tag] = nativeObjectCreate(SymbolPrototype);
	  setInternalState(symbol, {
	    type: SYMBOL,
	    tag: tag,
	    description: description
	  });
	  if (!DESCRIPTORS) symbol.description = description;
	  return symbol;
	};

	var $defineProperty = function defineProperty(O, P, Attributes) {
	  if (O === ObjectPrototype) $defineProperty(ObjectPrototypeSymbols, P, Attributes);
	  anObject(O);
	  var key = toPropertyKey(P);
	  anObject(Attributes);
	  if (hasOwn(AllSymbols, key)) {
	    if (!Attributes.enumerable) {
	      if (!hasOwn(O, HIDDEN)) nativeDefineProperty(O, HIDDEN, createPropertyDescriptor(1, nativeObjectCreate(null)));
	      O[HIDDEN][key] = true;
	    } else {
	      if (hasOwn(O, HIDDEN) && O[HIDDEN][key]) O[HIDDEN][key] = false;
	      Attributes = nativeObjectCreate(Attributes, { enumerable: createPropertyDescriptor(0, false) });
	    } return setSymbolDescriptor(O, key, Attributes);
	  } return nativeDefineProperty(O, key, Attributes);
	};

	var $defineProperties = function defineProperties(O, Properties) {
	  anObject(O);
	  var properties = toIndexedObject(Properties);
	  var keys = objectKeys(properties).concat($getOwnPropertySymbols(properties));
	  $forEach(keys, function (key) {
	    if (!DESCRIPTORS || call($propertyIsEnumerable, properties, key)) $defineProperty(O, key, properties[key]);
	  });
	  return O;
	};

	var $create = function create(O, Properties) {
	  return Properties === undefined ? nativeObjectCreate(O) : $defineProperties(nativeObjectCreate(O), Properties);
	};

	var $propertyIsEnumerable = function propertyIsEnumerable(V) {
	  var P = toPropertyKey(V);
	  var enumerable = call(nativePropertyIsEnumerable, this, P);
	  if (this === ObjectPrototype && hasOwn(AllSymbols, P) && !hasOwn(ObjectPrototypeSymbols, P)) return false;
	  return enumerable || !hasOwn(this, P) || !hasOwn(AllSymbols, P) || hasOwn(this, HIDDEN) && this[HIDDEN][P]
	    ? enumerable : true;
	};

	var $getOwnPropertyDescriptor = function getOwnPropertyDescriptor(O, P) {
	  var it = toIndexedObject(O);
	  var key = toPropertyKey(P);
	  if (it === ObjectPrototype && hasOwn(AllSymbols, key) && !hasOwn(ObjectPrototypeSymbols, key)) return;
	  var descriptor = nativeGetOwnPropertyDescriptor(it, key);
	  if (descriptor && hasOwn(AllSymbols, key) && !(hasOwn(it, HIDDEN) && it[HIDDEN][key])) {
	    descriptor.enumerable = true;
	  }
	  return descriptor;
	};

	var $getOwnPropertyNames = function getOwnPropertyNames(O) {
	  var names = nativeGetOwnPropertyNames(toIndexedObject(O));
	  var result = [];
	  $forEach(names, function (key) {
	    if (!hasOwn(AllSymbols, key) && !hasOwn(hiddenKeys, key)) push(result, key);
	  });
	  return result;
	};

	var $getOwnPropertySymbols = function (O) {
	  var IS_OBJECT_PROTOTYPE = O === ObjectPrototype;
	  var names = nativeGetOwnPropertyNames(IS_OBJECT_PROTOTYPE ? ObjectPrototypeSymbols : toIndexedObject(O));
	  var result = [];
	  $forEach(names, function (key) {
	    if (hasOwn(AllSymbols, key) && (!IS_OBJECT_PROTOTYPE || hasOwn(ObjectPrototype, key))) {
	      push(result, AllSymbols[key]);
	    }
	  });
	  return result;
	};

	// `Symbol` constructor
	// https://tc39.es/ecma262/#sec-symbol-constructor
	if (!NATIVE_SYMBOL) {
	  $Symbol = function Symbol() {
	    if (isPrototypeOf(SymbolPrototype, this)) throw new TypeError('Symbol is not a constructor');
	    var description = !arguments.length || arguments[0] === undefined ? undefined : $toString(arguments[0]);
	    var tag = uid(description);
	    var setter = function (value) {
	      var $this = this === undefined ? globalThis : this;
	      if ($this === ObjectPrototype) call(setter, ObjectPrototypeSymbols, value);
	      if (hasOwn($this, HIDDEN) && hasOwn($this[HIDDEN], tag)) $this[HIDDEN][tag] = false;
	      var descriptor = createPropertyDescriptor(1, value);
	      try {
	        setSymbolDescriptor($this, tag, descriptor);
	      } catch (error) {
	        if (!(error instanceof RangeError)) throw error;
	        fallbackDefineProperty($this, tag, descriptor);
	      }
	    };
	    if (DESCRIPTORS && USE_SETTER) setSymbolDescriptor(ObjectPrototype, tag, { configurable: true, set: setter });
	    return wrap(tag, description);
	  };

	  SymbolPrototype = $Symbol[PROTOTYPE];

	  defineBuiltIn(SymbolPrototype, 'toString', function toString() {
	    return getInternalState(this).tag;
	  });

	  defineBuiltIn($Symbol, 'withoutSetter', function (description) {
	    return wrap(uid(description), description);
	  });

	  propertyIsEnumerableModule.f = $propertyIsEnumerable;
	  definePropertyModule.f = $defineProperty;
	  definePropertiesModule.f = $defineProperties;
	  getOwnPropertyDescriptorModule.f = $getOwnPropertyDescriptor;
	  getOwnPropertyNamesModule.f = getOwnPropertyNamesExternal.f = $getOwnPropertyNames;
	  getOwnPropertySymbolsModule.f = $getOwnPropertySymbols;

	  wrappedWellKnownSymbolModule.f = function (name) {
	    return wrap(wellKnownSymbol(name), name);
	  };

	  if (DESCRIPTORS) {
	    // https://tc39.es/ecma262/#sec-symbol.prototype.description
	    defineBuiltInAccessor(SymbolPrototype, 'description', {
	      configurable: true,
	      get: function description() {
	        return getInternalState(this).description;
	      }
	    });
	    if (!IS_PURE) {
	      defineBuiltIn(ObjectPrototype, 'propertyIsEnumerable', $propertyIsEnumerable, { unsafe: true });
	    }
	  }
	}

	$({ global: true, constructor: true, wrap: true, forced: !NATIVE_SYMBOL, sham: !NATIVE_SYMBOL }, {
	  Symbol: $Symbol
	});

	$forEach(objectKeys(WellKnownSymbolsStore), function (name) {
	  defineWellKnownSymbol(name);
	});

	$({ target: SYMBOL, stat: true, forced: !NATIVE_SYMBOL }, {
	  useSetter: function () { USE_SETTER = true; },
	  useSimple: function () { USE_SETTER = false; }
	});

	$({ target: 'Object', stat: true, forced: !NATIVE_SYMBOL, sham: !DESCRIPTORS }, {
	  // `Object.create` method
	  // https://tc39.es/ecma262/#sec-object.create
	  create: $create,
	  // `Object.defineProperty` method
	  // https://tc39.es/ecma262/#sec-object.defineproperty
	  defineProperty: $defineProperty,
	  // `Object.defineProperties` method
	  // https://tc39.es/ecma262/#sec-object.defineproperties
	  defineProperties: $defineProperties,
	  // `Object.getOwnPropertyDescriptor` method
	  // https://tc39.es/ecma262/#sec-object.getownpropertydescriptors
	  getOwnPropertyDescriptor: $getOwnPropertyDescriptor
	});

	$({ target: 'Object', stat: true, forced: !NATIVE_SYMBOL }, {
	  // `Object.getOwnPropertyNames` method
	  // https://tc39.es/ecma262/#sec-object.getownpropertynames
	  getOwnPropertyNames: $getOwnPropertyNames
	});

	// `Symbol.prototype[@@toPrimitive]` method
	// https://tc39.es/ecma262/#sec-symbol.prototype-@@toprimitive
	defineSymbolToPrimitive();

	// `Symbol.prototype[@@toStringTag]` property
	// https://tc39.es/ecma262/#sec-symbol.prototype-@@tostringtag
	setToStringTag($Symbol, SYMBOL);

	hiddenKeys[HIDDEN] = true;


	/***/ }),

	/***/ "./node_modules/core-js/modules/es.symbol.description.js":
	/*!***************************************************************!*\
	  !*** ./node_modules/core-js/modules/es.symbol.description.js ***!
	  \***************************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

	// `Symbol.prototype.description` getter
	// https://tc39.es/ecma262/#sec-symbol.prototype.description

	var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
	var DESCRIPTORS = __webpack_require__(/*! ../internals/descriptors */ "./node_modules/core-js/internals/descriptors.js");
	var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/core-js/internals/global-this.js");
	var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/core-js/internals/function-uncurry-this.js");
	var hasOwn = __webpack_require__(/*! ../internals/has-own-property */ "./node_modules/core-js/internals/has-own-property.js");
	var isCallable = __webpack_require__(/*! ../internals/is-callable */ "./node_modules/core-js/internals/is-callable.js");
	var isPrototypeOf = __webpack_require__(/*! ../internals/object-is-prototype-of */ "./node_modules/core-js/internals/object-is-prototype-of.js");
	var toString = __webpack_require__(/*! ../internals/to-string */ "./node_modules/core-js/internals/to-string.js");
	var defineBuiltInAccessor = __webpack_require__(/*! ../internals/define-built-in-accessor */ "./node_modules/core-js/internals/define-built-in-accessor.js");
	var copyConstructorProperties = __webpack_require__(/*! ../internals/copy-constructor-properties */ "./node_modules/core-js/internals/copy-constructor-properties.js");

	var NativeSymbol = globalThis.Symbol;
	var SymbolPrototype = NativeSymbol && NativeSymbol.prototype;

	if (DESCRIPTORS && isCallable(NativeSymbol) && (!('description' in SymbolPrototype) ||
	  // Safari 12 bug
	  NativeSymbol().description !== undefined
	)) {
	  var EmptyStringDescriptionStore = {};
	  // wrap Symbol constructor for correct work with undefined description
	  var SymbolWrapper = function Symbol() {
	    var description = arguments.length < 1 || arguments[0] === undefined ? undefined : toString(arguments[0]);
	    var result = isPrototypeOf(SymbolPrototype, this)
	      // eslint-disable-next-line sonarjs/inconsistent-function-call -- ok
	      ? new NativeSymbol(description)
	      // in Edge 13, String(Symbol(undefined)) === 'Symbol(undefined)'
	      : description === undefined ? NativeSymbol() : NativeSymbol(description);
	    if (description === '') EmptyStringDescriptionStore[result] = true;
	    return result;
	  };

	  copyConstructorProperties(SymbolWrapper, NativeSymbol);
	  SymbolWrapper.prototype = SymbolPrototype;
	  SymbolPrototype.constructor = SymbolWrapper;

	  var NATIVE_SYMBOL = String(NativeSymbol('description detection')) === 'Symbol(description detection)';
	  var thisSymbolValue = uncurryThis(SymbolPrototype.valueOf);
	  var symbolDescriptiveString = uncurryThis(SymbolPrototype.toString);
	  var regexp = /^Symbol\((.*)\)[^)]+$/;
	  var replace = uncurryThis(''.replace);
	  var stringSlice = uncurryThis(''.slice);

	  defineBuiltInAccessor(SymbolPrototype, 'description', {
	    configurable: true,
	    get: function description() {
	      var symbol = thisSymbolValue(this);
	      if (hasOwn(EmptyStringDescriptionStore, symbol)) return '';
	      var string = symbolDescriptiveString(symbol);
	      var desc = NATIVE_SYMBOL ? stringSlice(string, 7, -1) : replace(string, regexp, '$1');
	      return desc === '' ? undefined : desc;
	    }
	  });

	  $({ global: true, constructor: true, forced: true }, {
	    Symbol: SymbolWrapper
	  });
	}


	/***/ }),

	/***/ "./node_modules/core-js/modules/es.symbol.for.js":
	/*!*******************************************************!*\
	  !*** ./node_modules/core-js/modules/es.symbol.for.js ***!
	  \*******************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
	var getBuiltIn = __webpack_require__(/*! ../internals/get-built-in */ "./node_modules/core-js/internals/get-built-in.js");
	var hasOwn = __webpack_require__(/*! ../internals/has-own-property */ "./node_modules/core-js/internals/has-own-property.js");
	var toString = __webpack_require__(/*! ../internals/to-string */ "./node_modules/core-js/internals/to-string.js");
	var shared = __webpack_require__(/*! ../internals/shared */ "./node_modules/core-js/internals/shared.js");
	var NATIVE_SYMBOL_REGISTRY = __webpack_require__(/*! ../internals/symbol-registry-detection */ "./node_modules/core-js/internals/symbol-registry-detection.js");

	var StringToSymbolRegistry = shared('string-to-symbol-registry');
	var SymbolToStringRegistry = shared('symbol-to-string-registry');

	// `Symbol.for` method
	// https://tc39.es/ecma262/#sec-symbol.for
	$({ target: 'Symbol', stat: true, forced: !NATIVE_SYMBOL_REGISTRY }, {
	  'for': function (key) {
	    var string = toString(key);
	    if (hasOwn(StringToSymbolRegistry, string)) return StringToSymbolRegistry[string];
	    var symbol = getBuiltIn('Symbol')(string);
	    StringToSymbolRegistry[string] = symbol;
	    SymbolToStringRegistry[symbol] = string;
	    return symbol;
	  }
	});


	/***/ }),

	/***/ "./node_modules/core-js/modules/es.symbol.iterator.js":
	/*!************************************************************!*\
	  !*** ./node_modules/core-js/modules/es.symbol.iterator.js ***!
	  \************************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	var defineWellKnownSymbol = __webpack_require__(/*! ../internals/well-known-symbol-define */ "./node_modules/core-js/internals/well-known-symbol-define.js");

	// `Symbol.iterator` well-known symbol
	// https://tc39.es/ecma262/#sec-symbol.iterator
	defineWellKnownSymbol('iterator');


	/***/ }),

	/***/ "./node_modules/core-js/modules/es.symbol.js":
	/*!***************************************************!*\
	  !*** ./node_modules/core-js/modules/es.symbol.js ***!
	  \***************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	// TODO: Remove this module from `core-js@4` since it's split to modules listed below
	__webpack_require__(/*! ../modules/es.symbol.constructor */ "./node_modules/core-js/modules/es.symbol.constructor.js");
	__webpack_require__(/*! ../modules/es.symbol.for */ "./node_modules/core-js/modules/es.symbol.for.js");
	__webpack_require__(/*! ../modules/es.symbol.key-for */ "./node_modules/core-js/modules/es.symbol.key-for.js");
	__webpack_require__(/*! ../modules/es.json.stringify */ "./node_modules/core-js/modules/es.json.stringify.js");
	__webpack_require__(/*! ../modules/es.object.get-own-property-symbols */ "./node_modules/core-js/modules/es.object.get-own-property-symbols.js");


	/***/ }),

	/***/ "./node_modules/core-js/modules/es.symbol.key-for.js":
	/*!***********************************************************!*\
	  !*** ./node_modules/core-js/modules/es.symbol.key-for.js ***!
	  \***********************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
	var hasOwn = __webpack_require__(/*! ../internals/has-own-property */ "./node_modules/core-js/internals/has-own-property.js");
	var isSymbol = __webpack_require__(/*! ../internals/is-symbol */ "./node_modules/core-js/internals/is-symbol.js");
	var tryToString = __webpack_require__(/*! ../internals/try-to-string */ "./node_modules/core-js/internals/try-to-string.js");
	var shared = __webpack_require__(/*! ../internals/shared */ "./node_modules/core-js/internals/shared.js");
	var NATIVE_SYMBOL_REGISTRY = __webpack_require__(/*! ../internals/symbol-registry-detection */ "./node_modules/core-js/internals/symbol-registry-detection.js");

	var SymbolToStringRegistry = shared('symbol-to-string-registry');

	// `Symbol.keyFor` method
	// https://tc39.es/ecma262/#sec-symbol.keyfor
	$({ target: 'Symbol', stat: true, forced: !NATIVE_SYMBOL_REGISTRY }, {
	  keyFor: function keyFor(sym) {
	    if (!isSymbol(sym)) throw new TypeError(tryToString(sym) + ' is not a symbol');
	    if (hasOwn(SymbolToStringRegistry, sym)) return SymbolToStringRegistry[sym];
	  }
	});


	/***/ }),

	/***/ "./node_modules/core-js/modules/esnext.iterator.constructor.js":
	/*!*********************************************************************!*\
	  !*** ./node_modules/core-js/modules/esnext.iterator.constructor.js ***!
	  \*********************************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	// TODO: Remove from `core-js@4`
	__webpack_require__(/*! ../modules/es.iterator.constructor */ "./node_modules/core-js/modules/es.iterator.constructor.js");


	/***/ }),

	/***/ "./node_modules/core-js/modules/esnext.iterator.for-each.js":
	/*!******************************************************************!*\
	  !*** ./node_modules/core-js/modules/esnext.iterator.for-each.js ***!
	  \******************************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	// TODO: Remove from `core-js@4`
	__webpack_require__(/*! ../modules/es.iterator.for-each */ "./node_modules/core-js/modules/es.iterator.for-each.js");


	/***/ }),

	/***/ "./node_modules/core-js/modules/esnext.iterator.map.js":
	/*!*************************************************************!*\
	  !*** ./node_modules/core-js/modules/esnext.iterator.map.js ***!
	  \*************************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	// TODO: Remove from `core-js@4`
	__webpack_require__(/*! ../modules/es.iterator.map */ "./node_modules/core-js/modules/es.iterator.map.js");


	/***/ }),

	/***/ "./node_modules/core-js/modules/esnext.set.add-all.js":
	/*!************************************************************!*\
	  !*** ./node_modules/core-js/modules/esnext.set.add-all.js ***!
	  \************************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
	var aSet = __webpack_require__(/*! ../internals/a-set */ "./node_modules/core-js/internals/a-set.js");
	var add = (__webpack_require__(/*! ../internals/set-helpers */ "./node_modules/core-js/internals/set-helpers.js").add);

	// `Set.prototype.addAll` method
	// https://github.com/tc39/proposal-collection-methods
	$({ target: 'Set', proto: true, real: true, forced: true }, {
	  addAll: function addAll(/* ...elements */) {
	    var set = aSet(this);
	    for (var k = 0, len = arguments.length; k < len; k++) {
	      add(set, arguments[k]);
	    } return set;
	  }
	});


	/***/ }),

	/***/ "./node_modules/core-js/modules/esnext.set.delete-all.js":
	/*!***************************************************************!*\
	  !*** ./node_modules/core-js/modules/esnext.set.delete-all.js ***!
	  \***************************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
	var aSet = __webpack_require__(/*! ../internals/a-set */ "./node_modules/core-js/internals/a-set.js");
	var remove = (__webpack_require__(/*! ../internals/set-helpers */ "./node_modules/core-js/internals/set-helpers.js").remove);

	// `Set.prototype.deleteAll` method
	// https://github.com/tc39/proposal-collection-methods
	$({ target: 'Set', proto: true, real: true, forced: true }, {
	  deleteAll: function deleteAll(/* ...elements */) {
	    var collection = aSet(this);
	    var allDeleted = true;
	    var wasDeleted;
	    for (var k = 0, len = arguments.length; k < len; k++) {
	      wasDeleted = remove(collection, arguments[k]);
	      allDeleted = allDeleted && wasDeleted;
	    } return !!allDeleted;
	  }
	});


	/***/ }),

	/***/ "./node_modules/core-js/modules/esnext.set.difference.js":
	/*!***************************************************************!*\
	  !*** ./node_modules/core-js/modules/esnext.set.difference.js ***!
	  \***************************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
	var call = __webpack_require__(/*! ../internals/function-call */ "./node_modules/core-js/internals/function-call.js");
	var toSetLike = __webpack_require__(/*! ../internals/to-set-like */ "./node_modules/core-js/internals/to-set-like.js");
	var $difference = __webpack_require__(/*! ../internals/set-difference */ "./node_modules/core-js/internals/set-difference.js");

	// `Set.prototype.difference` method
	// https://github.com/tc39/proposal-set-methods
	// TODO: Obsolete version, remove from `core-js@4`
	$({ target: 'Set', proto: true, real: true, forced: true }, {
	  difference: function difference(other) {
	    return call($difference, this, toSetLike(other));
	  }
	});


	/***/ }),

	/***/ "./node_modules/core-js/modules/esnext.set.every.js":
	/*!**********************************************************!*\
	  !*** ./node_modules/core-js/modules/esnext.set.every.js ***!
	  \**********************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
	var bind = __webpack_require__(/*! ../internals/function-bind-context */ "./node_modules/core-js/internals/function-bind-context.js");
	var aSet = __webpack_require__(/*! ../internals/a-set */ "./node_modules/core-js/internals/a-set.js");
	var iterate = __webpack_require__(/*! ../internals/set-iterate */ "./node_modules/core-js/internals/set-iterate.js");

	// `Set.prototype.every` method
	// https://github.com/tc39/proposal-collection-methods
	$({ target: 'Set', proto: true, real: true, forced: true }, {
	  every: function every(callbackfn /* , thisArg */) {
	    var set = aSet(this);
	    var boundFunction = bind(callbackfn, arguments.length > 1 ? arguments[1] : undefined);
	    return iterate(set, function (value) {
	      if (!boundFunction(value, value, set)) return false;
	    }, true) !== false;
	  }
	});


	/***/ }),

	/***/ "./node_modules/core-js/modules/esnext.set.filter.js":
	/*!***********************************************************!*\
	  !*** ./node_modules/core-js/modules/esnext.set.filter.js ***!
	  \***********************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
	var bind = __webpack_require__(/*! ../internals/function-bind-context */ "./node_modules/core-js/internals/function-bind-context.js");
	var aSet = __webpack_require__(/*! ../internals/a-set */ "./node_modules/core-js/internals/a-set.js");
	var SetHelpers = __webpack_require__(/*! ../internals/set-helpers */ "./node_modules/core-js/internals/set-helpers.js");
	var iterate = __webpack_require__(/*! ../internals/set-iterate */ "./node_modules/core-js/internals/set-iterate.js");

	var Set = SetHelpers.Set;
	var add = SetHelpers.add;

	// `Set.prototype.filter` method
	// https://github.com/tc39/proposal-collection-methods
	$({ target: 'Set', proto: true, real: true, forced: true }, {
	  filter: function filter(callbackfn /* , thisArg */) {
	    var set = aSet(this);
	    var boundFunction = bind(callbackfn, arguments.length > 1 ? arguments[1] : undefined);
	    var newSet = new Set();
	    iterate(set, function (value) {
	      if (boundFunction(value, value, set)) add(newSet, value);
	    });
	    return newSet;
	  }
	});


	/***/ }),

	/***/ "./node_modules/core-js/modules/esnext.set.find.js":
	/*!*********************************************************!*\
	  !*** ./node_modules/core-js/modules/esnext.set.find.js ***!
	  \*********************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
	var bind = __webpack_require__(/*! ../internals/function-bind-context */ "./node_modules/core-js/internals/function-bind-context.js");
	var aSet = __webpack_require__(/*! ../internals/a-set */ "./node_modules/core-js/internals/a-set.js");
	var iterate = __webpack_require__(/*! ../internals/set-iterate */ "./node_modules/core-js/internals/set-iterate.js");

	// `Set.prototype.find` method
	// https://github.com/tc39/proposal-collection-methods
	$({ target: 'Set', proto: true, real: true, forced: true }, {
	  find: function find(callbackfn /* , thisArg */) {
	    var set = aSet(this);
	    var boundFunction = bind(callbackfn, arguments.length > 1 ? arguments[1] : undefined);
	    var result = iterate(set, function (value) {
	      if (boundFunction(value, value, set)) return { value: value };
	    }, true);
	    return result && result.value;
	  }
	});


	/***/ }),

	/***/ "./node_modules/core-js/modules/esnext.set.intersection.js":
	/*!*****************************************************************!*\
	  !*** ./node_modules/core-js/modules/esnext.set.intersection.js ***!
	  \*****************************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
	var call = __webpack_require__(/*! ../internals/function-call */ "./node_modules/core-js/internals/function-call.js");
	var toSetLike = __webpack_require__(/*! ../internals/to-set-like */ "./node_modules/core-js/internals/to-set-like.js");
	var $intersection = __webpack_require__(/*! ../internals/set-intersection */ "./node_modules/core-js/internals/set-intersection.js");

	// `Set.prototype.intersection` method
	// https://github.com/tc39/proposal-set-methods
	// TODO: Obsolete version, remove from `core-js@4`
	$({ target: 'Set', proto: true, real: true, forced: true }, {
	  intersection: function intersection(other) {
	    return call($intersection, this, toSetLike(other));
	  }
	});


	/***/ }),

	/***/ "./node_modules/core-js/modules/esnext.set.is-disjoint-from.js":
	/*!*********************************************************************!*\
	  !*** ./node_modules/core-js/modules/esnext.set.is-disjoint-from.js ***!
	  \*********************************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
	var call = __webpack_require__(/*! ../internals/function-call */ "./node_modules/core-js/internals/function-call.js");
	var toSetLike = __webpack_require__(/*! ../internals/to-set-like */ "./node_modules/core-js/internals/to-set-like.js");
	var $isDisjointFrom = __webpack_require__(/*! ../internals/set-is-disjoint-from */ "./node_modules/core-js/internals/set-is-disjoint-from.js");

	// `Set.prototype.isDisjointFrom` method
	// https://github.com/tc39/proposal-set-methods
	// TODO: Obsolete version, remove from `core-js@4`
	$({ target: 'Set', proto: true, real: true, forced: true }, {
	  isDisjointFrom: function isDisjointFrom(other) {
	    return call($isDisjointFrom, this, toSetLike(other));
	  }
	});


	/***/ }),

	/***/ "./node_modules/core-js/modules/esnext.set.is-subset-of.js":
	/*!*****************************************************************!*\
	  !*** ./node_modules/core-js/modules/esnext.set.is-subset-of.js ***!
	  \*****************************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
	var call = __webpack_require__(/*! ../internals/function-call */ "./node_modules/core-js/internals/function-call.js");
	var toSetLike = __webpack_require__(/*! ../internals/to-set-like */ "./node_modules/core-js/internals/to-set-like.js");
	var $isSubsetOf = __webpack_require__(/*! ../internals/set-is-subset-of */ "./node_modules/core-js/internals/set-is-subset-of.js");

	// `Set.prototype.isSubsetOf` method
	// https://github.com/tc39/proposal-set-methods
	// TODO: Obsolete version, remove from `core-js@4`
	$({ target: 'Set', proto: true, real: true, forced: true }, {
	  isSubsetOf: function isSubsetOf(other) {
	    return call($isSubsetOf, this, toSetLike(other));
	  }
	});


	/***/ }),

	/***/ "./node_modules/core-js/modules/esnext.set.is-superset-of.js":
	/*!*******************************************************************!*\
	  !*** ./node_modules/core-js/modules/esnext.set.is-superset-of.js ***!
	  \*******************************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
	var call = __webpack_require__(/*! ../internals/function-call */ "./node_modules/core-js/internals/function-call.js");
	var toSetLike = __webpack_require__(/*! ../internals/to-set-like */ "./node_modules/core-js/internals/to-set-like.js");
	var $isSupersetOf = __webpack_require__(/*! ../internals/set-is-superset-of */ "./node_modules/core-js/internals/set-is-superset-of.js");

	// `Set.prototype.isSupersetOf` method
	// https://github.com/tc39/proposal-set-methods
	// TODO: Obsolete version, remove from `core-js@4`
	$({ target: 'Set', proto: true, real: true, forced: true }, {
	  isSupersetOf: function isSupersetOf(other) {
	    return call($isSupersetOf, this, toSetLike(other));
	  }
	});


	/***/ }),

	/***/ "./node_modules/core-js/modules/esnext.set.join.js":
	/*!*********************************************************!*\
	  !*** ./node_modules/core-js/modules/esnext.set.join.js ***!
	  \*********************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
	var uncurryThis = __webpack_require__(/*! ../internals/function-uncurry-this */ "./node_modules/core-js/internals/function-uncurry-this.js");
	var aSet = __webpack_require__(/*! ../internals/a-set */ "./node_modules/core-js/internals/a-set.js");
	var iterate = __webpack_require__(/*! ../internals/set-iterate */ "./node_modules/core-js/internals/set-iterate.js");
	var toString = __webpack_require__(/*! ../internals/to-string */ "./node_modules/core-js/internals/to-string.js");

	var arrayJoin = uncurryThis([].join);
	var push = uncurryThis([].push);

	// `Set.prototype.join` method
	// https://github.com/tc39/proposal-collection-methods
	$({ target: 'Set', proto: true, real: true, forced: true }, {
	  join: function join(separator) {
	    var set = aSet(this);
	    var sep = separator === undefined ? ',' : toString(separator);
	    var array = [];
	    iterate(set, function (value) {
	      push(array, value);
	    });
	    return arrayJoin(array, sep);
	  }
	});


	/***/ }),

	/***/ "./node_modules/core-js/modules/esnext.set.map.js":
	/*!********************************************************!*\
	  !*** ./node_modules/core-js/modules/esnext.set.map.js ***!
	  \********************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
	var bind = __webpack_require__(/*! ../internals/function-bind-context */ "./node_modules/core-js/internals/function-bind-context.js");
	var aSet = __webpack_require__(/*! ../internals/a-set */ "./node_modules/core-js/internals/a-set.js");
	var SetHelpers = __webpack_require__(/*! ../internals/set-helpers */ "./node_modules/core-js/internals/set-helpers.js");
	var iterate = __webpack_require__(/*! ../internals/set-iterate */ "./node_modules/core-js/internals/set-iterate.js");

	var Set = SetHelpers.Set;
	var add = SetHelpers.add;

	// `Set.prototype.map` method
	// https://github.com/tc39/proposal-collection-methods
	$({ target: 'Set', proto: true, real: true, forced: true }, {
	  map: function map(callbackfn /* , thisArg */) {
	    var set = aSet(this);
	    var boundFunction = bind(callbackfn, arguments.length > 1 ? arguments[1] : undefined);
	    var newSet = new Set();
	    iterate(set, function (value) {
	      add(newSet, boundFunction(value, value, set));
	    });
	    return newSet;
	  }
	});


	/***/ }),

	/***/ "./node_modules/core-js/modules/esnext.set.reduce.js":
	/*!***********************************************************!*\
	  !*** ./node_modules/core-js/modules/esnext.set.reduce.js ***!
	  \***********************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
	var aCallable = __webpack_require__(/*! ../internals/a-callable */ "./node_modules/core-js/internals/a-callable.js");
	var aSet = __webpack_require__(/*! ../internals/a-set */ "./node_modules/core-js/internals/a-set.js");
	var iterate = __webpack_require__(/*! ../internals/set-iterate */ "./node_modules/core-js/internals/set-iterate.js");

	var $TypeError = TypeError;

	// `Set.prototype.reduce` method
	// https://github.com/tc39/proposal-collection-methods
	$({ target: 'Set', proto: true, real: true, forced: true }, {
	  reduce: function reduce(callbackfn /* , initialValue */) {
	    var set = aSet(this);
	    var noInitial = arguments.length < 2;
	    var accumulator = noInitial ? undefined : arguments[1];
	    aCallable(callbackfn);
	    iterate(set, function (value) {
	      if (noInitial) {
	        noInitial = false;
	        accumulator = value;
	      } else {
	        accumulator = callbackfn(accumulator, value, value, set);
	      }
	    });
	    if (noInitial) throw new $TypeError('Reduce of empty set with no initial value');
	    return accumulator;
	  }
	});


	/***/ }),

	/***/ "./node_modules/core-js/modules/esnext.set.some.js":
	/*!*********************************************************!*\
	  !*** ./node_modules/core-js/modules/esnext.set.some.js ***!
	  \*********************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
	var bind = __webpack_require__(/*! ../internals/function-bind-context */ "./node_modules/core-js/internals/function-bind-context.js");
	var aSet = __webpack_require__(/*! ../internals/a-set */ "./node_modules/core-js/internals/a-set.js");
	var iterate = __webpack_require__(/*! ../internals/set-iterate */ "./node_modules/core-js/internals/set-iterate.js");

	// `Set.prototype.some` method
	// https://github.com/tc39/proposal-collection-methods
	$({ target: 'Set', proto: true, real: true, forced: true }, {
	  some: function some(callbackfn /* , thisArg */) {
	    var set = aSet(this);
	    var boundFunction = bind(callbackfn, arguments.length > 1 ? arguments[1] : undefined);
	    return iterate(set, function (value) {
	      if (boundFunction(value, value, set)) return true;
	    }, true) === true;
	  }
	});


	/***/ }),

	/***/ "./node_modules/core-js/modules/esnext.set.symmetric-difference.js":
	/*!*************************************************************************!*\
	  !*** ./node_modules/core-js/modules/esnext.set.symmetric-difference.js ***!
	  \*************************************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
	var call = __webpack_require__(/*! ../internals/function-call */ "./node_modules/core-js/internals/function-call.js");
	var toSetLike = __webpack_require__(/*! ../internals/to-set-like */ "./node_modules/core-js/internals/to-set-like.js");
	var $symmetricDifference = __webpack_require__(/*! ../internals/set-symmetric-difference */ "./node_modules/core-js/internals/set-symmetric-difference.js");

	// `Set.prototype.symmetricDifference` method
	// https://github.com/tc39/proposal-set-methods
	// TODO: Obsolete version, remove from `core-js@4`
	$({ target: 'Set', proto: true, real: true, forced: true }, {
	  symmetricDifference: function symmetricDifference(other) {
	    return call($symmetricDifference, this, toSetLike(other));
	  }
	});


	/***/ }),

	/***/ "./node_modules/core-js/modules/esnext.set.union.js":
	/*!**********************************************************!*\
	  !*** ./node_modules/core-js/modules/esnext.set.union.js ***!
	  \**********************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
	var call = __webpack_require__(/*! ../internals/function-call */ "./node_modules/core-js/internals/function-call.js");
	var toSetLike = __webpack_require__(/*! ../internals/to-set-like */ "./node_modules/core-js/internals/to-set-like.js");
	var $union = __webpack_require__(/*! ../internals/set-union */ "./node_modules/core-js/internals/set-union.js");

	// `Set.prototype.union` method
	// https://github.com/tc39/proposal-set-methods
	// TODO: Obsolete version, remove from `core-js@4`
	$({ target: 'Set', proto: true, real: true, forced: true }, {
	  union: function union(other) {
	    return call($union, this, toSetLike(other));
	  }
	});


	/***/ }),

	/***/ "./node_modules/core-js/modules/web.dom-collections.for-each.js":
	/*!**********************************************************************!*\
	  !*** ./node_modules/core-js/modules/web.dom-collections.for-each.js ***!
	  \**********************************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/core-js/internals/global-this.js");
	var DOMIterables = __webpack_require__(/*! ../internals/dom-iterables */ "./node_modules/core-js/internals/dom-iterables.js");
	var DOMTokenListPrototype = __webpack_require__(/*! ../internals/dom-token-list-prototype */ "./node_modules/core-js/internals/dom-token-list-prototype.js");
	var forEach = __webpack_require__(/*! ../internals/array-for-each */ "./node_modules/core-js/internals/array-for-each.js");
	var createNonEnumerableProperty = __webpack_require__(/*! ../internals/create-non-enumerable-property */ "./node_modules/core-js/internals/create-non-enumerable-property.js");

	var handlePrototype = function (CollectionPrototype) {
	  // some Chrome versions have non-configurable methods on DOMTokenList
	  if (CollectionPrototype && CollectionPrototype.forEach !== forEach) try {
	    createNonEnumerableProperty(CollectionPrototype, 'forEach', forEach);
	  } catch (error) {
	    CollectionPrototype.forEach = forEach;
	  }
	};

	for (var COLLECTION_NAME in DOMIterables) {
	  if (DOMIterables[COLLECTION_NAME]) {
	    handlePrototype(globalThis[COLLECTION_NAME] && globalThis[COLLECTION_NAME].prototype);
	  }
	}

	handlePrototype(DOMTokenListPrototype);


	/***/ }),

	/***/ "./node_modules/core-js/modules/web.dom-collections.iterator.js":
	/*!**********************************************************************!*\
	  !*** ./node_modules/core-js/modules/web.dom-collections.iterator.js ***!
	  \**********************************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/core-js/internals/global-this.js");
	var DOMIterables = __webpack_require__(/*! ../internals/dom-iterables */ "./node_modules/core-js/internals/dom-iterables.js");
	var DOMTokenListPrototype = __webpack_require__(/*! ../internals/dom-token-list-prototype */ "./node_modules/core-js/internals/dom-token-list-prototype.js");
	var ArrayIteratorMethods = __webpack_require__(/*! ../modules/es.array.iterator */ "./node_modules/core-js/modules/es.array.iterator.js");
	var createNonEnumerableProperty = __webpack_require__(/*! ../internals/create-non-enumerable-property */ "./node_modules/core-js/internals/create-non-enumerable-property.js");
	var setToStringTag = __webpack_require__(/*! ../internals/set-to-string-tag */ "./node_modules/core-js/internals/set-to-string-tag.js");
	var wellKnownSymbol = __webpack_require__(/*! ../internals/well-known-symbol */ "./node_modules/core-js/internals/well-known-symbol.js");

	var ITERATOR = wellKnownSymbol('iterator');
	var ArrayValues = ArrayIteratorMethods.values;

	var handlePrototype = function (CollectionPrototype, COLLECTION_NAME) {
	  if (CollectionPrototype) {
	    // some Chrome versions have non-configurable methods on DOMTokenList
	    if (CollectionPrototype[ITERATOR] !== ArrayValues) try {
	      createNonEnumerableProperty(CollectionPrototype, ITERATOR, ArrayValues);
	    } catch (error) {
	      CollectionPrototype[ITERATOR] = ArrayValues;
	    }
	    setToStringTag(CollectionPrototype, COLLECTION_NAME, true);
	    if (DOMIterables[COLLECTION_NAME]) for (var METHOD_NAME in ArrayIteratorMethods) {
	      // some Chrome versions have non-configurable methods on DOMTokenList
	      if (CollectionPrototype[METHOD_NAME] !== ArrayIteratorMethods[METHOD_NAME]) try {
	        createNonEnumerableProperty(CollectionPrototype, METHOD_NAME, ArrayIteratorMethods[METHOD_NAME]);
	      } catch (error) {
	        CollectionPrototype[METHOD_NAME] = ArrayIteratorMethods[METHOD_NAME];
	      }
	    }
	  }
	};

	for (var COLLECTION_NAME in DOMIterables) {
	  handlePrototype(globalThis[COLLECTION_NAME] && globalThis[COLLECTION_NAME].prototype, COLLECTION_NAME);
	}

	handlePrototype(DOMTokenListPrototype, 'DOMTokenList');


	/***/ }),

	/***/ "./node_modules/core-js/modules/web.set-interval.js":
	/*!**********************************************************!*\
	  !*** ./node_modules/core-js/modules/web.set-interval.js ***!
	  \**********************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
	var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/core-js/internals/global-this.js");
	var schedulersFix = __webpack_require__(/*! ../internals/schedulers-fix */ "./node_modules/core-js/internals/schedulers-fix.js");

	var setInterval = schedulersFix(globalThis.setInterval, true);

	// Bun / IE9- setInterval additional parameters fix
	// https://html.spec.whatwg.org/multipage/timers-and-user-prompts.html#dom-setinterval
	$({ global: true, bind: true, forced: globalThis.setInterval !== setInterval }, {
	  setInterval: setInterval
	});


	/***/ }),

	/***/ "./node_modules/core-js/modules/web.set-timeout.js":
	/*!*********************************************************!*\
	  !*** ./node_modules/core-js/modules/web.set-timeout.js ***!
	  \*********************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	var $ = __webpack_require__(/*! ../internals/export */ "./node_modules/core-js/internals/export.js");
	var globalThis = __webpack_require__(/*! ../internals/global-this */ "./node_modules/core-js/internals/global-this.js");
	var schedulersFix = __webpack_require__(/*! ../internals/schedulers-fix */ "./node_modules/core-js/internals/schedulers-fix.js");

	var setTimeout = schedulersFix(globalThis.setTimeout, true);

	// Bun / IE9- setTimeout additional parameters fix
	// https://html.spec.whatwg.org/multipage/timers-and-user-prompts.html#dom-settimeout
	$({ global: true, bind: true, forced: globalThis.setTimeout !== setTimeout }, {
	  setTimeout: setTimeout
	});


	/***/ }),

	/***/ "./node_modules/core-js/modules/web.timers.js":
	/*!****************************************************!*\
	  !*** ./node_modules/core-js/modules/web.timers.js ***!
	  \****************************************************/
	/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {


	// TODO: Remove this module from `core-js@4` since it's split to modules listed below
	__webpack_require__(/*! ../modules/web.set-interval */ "./node_modules/core-js/modules/web.set-interval.js");
	__webpack_require__(/*! ../modules/web.set-timeout */ "./node_modules/core-js/modules/web.set-timeout.js");


	/***/ }),

	/***/ "./src/plugin/hyperlinks.js":
	/*!**********************************!*\
	  !*** ./src/plugin/hyperlinks.js ***!
	  \**********************************/
	/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

	__webpack_require__.r(__webpack_exports__);
	/* harmony import */ __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/es.string.link.js */ "./node_modules/core-js/modules/es.string.link.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/esnext.iterator.constructor.js */ "./node_modules/core-js/modules/esnext.iterator.constructor.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/esnext.iterator.for-each.js */ "./node_modules/core-js/modules/esnext.iterator.for-each.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
	/* harmony import */ var _worker_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../worker.js */ "./src/worker.js");
	/* harmony import */ var _utils_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../utils.js */ "./src/utils.js");








	// Add hyperlink functionality to the PDF creation.

	// Main link array, and refs to original functions.
	var linkInfo = [];
	var orig = {
	  toContainer: _worker_js__WEBPACK_IMPORTED_MODULE_5__["default"].prototype.toContainer,
	  toPdf: _worker_js__WEBPACK_IMPORTED_MODULE_5__["default"].prototype.toPdf
	};
	_worker_js__WEBPACK_IMPORTED_MODULE_5__["default"].prototype.toContainer = function toContainer() {
	  return orig.toContainer.call(this).then(function toContainer_hyperlink() {
	    // Retrieve hyperlink info if the option is enabled.
	    if (this.opt.enableLinks) {
	      // Find all anchor tags and get the container's bounds for reference.
	      var container = this.prop.container;
	      var links = container.querySelectorAll('a');
	      var containerRect = (0, _utils_js__WEBPACK_IMPORTED_MODULE_6__.unitConvert)(container.getBoundingClientRect(), this.prop.pageSize.k);
	      linkInfo = [];

	      // Loop through each anchor tag.
	      Array.prototype.forEach.call(links, function (link) {
	        // Treat each client rect as a separate link (for text-wrapping).
	        var clientRects = link.getClientRects();
	        for (var i = 0; i < clientRects.length; i++) {
	          var clientRect = (0, _utils_js__WEBPACK_IMPORTED_MODULE_6__.unitConvert)(clientRects[i], this.prop.pageSize.k);
	          clientRect.left -= containerRect.left;
	          clientRect.top -= containerRect.top;
	          var page = Math.floor(clientRect.top / this.prop.pageSize.inner.height) + 1;
	          var top = this.opt.margin[0] + clientRect.top % this.prop.pageSize.inner.height;
	          var left = this.opt.margin[1] + clientRect.left;
	          linkInfo.push({
	            page: page,
	            top: top,
	            left: left,
	            clientRect: clientRect,
	            link: link
	          });
	        }
	      }, this);
	    }
	  });
	};
	_worker_js__WEBPACK_IMPORTED_MODULE_5__["default"].prototype.toPdf = function toPdf() {
	  return orig.toPdf.call(this).then(function toPdf_hyperlink() {
	    // Add hyperlinks if the option is enabled.
	    if (this.opt.enableLinks) {
	      // Attach each anchor tag based on info from toContainer().
	      linkInfo.forEach(function (l) {
	        this.prop.pdf.setPage(l.page);
	        this.prop.pdf.link(l.left, l.top, l.clientRect.width, l.clientRect.height, {
	          url: l.link.href
	        });
	      }, this);

	      // Reset the active page of the PDF to the final page.
	      var nPages = this.prop.pdf.internal.getNumberOfPages();
	      this.prop.pdf.setPage(nPages);
	    }
	  });
	};

	/***/ }),

	/***/ "./src/plugin/jspdf-plugin.js":
	/*!************************************!*\
	  !*** ./src/plugin/jspdf-plugin.js ***!
	  \************************************/
	/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

	__webpack_require__.r(__webpack_exports__);
	/* harmony import */ __webpack_require__(/*! core-js/modules/es.symbol.js */ "./node_modules/core-js/modules/es.symbol.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/es.symbol.description.js */ "./node_modules/core-js/modules/es.symbol.description.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/es.symbol.iterator.js */ "./node_modules/core-js/modules/es.symbol.iterator.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/es.array.iterator.js */ "./node_modules/core-js/modules/es.array.iterator.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
	/* harmony import */ var jspdf__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! jspdf */ "jspdf");







	function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
	// Import dependencies.


	// Get dimensions of a PDF page, as determined by jsPDF.
	jspdf__WEBPACK_IMPORTED_MODULE_7__.jsPDF.getPageSize = function (orientation, unit, format) {
	  // Decode options object
	  if (_typeof(orientation) === 'object') {
	    var options = orientation;
	    orientation = options.orientation;
	    unit = options.unit || unit;
	    format = options.format || format;
	  }

	  // Default options
	  unit = unit || 'mm';
	  format = format || 'a4';
	  orientation = ('' + (orientation || 'P')).toLowerCase();
	  var format_as_string = ('' + format).toLowerCase();

	  // Size in pt of various paper formats
	  var pageFormats = {
	    'a0': [2383.94, 3370.39],
	    'a1': [1683.78, 2383.94],
	    'a2': [1190.55, 1683.78],
	    'a3': [841.89, 1190.55],
	    'a4': [595.28, 841.89],
	    'a5': [419.53, 595.28],
	    'a6': [297.64, 419.53],
	    'a7': [209.76, 297.64],
	    'a8': [147.40, 209.76],
	    'a9': [104.88, 147.40],
	    'a10': [73.70, 104.88],
	    'b0': [2834.65, 4008.19],
	    'b1': [2004.09, 2834.65],
	    'b2': [1417.32, 2004.09],
	    'b3': [1000.63, 1417.32],
	    'b4': [708.66, 1000.63],
	    'b5': [498.90, 708.66],
	    'b6': [354.33, 498.90],
	    'b7': [249.45, 354.33],
	    'b8': [175.75, 249.45],
	    'b9': [124.72, 175.75],
	    'b10': [87.87, 124.72],
	    'c0': [2599.37, 3676.54],
	    'c1': [1836.85, 2599.37],
	    'c2': [1298.27, 1836.85],
	    'c3': [918.43, 1298.27],
	    'c4': [649.13, 918.43],
	    'c5': [459.21, 649.13],
	    'c6': [323.15, 459.21],
	    'c7': [229.61, 323.15],
	    'c8': [161.57, 229.61],
	    'c9': [113.39, 161.57],
	    'c10': [79.37, 113.39],
	    'dl': [311.81, 623.62],
	    'letter': [612, 792],
	    'government-letter': [576, 756],
	    'legal': [612, 1008],
	    'junior-legal': [576, 360],
	    'ledger': [1224, 792],
	    'tabloid': [792, 1224],
	    'credit-card': [153, 243]
	  };

	  // Unit conversion
	  switch (unit) {
	    case 'pt':
	      var k = 1;
	      break;
	    case 'mm':
	      var k = 72 / 25.4;
	      break;
	    case 'cm':
	      var k = 72 / 2.54;
	      break;
	    case 'in':
	      var k = 72;
	      break;
	    case 'px':
	      var k = 72 / 96;
	      break;
	    case 'pc':
	      var k = 12;
	      break;
	    case 'em':
	      var k = 12;
	      break;
	    case 'ex':
	      var k = 6;
	      break;
	    default:
	      throw 'Invalid unit: ' + unit;
	  }

	  // Dimensions are stored as user units and converted to points on output
	  if (pageFormats.hasOwnProperty(format_as_string)) {
	    var pageHeight = pageFormats[format_as_string][1] / k;
	    var pageWidth = pageFormats[format_as_string][0] / k;
	  } else {
	    try {
	      var pageHeight = format[1];
	      var pageWidth = format[0];
	    } catch (err) {
	      throw new Error('Invalid format: ' + format);
	    }
	  }

	  // Handle page orientation
	  if (orientation === 'p' || orientation === 'portrait') {
	    orientation = 'p';
	    if (pageWidth > pageHeight) {
	      var tmp = pageWidth;
	      pageWidth = pageHeight;
	      pageHeight = tmp;
	    }
	  } else if (orientation === 'l' || orientation === 'landscape') {
	    orientation = 'l';
	    if (pageHeight > pageWidth) {
	      var tmp = pageWidth;
	      pageWidth = pageHeight;
	      pageHeight = tmp;
	    }
	  } else {
	    throw 'Invalid orientation: ' + orientation;
	  }

	  // Return information (k is the unit conversion ratio from pts)
	  var info = {
	    'width': pageWidth,
	    'height': pageHeight,
	    'unit': unit,
	    'k': k
	  };
	  return info;
	};
	/* harmony default export */ __webpack_exports__["default"] = (jspdf__WEBPACK_IMPORTED_MODULE_7__.jsPDF);

	/***/ }),

	/***/ "./src/plugin/pagebreaks.js":
	/*!**********************************!*\
	  !*** ./src/plugin/pagebreaks.js ***!
	  \**********************************/
	/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

	__webpack_require__.r(__webpack_exports__);
	/* harmony import */ __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/es.array.join.js */ "./node_modules/core-js/modules/es.array.join.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/es.object.keys.js */ "./node_modules/core-js/modules/es.object.keys.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/esnext.iterator.constructor.js */ "./node_modules/core-js/modules/esnext.iterator.constructor.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/esnext.iterator.for-each.js */ "./node_modules/core-js/modules/esnext.iterator.for-each.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
	/* harmony import */ var _worker_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../worker.js */ "./src/worker.js");
	/* harmony import */ var _utils_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../utils.js */ "./src/utils.js");











	/* Pagebreak plugin:

	    Adds page-break functionality to the html2pdf library. Page-breaks can be
	    enabled by CSS styles, set on individual elements using selectors, or
	    avoided from breaking inside all elements.

	    Options on the `opt.pagebreak` object:

	    mode:   String or array of strings: 'avoid-all', 'css', and/or 'legacy'
	            Default: ['css', 'legacy']

	    before: String or array of CSS selectors for which to add page-breaks
	            before each element. Can be a specific element with an ID
	            ('#myID'), all elements of a type (e.g. 'img'), all of a class
	            ('.myClass'), or even '*' to match every element.

	    after:  Like 'before', but adds a page-break immediately after the element.

	    avoid:  Like 'before', but avoids page-breaks on these elements. You can
	            enable this feature on every element using the 'avoid-all' mode.
	*/

	// Refs to original functions.
	var orig = {
	  toContainer: _worker_js__WEBPACK_IMPORTED_MODULE_8__["default"].prototype.toContainer
	};

	// Add pagebreak default options to the Worker template.
	_worker_js__WEBPACK_IMPORTED_MODULE_8__["default"].template.opt.pagebreak = {
	  mode: ['css', 'legacy'],
	  before: [],
	  after: [],
	  avoid: []
	};
	_worker_js__WEBPACK_IMPORTED_MODULE_8__["default"].prototype.toContainer = function toContainer() {
	  return orig.toContainer.call(this).then(function toContainer_pagebreak() {
	    // Setup root element and inner page height.
	    var root = this.prop.container;
	    var pxPageHeight = this.prop.pageSize.inner.px.height;

	    // Check all requested modes.
	    var modeSrc = [].concat(this.opt.pagebreak.mode);
	    var mode = {
	      avoidAll: modeSrc.indexOf('avoid-all') !== -1,
	      css: modeSrc.indexOf('css') !== -1,
	      legacy: modeSrc.indexOf('legacy') !== -1
	    };

	    // Get arrays of all explicitly requested elements.
	    var select = {};
	    var self = this;
	    ['before', 'after', 'avoid'].forEach(function (key) {
	      var all = mode.avoidAll && key === 'avoid';
	      select[key] = all ? [] : [].concat(self.opt.pagebreak[key] || []);
	      if (select[key].length > 0) {
	        select[key] = Array.prototype.slice.call(root.querySelectorAll(select[key].join(', ')));
	      }
	    });

	    // Get all legacy page-break elements.
	    var legacyEls = root.querySelectorAll('.html2pdf__page-break');
	    legacyEls = Array.prototype.slice.call(legacyEls);

	    // Loop through all elements.
	    var els = root.querySelectorAll('*');
	    Array.prototype.forEach.call(els, function pagebreak_loop(el) {
	      // Setup pagebreak rules based on legacy and avoidAll modes.
	      var rules = {
	        before: false,
	        after: mode.legacy && legacyEls.indexOf(el) !== -1,
	        avoid: mode.avoidAll
	      };

	      // Add rules for css mode.
	      if (mode.css) {
	        // TODO: Check if this is valid with iFrames.
	        var style = window.getComputedStyle(el);
	        // TODO: Handle 'left' and 'right' correctly.
	        // TODO: Add support for 'avoid' on breakBefore/After.
	        var breakOpt = ['always', 'page', 'left', 'right'];
	        var avoidOpt = ['avoid', 'avoid-page'];
	        rules = {
	          before: rules.before || breakOpt.indexOf(style.breakBefore || style.pageBreakBefore) !== -1,
	          after: rules.after || breakOpt.indexOf(style.breakAfter || style.pageBreakAfter) !== -1,
	          avoid: rules.avoid || avoidOpt.indexOf(style.breakInside || style.pageBreakInside) !== -1
	        };
	      }

	      // Add rules for explicit requests.
	      Object.keys(rules).forEach(function (key) {
	        rules[key] = rules[key] || select[key].indexOf(el) !== -1;
	      });

	      // Get element position on the screen.
	      // TODO: Subtract the top of the container from clientRect.top/bottom?
	      var clientRect = el.getBoundingClientRect();

	      // Avoid: Check if a break happens mid-element.
	      if (rules.avoid && !rules.before) {
	        var startPage = Math.floor(clientRect.top / pxPageHeight);
	        var endPage = Math.floor(clientRect.bottom / pxPageHeight);
	        var nPages = Math.abs(clientRect.bottom - clientRect.top) / pxPageHeight;

	        // Turn on rules.before if the el is broken and is at most one page long.
	        if (endPage !== startPage && nPages <= 1) {
	          rules.before = true;
	        }
	      }

	      // Before: Create a padding div to push the element to the next page.
	      if (rules.before) {
	        var pad = (0, _utils_js__WEBPACK_IMPORTED_MODULE_9__.createElement)('div', {
	          style: {
	            display: 'block',
	            height: pxPageHeight - clientRect.top % pxPageHeight + 'px'
	          }
	        });
	        el.parentNode.insertBefore(pad, el);
	      }

	      // After: Create a padding div to fill the remaining page.
	      if (rules.after) {
	        var pad = (0, _utils_js__WEBPACK_IMPORTED_MODULE_9__.createElement)('div', {
	          style: {
	            display: 'block',
	            height: pxPageHeight - clientRect.bottom % pxPageHeight + 'px'
	          }
	        });
	        el.parentNode.insertBefore(pad, el.nextSibling);
	      }
	    });
	  });
	};

	/***/ }),

	/***/ "./src/snapdom/clone.js":
	/*!******************************!*\
	  !*** ./src/snapdom/clone.js ***!
	  \******************************/
	/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

	__webpack_require__.r(__webpack_exports__);
	/* harmony export */ __webpack_require__.d(__webpack_exports__, {
	/* harmony export */   deepCloneBasic: function() { return /* binding */ deepCloneBasic; }
	/* harmony export */ });
	/* harmony import */ __webpack_require__(/*! core-js/modules/es.symbol.js */ "./node_modules/core-js/modules/es.symbol.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/es.symbol.description.js */ "./node_modules/core-js/modules/es.symbol.description.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/es.symbol.iterator.js */ "./node_modules/core-js/modules/es.symbol.iterator.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/es.array.from.js */ "./node_modules/core-js/modules/es.array.from.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/es.array.iterator.js */ "./node_modules/core-js/modules/es.array.iterator.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/es.array.slice.js */ "./node_modules/core-js/modules/es.array.slice.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/es.regexp.exec.js */ "./node_modules/core-js/modules/es.regexp.exec.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/es.regexp.test.js */ "./node_modules/core-js/modules/es.regexp.test.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/es.regexp.to-string.js */ "./node_modules/core-js/modules/es.regexp.to-string.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/es.set.js */ "./node_modules/core-js/modules/es.set.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/esnext.set.add-all.js */ "./node_modules/core-js/modules/esnext.set.add-all.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/esnext.set.delete-all.js */ "./node_modules/core-js/modules/esnext.set.delete-all.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/esnext.set.difference.js */ "./node_modules/core-js/modules/esnext.set.difference.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/esnext.set.every.js */ "./node_modules/core-js/modules/esnext.set.every.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/esnext.set.filter.js */ "./node_modules/core-js/modules/esnext.set.filter.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/esnext.set.find.js */ "./node_modules/core-js/modules/esnext.set.find.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/esnext.set.intersection.js */ "./node_modules/core-js/modules/esnext.set.intersection.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/esnext.set.is-disjoint-from.js */ "./node_modules/core-js/modules/esnext.set.is-disjoint-from.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/esnext.set.is-subset-of.js */ "./node_modules/core-js/modules/esnext.set.is-subset-of.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/esnext.set.is-superset-of.js */ "./node_modules/core-js/modules/esnext.set.is-superset-of.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/esnext.set.join.js */ "./node_modules/core-js/modules/esnext.set.join.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/esnext.set.map.js */ "./node_modules/core-js/modules/esnext.set.map.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/esnext.set.reduce.js */ "./node_modules/core-js/modules/esnext.set.reduce.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/esnext.set.some.js */ "./node_modules/core-js/modules/esnext.set.some.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/esnext.set.symmetric-difference.js */ "./node_modules/core-js/modules/esnext.set.symmetric-difference.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/esnext.set.union.js */ "./node_modules/core-js/modules/esnext.set.union.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");
	function _createForOfIteratorHelper(r, e) { var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (!t) { if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e) { t && (r = t); var _n = 0, F = function F() {}; return { s: F, n: function n() { return _n >= r.length ? { done: true } : { done: false, value: r[_n++] }; }, e: function e(r) { throw r; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var o, a = true, u = false; return { s: function s() { t = t.call(r); }, n: function n() { var r = t.next(); return a = r.done, r; }, e: function e(r) { u = true, o = r; }, f: function f() { try { a || null == t.return || t.return(); } finally { if (u) throw o; } } }; }
	function _unsupportedIterableToArray(r, a) { if (r) { if ("string" == typeof r) return _arrayLikeToArray(r, a); var t = {}.toString.call(r).slice(8, -1); return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0; } }
	function _arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }































	// https://github.com/zumerlab/snapdom
	//
	// MIT License
	//
	// Copyright (c) 2025 ZumerLab
	//
	// Permission is hereby granted, free of charge, to any person obtaining a copy
	// of this software and associated documentation files (the "Software"), to deal
	// in the Software without restriction, including without limitation the rights
	// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
	// copies of the Software, and to permit persons to whom the Software is
	// furnished to do so, subject to the following conditions:
	//
	// The above copyright notice and this permission notice shall be included in all
	// copies or substantial portions of the Software.
	//
	// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
	// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
	// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
	// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
	// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
	// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
	// SOFTWARE.

	/**
	 * Deep cloning utilities for DOM elements, including styles and shadow DOM.
	 * @module clone
	 */

	/**
	 * Freeze the responsive selection of an <img> that has srcset/sizes.
	 * Copies a concrete URL into `src` and removes `srcset`/`sizes` so the clone
	 * doesn't need layout to resolve a candidate.
	 * Works with <picture> because currentSrc reflects the chosen source.
	 * @param {HTMLImageElement} original - Image in the live DOM.
	 * @param {HTMLImageElement} cloned - Just-created cloned <img>.
	 */
	function freezeImgSrcset(original, cloned) {
	  try {
	    var chosen = original.currentSrc || original.src || '';
	    if (!chosen) return;
	    cloned.setAttribute('src', chosen);
	    cloned.removeAttribute('srcset');
	    cloned.removeAttribute('sizes');
	    // Hint deterministic decode/load for capture
	    cloned.loading = 'eager';
	    cloned.decoding = 'sync';
	  } catch (_unused) {
	    // no-op
	  }
	}

	/**
	 * Creates a deep clone of a DOM node, including styles, shadow DOM, and special handling for excluded/placeholder/canvas nodes.
	 *
	 * @param {Node} node - Node to clone
	 * @returns {Node|null} Cloned node with styles and shadow DOM content, or null for empty text nodes or filtered elements
	 */

	function deepCloneBasic(node) {
	  if (!node) throw new Error('Invalid node');

	  // Local set to avoid duplicates in slot processing
	  var clonedAssignedNodes = new Set();
	  var pendingSelectValue = null; // Track select value for later fix

	  // 1. Text nodes
	  if (node.nodeType === Node.TEXT_NODE) {
	    return node.cloneNode(true);
	  }

	  // 2. Non-element nodes (comments, etc.)
	  if (node.nodeType !== Node.ELEMENT_NODE) {
	    return node.cloneNode(true);
	  }

	  // 6. Special case: iframe → fallback pattern
	  if (node.tagName === "IFRAME") {
	    var fallback = document.createElement("div");
	    fallback.style.cssText = "width:".concat(node.offsetWidth, "px;height:").concat(node.offsetHeight, "px;background-image:repeating-linear-gradient(45deg,#ddd,#ddd 5px,#f9f9f9 5px,#f9f9f9 10px);display:flex;align-items:center;justify-content:center;font-size:12px;color:#555;border:1px solid #aaa;");
	    return fallback;
	  }

	  // 8. Canvas → convert to image
	  if (node.tagName === "CANVAS") {
	    var dataURL = node.toDataURL();
	    var img = document.createElement("img");
	    img.src = dataURL;
	    img.width = node.width;
	    img.height = node.height;
	    return img;
	  }

	  // 9. Base clone (without children)
	  var clone;
	  try {
	    clone = node.cloneNode(false);
	    if (node.tagName === 'IMG') {
	      freezeImgSrcset(node, clone);
	    }
	  } catch (err) {
	    console.error("[Snapdom] Failed to clone node:", node, err);
	    throw err;
	  }

	  // Special handling: textarea (keep size and value)
	  if (node instanceof HTMLTextAreaElement) {
	    clone.textContent = node.value;
	    clone.value = node.value;
	    var rect = node.getBoundingClientRect();
	    clone.style.boxSizing = 'border-box';
	    clone.style.width = "".concat(rect.width, "px");
	    clone.style.height = "".concat(rect.height, "px");
	    return clone;
	  }

	  // Special handling: input
	  if (node instanceof HTMLInputElement) {
	    if (node.hasAttribute("value")) {
	      clone.value = node.value;
	      clone.setAttribute("value", node.value);
	    }
	    if (node.checked !== void 0) {
	      clone.checked = node.checked;
	      if (node.checked) clone.setAttribute("checked", "");
	      if (node.indeterminate) clone.indeterminate = node.indeterminate;
	    }
	    // return clone;
	  }

	  // Special handling: select → postpone value adjustment
	  if (node instanceof HTMLSelectElement) {
	    pendingSelectValue = node.value;
	  }

	  // 12. ShadowRoot logic
	  if (node.shadowRoot) {
	    var hasSlot = Array.from(node.shadowRoot.querySelectorAll("slot")).length > 0;
	    if (hasSlot) ; else {
	      // ShadowRoot without slots: clone full content
	      var shadowFrag = document.createDocumentFragment();
	      var _iterator = _createForOfIteratorHelper(node.shadowRoot.childNodes),
	        _step;
	      try {
	        for (_iterator.s(); !(_step = _iterator.n()).done;) {
	          var child = _step.value;
	          if (child.nodeType === Node.ELEMENT_NODE && child.tagName === "STYLE") {
	            continue;
	          }
	          var clonedChild = deepCloneBasic(child);
	          if (clonedChild) shadowFrag.appendChild(clonedChild);
	        }
	      } catch (err) {
	        _iterator.e(err);
	      } finally {
	        _iterator.f();
	      }
	      clone.appendChild(shadowFrag);
	    }
	  }

	  // 13. Slot outside ShadowRoot
	  if (node.tagName === "SLOT") {
	    var _node$assignedNodes;
	    var assigned = ((_node$assignedNodes = node.assignedNodes) === null || _node$assignedNodes === void 0 ? void 0 : _node$assignedNodes.call(node, {
	      flatten: true
	    })) || [];
	    var nodesToClone = assigned.length > 0 ? assigned : Array.from(node.childNodes);
	    var fragment = document.createDocumentFragment();
	    var _iterator2 = _createForOfIteratorHelper(nodesToClone),
	      _step2;
	    try {
	      for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
	        var _child = _step2.value;
	        var _clonedChild = deepCloneBasic(_child);
	        if (_clonedChild) fragment.appendChild(_clonedChild);
	      }
	    } catch (err) {
	      _iterator2.e(err);
	    } finally {
	      _iterator2.f();
	    }
	    return fragment;
	  }

	  // 14. Clone children (light DOM), skipping duplicates
	  var _iterator3 = _createForOfIteratorHelper(node.childNodes),
	    _step3;
	  try {
	    for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) {
	      var _child2 = _step3.value;
	      if (clonedAssignedNodes.has(_child2)) continue;
	      var _clonedChild2 = deepCloneBasic(_child2);
	      if (_clonedChild2) clone.appendChild(_clonedChild2);
	    }

	    // Adjust select value after children are cloned
	  } catch (err) {
	    _iterator3.e(err);
	  } finally {
	    _iterator3.f();
	  }
	  if (pendingSelectValue !== null && clone instanceof HTMLSelectElement) {
	    clone.value = pendingSelectValue;
	    var _iterator4 = _createForOfIteratorHelper(clone.options),
	      _step4;
	    try {
	      for (_iterator4.s(); !(_step4 = _iterator4.n()).done;) {
	        var opt = _step4.value;
	        if (opt.value === pendingSelectValue) {
	          opt.setAttribute("selected", "");
	        } else {
	          opt.removeAttribute("selected");
	        }
	      }
	    } catch (err) {
	      _iterator4.e(err);
	    } finally {
	      _iterator4.f();
	    }
	  }

	  // Fix scrolling (taken from prepareClone).
	  var scrollX = node.scrollLeft;
	  var scrollY = node.scrollTop;
	  var hasScroll = scrollX || scrollY;
	  if (hasScroll && clone instanceof HTMLElement) {
	    clone.style.overflow = "hidden";
	    clone.style.scrollbarWidth = "none";
	    clone.style.msOverflowStyle = "none";
	    var inner = document.createElement("div");
	    inner.style.transform = "translate(".concat(-scrollX, "px, ").concat(-scrollY, "px)");
	    inner.style.willChange = "transform";
	    inner.style.display = "inline-block";
	    inner.style.width = "100%";
	    while (clone.firstChild) {
	      inner.appendChild(clone.firstChild);
	    }
	    clone.appendChild(inner);
	  }
	  return clone;
	}

	/***/ }),

	/***/ "./src/utils.js":
	/*!**********************!*\
	  !*** ./src/utils.js ***!
	  \**********************/
	/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

	__webpack_require__.r(__webpack_exports__);
	/* harmony export */ __webpack_require__.d(__webpack_exports__, {
	/* harmony export */   createElement: function() { return /* binding */ createElement; },
	/* harmony export */   objType: function() { return /* binding */ objType; },
	/* harmony export */   toPx: function() { return /* binding */ toPx; },
	/* harmony export */   unitConvert: function() { return /* binding */ unitConvert; }
	/* harmony export */ });
	/* harmony import */ __webpack_require__(/*! core-js/modules/es.symbol.js */ "./node_modules/core-js/modules/es.symbol.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/es.symbol.description.js */ "./node_modules/core-js/modules/es.symbol.description.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/es.symbol.iterator.js */ "./node_modules/core-js/modules/es.symbol.iterator.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/es.array.iterator.js */ "./node_modules/core-js/modules/es.array.iterator.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/es.number.constructor.js */ "./node_modules/core-js/modules/es.number.constructor.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/es.string.iterator.js */ "./node_modules/core-js/modules/es.string.iterator.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ "./node_modules/core-js/modules/web.dom-collections.iterator.js");








	function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
	// Determine the type of a variable/object.
	var objType = function objType(obj) {
	  var type = _typeof(obj);
	  if (type === 'undefined') return 'undefined';else if (type === 'string' || obj instanceof String) return 'string';else if (type === 'number' || obj instanceof Number) return 'number';else if (type === 'function' || obj instanceof Function) return 'function';else if (!!obj && obj.constructor === Array) return 'array';else if (obj && obj.nodeType === 1) return 'element';else if (type === 'object') return 'object';else return 'unknown';
	};

	// Create an HTML element with optional className, innerHTML, and style.
	var createElement = function createElement(tagName, opt) {
	  var el = document.createElement(tagName);
	  if (opt.className) el.className = opt.className;
	  if (opt.innerHTML) {
	    el.innerHTML = opt.innerHTML;
	    var scripts = el.getElementsByTagName('script');
	    for (var i = scripts.length; i-- > 0; null) {
	      scripts[i].parentNode.removeChild(scripts[i]);
	    }
	  }
	  for (var key in opt.style) {
	    el.style[key] = opt.style[key];
	  }
	  return el;
	};

	// Convert units from px using the conversion value 'k' from jsPDF.
	var unitConvert = function unitConvert(obj, k) {
	  if (objType(obj) === 'number') {
	    return obj * 72 / 96 / k;
	  } else {
	    var newObj = {};
	    for (var key in obj) {
	      newObj[key] = obj[key] * 72 / 96 / k;
	    }
	    return newObj;
	  }
	};

	// Convert units to px using the conversion value 'k' from jsPDF.
	var toPx = function toPx(val, k) {
	  return Math.floor(val * k / 72 * 96);
	};

	/***/ }),

	/***/ "./src/worker.js":
	/*!***********************!*\
	  !*** ./src/worker.js ***!
	  \***********************/
	/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

	__webpack_require__.r(__webpack_exports__);
	/* harmony import */ __webpack_require__(/*! core-js/modules/es.array.concat.js */ "./node_modules/core-js/modules/es.array.concat.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/es.array.map.js */ "./node_modules/core-js/modules/es.array.map.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/es.function.name.js */ "./node_modules/core-js/modules/es.function.name.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/es.json.stringify.js */ "./node_modules/core-js/modules/es.json.stringify.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/es.object.assign.js */ "./node_modules/core-js/modules/es.object.assign.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/es.object.keys.js */ "./node_modules/core-js/modules/es.object.keys.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/es.object.to-string.js */ "./node_modules/core-js/modules/es.object.to-string.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/es.promise.js */ "./node_modules/core-js/modules/es.promise.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/es.regexp.to-string.js */ "./node_modules/core-js/modules/es.regexp.to-string.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/esnext.iterator.constructor.js */ "./node_modules/core-js/modules/esnext.iterator.constructor.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/esnext.iterator.for-each.js */ "./node_modules/core-js/modules/esnext.iterator.for-each.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/esnext.iterator.map.js */ "./node_modules/core-js/modules/esnext.iterator.map.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/web.dom-collections.for-each.js */ "./node_modules/core-js/modules/web.dom-collections.for-each.js");
	/* harmony import */ __webpack_require__(/*! core-js/modules/web.timers.js */ "./node_modules/core-js/modules/web.timers.js");
	/* harmony import */ var jspdf__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! jspdf */ "jspdf");
	/* harmony import */ var html2canvas__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! html2canvas */ "html2canvas");
	/* harmony import */ var html2canvas__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(html2canvas__WEBPACK_IMPORTED_MODULE_15__);
	/* harmony import */ var _snapdom_clone_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./snapdom/clone.js */ "./src/snapdom/clone.js");
	/* harmony import */ var _utils_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./utils.js */ "./src/utils.js");



















	/* ----- CONSTRUCTOR ----- */

	var Worker = function Worker(opt) {
	  // Create the root parent for the proto chain, and the starting Worker.
	  var root = Object.assign(Worker.convert(Promise.resolve()), JSON.parse(JSON.stringify(Worker.template)));
	  var self = Worker.convert(Promise.resolve(), root);

	  // Set progress, optional settings, and return.
	  self = self.setProgress(1, Worker, 1, [Worker]);
	  self = self.set(opt);
	  return self;
	};

	// Boilerplate for subclassing Promise.
	Worker.prototype = Object.create(Promise.prototype);
	Worker.prototype.constructor = Worker;

	// Converts/casts promises into Workers.
	Worker.convert = function convert(promise, inherit) {
	  // Uses prototypal inheritance to receive changes made to ancestors' properties.
	  promise.__proto__ = inherit || Worker.prototype;
	  return promise;
	};
	Worker.template = {
	  prop: {
	    src: null,
	    container: null,
	    overlay: null,
	    canvas: null,
	    img: null,
	    pdf: null,
	    pageSize: null
	  },
	  progress: {
	    val: 0,
	    state: null,
	    n: 0,
	    stack: []
	  },
	  opt: {
	    filename: 'file.pdf',
	    margin: [0, 0, 0, 0],
	    image: {
	      type: 'jpeg',
	      quality: 0.95
	    },
	    enableLinks: true,
	    html2canvas: {},
	    jsPDF: {}
	  }
	};

	/* ----- FROM / TO ----- */

	Worker.prototype.from = function from(src, type) {
	  function getType(src) {
	    switch ((0, _utils_js__WEBPACK_IMPORTED_MODULE_17__.objType)(src)) {
	      case 'string':
	        return 'string';
	      case 'element':
	        return src.nodeName.toLowerCase && src.nodeName.toLowerCase() === 'canvas' ? 'canvas' : 'element';
	      default:
	        return 'unknown';
	    }
	  }
	  return this.then(function from_main() {
	    type = type || getType(src);
	    switch (type) {
	      case 'string':
	        return this.set({
	          src: (0, _utils_js__WEBPACK_IMPORTED_MODULE_17__.createElement)('div', {
	            innerHTML: src
	          })
	        });
	      case 'element':
	        return this.set({
	          src: src
	        });
	      case 'canvas':
	        return this.set({
	          canvas: src
	        });
	      case 'img':
	        return this.set({
	          img: src
	        });
	      default:
	        return this.error('Unknown source type.');
	    }
	  });
	};
	Worker.prototype.to = function to(target) {
	  // Route the 'to' request to the appropriate method.
	  switch (target) {
	    case 'container':
	      return this.toContainer();
	    case 'canvas':
	      return this.toCanvas();
	    case 'img':
	      return this.toImg();
	    case 'pdf':
	      return this.toPdf();
	    default:
	      return this.error('Invalid target.');
	  }
	};
	Worker.prototype.toContainer = function toContainer() {
	  // Set up function prerequisites.
	  var prereqs = [function checkSrc() {
	    return this.prop.src || this.error('Cannot duplicate - no source HTML.');
	  }, function checkPageSize() {
	    return this.prop.pageSize || this.setPageSize();
	  }];
	  return this.thenList(prereqs).then(function toContainer_main() {
	    // Define the CSS styles for the container and its overlay parent.
	    var overlayCSS = {
	      position: 'fixed',
	      overflow: 'hidden',
	      zIndex: 1000,
	      left: 0,
	      right: 0,
	      bottom: 0,
	      top: 0,
	      backgroundColor: 'rgba(0,0,0,0.8)'
	    };
	    var containerCSS = {
	      position: 'absolute',
	      width: this.prop.pageSize.inner.width + this.prop.pageSize.unit,
	      left: 0,
	      right: 0,
	      top: 0,
	      height: 'auto',
	      margin: 'auto',
	      backgroundColor: 'white'
	    };

	    // Set the overlay to hidden (could be changed in the future to provide a print preview).
	    overlayCSS.opacity = 0;

	    // Create and attach the elements.
	    var source = (0, _snapdom_clone_js__WEBPACK_IMPORTED_MODULE_16__.deepCloneBasic)(this.prop.src);
	    this.prop.overlay = (0, _utils_js__WEBPACK_IMPORTED_MODULE_17__.createElement)('div', {
	      className: 'html2pdf__overlay',
	      style: overlayCSS
	    });
	    this.prop.container = (0, _utils_js__WEBPACK_IMPORTED_MODULE_17__.createElement)('div', {
	      className: 'html2pdf__container',
	      style: containerCSS
	    });
	    this.prop.container.appendChild(source);
	    this.prop.overlay.appendChild(this.prop.container);
	    document.body.appendChild(this.prop.overlay);

	    // Delay to better ensure content is fully cloned and rendering before capturing.
	    return new Promise(function (resolve) {
	      return setTimeout(resolve, 10);
	    });
	  });
	};
	Worker.prototype.toCanvas = function toCanvas() {
	  // Set up function prerequisites.
	  var prereqs = [function checkContainer() {
	    return document.body.contains(this.prop.container) || this.toContainer();
	  }];

	  // Fulfill prereqs then create the canvas.
	  return this.thenList(prereqs).then(function toCanvas_main() {
	    // Handle old-fashioned 'onrendered' argument.
	    var options = Object.assign({}, this.opt.html2canvas);
	    delete options.onrendered;
	    return html2canvas__WEBPACK_IMPORTED_MODULE_15___default()(this.prop.container, options);
	  }).then(function toCanvas_post(canvas) {
	    // Handle old-fashioned 'onrendered' argument.
	    var onRendered = this.opt.html2canvas.onrendered || function () {};
	    onRendered(canvas);
	    this.prop.canvas = canvas;
	    document.body.removeChild(this.prop.overlay);
	  });
	};
	Worker.prototype.toImg = function toImg() {
	  // Set up function prerequisites.
	  var prereqs = [function checkCanvas() {
	    return this.prop.canvas || this.toCanvas();
	  }];

	  // Fulfill prereqs then create the image.
	  return this.thenList(prereqs).then(function toImg_main() {
	    var imgData = this.prop.canvas.toDataURL('image/' + this.opt.image.type, this.opt.image.quality);
	    this.prop.img = document.createElement('img');
	    this.prop.img.src = imgData;
	  });
	};
	Worker.prototype.toPdf = function toPdf() {
	  // Set up function prerequisites.
	  var prereqs = [function checkCanvas() {
	    return this.prop.canvas || this.toCanvas();
	  }, function checkPageSize() {
	    return this.prop.pageSize || this.setPageSize();
	  }];

	  // Fulfill prereqs then create the image.
	  return this.thenList(prereqs).then(function toPdf_main() {
	    // Create local copies of frequently used properties.
	    var canvas = this.prop.canvas;
	    var opt = this.opt;

	    // Calculate the number of pages.
	    var pxFullHeight = canvas.height;
	    var pxPageHeight = Math.floor(canvas.width * this.prop.pageSize.inner.ratio);
	    var nPages = Math.ceil(pxFullHeight / pxPageHeight);

	    // Define pageHeight separately so it can be trimmed on the final page.
	    var pageHeight = this.prop.pageSize.inner.height;

	    // Create a one-page canvas to split up the full image.
	    var pageCanvas = document.createElement('canvas');
	    var pageCtx = pageCanvas.getContext('2d');
	    pageCanvas.width = canvas.width;
	    pageCanvas.height = pxPageHeight;

	    // Initialize the PDF.
	    this.prop.pdf = this.prop.pdf || new jspdf__WEBPACK_IMPORTED_MODULE_14__.jsPDF(opt.jsPDF);
	    for (var page = 0; page < nPages; page++) {
	      // Trim the final page to reduce file size.
	      if (page === nPages - 1 && pxFullHeight % pxPageHeight !== 0) {
	        pageCanvas.height = pxFullHeight % pxPageHeight;
	        pageHeight = pageCanvas.height * this.prop.pageSize.inner.width / pageCanvas.width;
	      }

	      // Display the page.
	      var w = pageCanvas.width;
	      var h = pageCanvas.height;
	      pageCtx.fillStyle = 'white';
	      pageCtx.fillRect(0, 0, w, h);
	      pageCtx.drawImage(canvas, 0, page * pxPageHeight, w, h, 0, 0, w, h);

	      // Add the page to the PDF.
	      if (page) this.prop.pdf.addPage();
	      var imgData = pageCanvas.toDataURL('image/' + opt.image.type, opt.image.quality);
	      this.prop.pdf.addImage(imgData, opt.image.type, opt.margin[1], opt.margin[0], this.prop.pageSize.inner.width, pageHeight);
	    }
	  });
	};

	/* ----- OUTPUT / SAVE ----- */

	Worker.prototype.output = function output(type, options, src) {
	  // Redirect requests to the correct function (outputPdf / outputImg).
	  src = src || 'pdf';
	  if (src.toLowerCase() === 'img' || src.toLowerCase() === 'image') {
	    return this.outputImg(type, options);
	  } else {
	    return this.outputPdf(type, options);
	  }
	};
	Worker.prototype.outputPdf = function outputPdf(type, options) {
	  // Set up function prerequisites.
	  var prereqs = [function checkPdf() {
	    return this.prop.pdf || this.toPdf();
	  }];

	  // Fulfill prereqs then perform the appropriate output.
	  return this.thenList(prereqs).then(function outputPdf_main() {
	    /* Currently implemented output types:
	     *    https://rawgit.com/MrRio/jsPDF/master/docs/jspdf.js.html#line992
	     *  save(options), arraybuffer, blob, bloburi/bloburl,
	     *  datauristring/dataurlstring, dataurlnewwindow, datauri/dataurl
	     */
	    return this.prop.pdf.output(type, options);
	  });
	};
	Worker.prototype.outputImg = function outputImg(type, options) {
	  // Set up function prerequisites.
	  var prereqs = [function checkImg() {
	    return this.prop.img || this.toImg();
	  }];

	  // Fulfill prereqs then perform the appropriate output.
	  return this.thenList(prereqs).then(function outputImg_main() {
	    switch (type) {
	      case undefined:
	      case 'img':
	        return this.prop.img;
	      case 'datauristring':
	      case 'dataurlstring':
	        return this.prop.img.src;
	      case 'datauri':
	      case 'dataurl':
	        return document.location.href = this.prop.img.src;
	      default:
	        throw 'Image output type "' + type + '" is not supported.';
	    }
	  });
	};
	Worker.prototype.save = function save(filename) {
	  // Set up function prerequisites.
	  var prereqs = [function checkPdf() {
	    return this.prop.pdf || this.toPdf();
	  }];

	  // Fulfill prereqs, update the filename (if provided), and save the PDF.
	  return this.thenList(prereqs).set(filename ? {
	    filename: filename
	  } : null).then(function save_main() {
	    this.prop.pdf.save(this.opt.filename);
	  });
	};

	/* ----- SET / GET ----- */

	Worker.prototype.set = function set(opt) {
	  // TODO: Implement ordered pairs?

	  // Silently ignore invalid or empty input.
	  if ((0, _utils_js__WEBPACK_IMPORTED_MODULE_17__.objType)(opt) !== 'object') {
	    return this;
	  }

	  // Build an array of setter functions to queue.
	  var fns = Object.keys(opt || {}).map(function (key) {
	    switch (key) {
	      case 'margin':
	        return this.setMargin.bind(this, opt.margin);
	      case 'jsPDF':
	        return function set_jsPDF() {
	          this.opt.jsPDF = opt.jsPDF;
	          return this.setPageSize();
	        };
	      case 'pageSize':
	        return this.setPageSize.bind(this, opt.pageSize);
	      default:
	        if (key in Worker.template.prop) {
	          // Set pre-defined properties in prop.
	          return function set_prop() {
	            this.prop[key] = opt[key];
	          };
	        } else {
	          // Set any other properties in opt.
	          return function set_opt() {
	            this.opt[key] = opt[key];
	          };
	        }
	    }
	  }, this);

	  // Set properties within the promise chain.
	  return this.then(function set_main() {
	    return this.thenList(fns);
	  });
	};
	Worker.prototype.get = function get(key, cbk) {
	  return this.then(function get_main() {
	    // Fetch the requested property, either as a predefined prop or in opt.
	    var val = key in Worker.template.prop ? this.prop[key] : this.opt[key];
	    return cbk ? cbk(val) : val;
	  });
	};
	Worker.prototype.setMargin = function setMargin(margin) {
	  return this.then(function setMargin_main() {
	    // Parse the margin property: [top, left, bottom, right].
	    switch ((0, _utils_js__WEBPACK_IMPORTED_MODULE_17__.objType)(margin)) {
	      case 'number':
	        margin = [margin, margin, margin, margin];
	      case 'array':
	        if (margin.length === 2) {
	          margin = [margin[0], margin[1], margin[0], margin[1]];
	        }
	        if (margin.length === 4) {
	          break;
	        }
	      default:
	        return this.error('Invalid margin array.');
	    }

	    // Set the margin property, then update pageSize.
	    this.opt.margin = margin;
	  }).then(this.setPageSize);
	};
	Worker.prototype.setPageSize = function setPageSize(pageSize) {
	  return this.then(function setPageSize_main() {
	    // Retrieve page-size based on jsPDF settings, if not explicitly provided.
	    pageSize = pageSize || jspdf__WEBPACK_IMPORTED_MODULE_14__.jsPDF.getPageSize(this.opt.jsPDF);

	    // Add 'inner' field if not present.
	    if (!pageSize.hasOwnProperty('inner')) {
	      pageSize.inner = {
	        width: pageSize.width - this.opt.margin[1] - this.opt.margin[3],
	        height: pageSize.height - this.opt.margin[0] - this.opt.margin[2]
	      };
	      pageSize.inner.px = {
	        width: (0, _utils_js__WEBPACK_IMPORTED_MODULE_17__.toPx)(pageSize.inner.width, pageSize.k),
	        height: (0, _utils_js__WEBPACK_IMPORTED_MODULE_17__.toPx)(pageSize.inner.height, pageSize.k)
	      };
	      pageSize.inner.ratio = pageSize.inner.height / pageSize.inner.width;
	    }

	    // Attach pageSize to this.
	    this.prop.pageSize = pageSize;
	  });
	};
	Worker.prototype.setProgress = function setProgress(val, state, n, stack) {
	  // Immediately update all progress values.
	  if (val != null) this.progress.val = val;
	  if (state != null) this.progress.state = state;
	  if (n != null) this.progress.n = n;
	  if (stack != null) this.progress.stack = stack;
	  this.progress.ratio = this.progress.val / this.progress.state;

	  // Return this for command chaining.
	  return this;
	};
	Worker.prototype.updateProgress = function updateProgress(val, state, n, stack) {
	  // Immediately update all progress values, using setProgress.
	  return this.setProgress(val ? this.progress.val + val : null, state ? state : null, n ? this.progress.n + n : null, stack ? this.progress.stack.concat(stack) : null);
	};

	/* ----- PROMISE MAPPING ----- */

	Worker.prototype.then = function then(onFulfilled, onRejected) {
	  // Wrap `this` for encapsulation.
	  var self = this;
	  return this.thenCore(onFulfilled, onRejected, function then_main(onFulfilled, onRejected) {
	    // Update progress while queuing, calling, and resolving `then`.
	    self.updateProgress(null, null, 1, [onFulfilled]);
	    return Promise.prototype.then.call(this, function then_pre(val) {
	      self.updateProgress(null, onFulfilled);
	      return val;
	    }).then(onFulfilled, onRejected).then(function then_post(val) {
	      self.updateProgress(1);
	      return val;
	    });
	  });
	};
	Worker.prototype.thenCore = function thenCore(onFulfilled, onRejected, thenBase) {
	  // Handle optional thenBase parameter.
	  thenBase = thenBase || Promise.prototype.then;

	  // Wrap `this` for encapsulation and bind it to the promise handlers.
	  var self = this;
	  if (onFulfilled) {
	    onFulfilled = onFulfilled.bind(self);
	  }
	  if (onRejected) {
	    onRejected = onRejected.bind(self);
	  }

	  // Cast self into a Promise to avoid polyfills recursively defining `then`.
	  var isNative = Promise.toString().indexOf('[native code]') !== -1 && Promise.name === 'Promise';
	  var selfPromise = isNative ? self : Worker.convert(Object.assign({}, self), Promise.prototype);

	  // Return the promise, after casting it into a Worker and preserving props.
	  var returnVal = thenBase.call(selfPromise, onFulfilled, onRejected);
	  return Worker.convert(returnVal, self.__proto__);
	};
	Worker.prototype.thenExternal = function thenExternal(onFulfilled, onRejected) {
	  // Call `then` and return a standard promise (exits the Worker chain).
	  return Promise.prototype.then.call(this, onFulfilled, onRejected);
	};
	Worker.prototype.thenList = function thenList(fns) {
	  // Queue a series of promise 'factories' into the promise chain.
	  var self = this;
	  fns.forEach(function thenList_forEach(fn) {
	    self = self.thenCore(fn);
	  });
	  return self;
	};
	Worker.prototype['catch'] = function (onRejected) {
	  // Bind `this` to the promise handler, call `catch`, and return a Worker.
	  if (onRejected) {
	    onRejected = onRejected.bind(this);
	  }
	  var returnVal = Promise.prototype['catch'].call(this, onRejected);
	  return Worker.convert(returnVal, this);
	};
	Worker.prototype.catchExternal = function catchExternal(onRejected) {
	  // Call `catch` and return a standard promise (exits the Worker chain).
	  return Promise.prototype['catch'].call(this, onRejected);
	};
	Worker.prototype.error = function error(msg) {
	  // Throw the error in the Promise chain.
	  return this.then(function error_main() {
	    throw new Error(msg);
	  });
	};

	/* ----- ALIASES ----- */

	Worker.prototype.using = Worker.prototype.set;
	Worker.prototype.saveAs = Worker.prototype.save;
	Worker.prototype.export = Worker.prototype.output;
	Worker.prototype.run = Worker.prototype.then;

	/* ----- FINISHING ----- */

	// Expose the Worker class.
	/* harmony default export */ __webpack_exports__["default"] = (Worker);

	/***/ }),

	/***/ "html2canvas":
	/*!******************************!*\
	  !*** external "html2canvas" ***!
	  \******************************/
	/***/ (function(module) {

	module.exports = __WEBPACK_EXTERNAL_MODULE_html2canvas__;

	/***/ }),

	/***/ "jspdf":
	/*!************************!*\
	  !*** external "jspdf" ***!
	  \************************/
	/***/ (function(module) {

	module.exports = __WEBPACK_EXTERNAL_MODULE_jspdf__;

	/***/ })

	/******/ 	});
	/************************************************************************/
	/******/ 	// The module cache
	/******/ 	var __webpack_module_cache__ = {};
	/******/ 	
	/******/ 	// The require function
	/******/ 	function __webpack_require__(moduleId) {
	/******/ 		// Check if module is in cache
	/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
	/******/ 		if (cachedModule !== undefined) {
	/******/ 			return cachedModule.exports;
	/******/ 		}
	/******/ 		// Create a new module (and put it into the cache)
	/******/ 		var module = __webpack_module_cache__[moduleId] = {
	/******/ 			// no module.id needed
	/******/ 			// no module.loaded needed
	/******/ 			exports: {}
	/******/ 		};
	/******/ 	
	/******/ 		// Execute the module function
	/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
	/******/ 	
	/******/ 		// Return the exports of the module
	/******/ 		return module.exports;
	/******/ 	}
	/******/ 	
	/************************************************************************/
	/******/ 	/* webpack/runtime/compat get default export */
	/******/ 	!function() {
	/******/ 		// getDefaultExport function for compatibility with non-harmony modules
	/******/ 		__webpack_require__.n = function(module) {
	/******/ 			var getter = module && module.__esModule ?
	/******/ 				function() { return module['default']; } :
	/******/ 				function() { return module; };
	/******/ 			__webpack_require__.d(getter, { a: getter });
	/******/ 			return getter;
	/******/ 		};
	/******/ 	}();
	/******/ 	
	/******/ 	/* webpack/runtime/define property getters */
	/******/ 	!function() {
	/******/ 		// define getter functions for harmony exports
	/******/ 		__webpack_require__.d = function(exports, definition) {
	/******/ 			for(var key in definition) {
	/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
	/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
	/******/ 				}
	/******/ 			}
	/******/ 		};
	/******/ 	}();
	/******/ 	
	/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
	/******/ 	!function() {
	/******/ 		__webpack_require__.o = function(obj, prop) { return Object.prototype.hasOwnProperty.call(obj, prop); };
	/******/ 	}();
	/******/ 	
	/******/ 	/* webpack/runtime/make namespace object */
	/******/ 	!function() {
	/******/ 		// define __esModule on exports
	/******/ 		__webpack_require__.r = function(exports) {
	/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
	/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
	/******/ 			}
	/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
	/******/ 		};
	/******/ 	}();
	/******/ 	
	/************************************************************************/
	var __webpack_exports__ = {};
	// This entry needs to be wrapped in an IIFE because it needs to be isolated against other modules in the chunk.
	!function() {
	/*!**********************!*\
	  !*** ./src/index.js ***!
	  \**********************/
	__webpack_require__.r(__webpack_exports__);
	/* harmony import */ var _worker_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./worker.js */ "./src/worker.js");
	/* harmony import */ __webpack_require__(/*! ./plugin/jspdf-plugin.js */ "./src/plugin/jspdf-plugin.js");
	/* harmony import */ __webpack_require__(/*! ./plugin/pagebreaks.js */ "./src/plugin/pagebreaks.js");
	/* harmony import */ __webpack_require__(/*! ./plugin/hyperlinks.js */ "./src/plugin/hyperlinks.js");





	/**
	 * Generate a PDF from an HTML element or string using html2canvas and jsPDF.
	 *
	 * @param {Element|string} source The source element or HTML string.
	 * @param {Object=} opt An object of optional settings: 'margin', 'filename',
	 *    'image' ('type' and 'quality'), and 'html2canvas' / 'jspdf', which are
	 *    sent as settings to their corresponding functions.
	 */
	var html2pdf = function html2pdf(src, opt) {
	  // Create a new worker with the given options.
	  var worker = new html2pdf.Worker(opt);
	  if (src) {
	    // If src is specified, perform the traditional 'simple' operation.
	    return worker.from(src).save();
	  } else {
	    // Otherwise, return the worker for new Promise-based operation.
	    return worker;
	  }
	};
	html2pdf.Worker = _worker_js__WEBPACK_IMPORTED_MODULE_0__["default"];

	// Expose the html2pdf function.
	/* harmony default export */ __webpack_exports__["default"] = (html2pdf);
	}();
	__webpack_exports__ = __webpack_exports__["default"];
	/******/ 	return __webpack_exports__;
	/******/ })()
	;
	}); 
} (html2pdf$2));

var html2pdfExports = html2pdf$2.exports;
const html2pdf = /*@__PURE__*/getDefaultExportFromCjs(html2pdfExports);

const html2pdf$1 = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
	__proto__: null,
	default: html2pdf
}, Symbol.toStringTag, { value: 'Module' }));

export { html2pdf$1 as h };
//# sourceMappingURL=html2pdf.mjs.map
