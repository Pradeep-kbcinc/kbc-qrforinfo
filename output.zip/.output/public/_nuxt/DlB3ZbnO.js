import"./BAWLWkTo.js";import{c as r}from"./5zZ1xFAJ.js";const e=r("v-spacer","div","VSpacer");export{e as V};
